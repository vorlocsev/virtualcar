param([Parameter(Mandatory=$true)][string]$Checkout,[Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
function Run-VC108P([string]$exe,[string[]]$argv) { & $exe @argv; if($LASTEXITCODE -ne 0){throw "$exe failed: $LASTEXITCODE"} }
foreach($tool in @('py.exe','git.exe','dotnet.exe','clang-cl.exe','link.exe')){if(-not (Get-Command $tool -ErrorAction SilentlyContinue)){throw "Missing $tool (Visual Studio x86 Developer PowerShell, LLVM, .NET 10 required)"}}
if($env:VSCMD_ARG_TGT_ARCH -ne 'x86'){throw 'Use x86 target Developer PowerShell (host may be x64)'}
if(-not ((& dotnet.exe --list-sdks) -match '^10\.')){throw '.NET 10 SDK required'}
$out=[IO.Path]::GetFullPath($Output)
Run-VC108P 'py.exe' @('-3',(Join-Path $PSScriptRoot 'prepare_all.py'),$Checkout,$out)
$src=Join-Path $out 'native-review\staged\emulator\src'; $obj=Join-Path $out 'obj'; $provider=Join-Path $out 'provider'; $app=Join-Path $out 'app'
New-Item -ItemType Directory -Path $obj,$provider | Out-Null
$sources=@('virtualcar.c','p2core\p2_cem_router.c','p2core\p2_ls_observer.c','p2core\p2_vehicle_core.c','p2core\p2_j2534_bridge.c','p2core\freestanding_memory.c','vc108n\native\vehicle_state_wire.c','vc108n\native\state_transport.c','vc108n\native\session_credentials.c','vc108n\native\live_state_slot.c','vc108n\native\worker_lifecycle.c','vc108n\windows\state_windows.c','vc108n\windows\session_windows.c','vc108n\windows\state_worker.c','vc108n\integration\vc108n_bridge.c')
$objects=@()
foreach($source in $sources){$o=Join-Path $obj (([IO.Path]::GetFileNameWithoutExtension($source))+'.obj'); $objects+=$o; Run-VC108P 'clang-cl.exe' @('--target=i686-pc-windows-msvc','/nologo','/c','/O2','/GS-','/Zl','/TC','/clang:-fno-builtin','/DVC108P_SDK','/DVC108N_EXTERNAL_STATE','/DVC108N_DLL_WORKER','/D_WIN32_WINNT=0x0A00',('/Fo'+$o),(Join-Path $src $source))}
$dll=Join-Path $provider 'VirtualCarJ2534.dll'
Run-VC108P 'link.exe' (@('/NOLOGO','/DLL','/MACHINE:X86','/ENTRY:DllMain@12','/NODEFAULTLIB',('/DEF:'+(Join-Path $src 'virtualcar.def')),('/OUT:'+$dll))+$objects+@('kernel32.lib','bcrypt.lib','crypt32.lib'))
Run-VC108P 'py.exe' @('-3',(Join-Path $PSScriptRoot 'audit_pe.py'),$dll)
$project=Join-Path $out 'winui-review\emulator\managed\VirtualCar.WinUI\VirtualCar.WinUI.csproj'
Run-VC108P 'dotnet.exe' @('publish',$project,'-c','Release','-r','win-x64','--self-contained','true','-o',$app)
if(-not (Test-Path -LiteralPath (Join-Path $app 'VirtualCar.WinUI.exe') -PathType Leaf)){throw 'WinUI apphost missing'}
# Managed tests are run from a new copy so builds cannot change the input archive tree.
$checks=Join-Path $out 'managed-checks'; New-Item -ItemType Directory -Path $checks | Out-Null
foreach($dir in @('Core','Checks','native')){Copy-Item -LiteralPath (Join-Path $root $dir) -Destination $checks -Recurse}
Push-Location $checks
try { Run-VC108P 'dotnet.exe' @('run','--project','Checks\Checks.csproj','--configuration','Release') } finally { Pop-Location }
# Run load/open/close smoke only in an independent directory, no active profile.
$smoke=Join-Path $out 'smoke'; New-Item -ItemType Directory -Path $smoke | Out-Null; Copy-Item -LiteralPath $dll -Destination $smoke
$ps32=Join-Path $env:WINDIR 'SysWOW64\WindowsPowerShell\v1.0\powershell.exe'
Run-VC108P $ps32 @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'smoke-x86.ps1'),'-Directory',$smoke)
Get-FileHash -Algorithm SHA256 -LiteralPath $dll,(Join-Path $app 'VirtualCar.WinUI.exe') | Format-List
Write-Host 'VC108P_BUILD=PASS (isolated candidate, not installed; external mode and VIDA NOT TESTED)'
