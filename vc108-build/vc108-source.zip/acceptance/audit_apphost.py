import runpy, sys
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name('run-windows-gates.py')))['apphost_x64'](Path(sys.argv[1]).read_bytes())
print('VC108_CLOUD_APPHOST=x64')
