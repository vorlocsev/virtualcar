"""Prepare WinUI and native source candidates; no installation or registry access."""
import argparse, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
BASE='b5671a5f0662d9be75e66314fb7968b2cca61a81'
ANCHOR='#elif defined(CROSS_LLVM)\n/* The module .def'
REPLACEMENT='#elif defined(CROSS_LLVM) || defined(VC108P_SDK)\n/* The module .def'
def sdk_mode(source):
    if source.count(ANCHOR)!=1 or 'VC108P_SDK' in source: raise ValueError('SDK build anchor mismatch')
    return source.replace(ANCHOR,REPLACEMENT,1)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('checkout',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    repo=a.checkout.resolve();out=a.output.resolve()
    if out.exists() or out==repo or repo in out.parents: raise SystemExit('Fresh destination outside checkout required')
    if subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()!=BASE: raise SystemExit('Exact HEAD required')
    out.mkdir(parents=True,exist_ok=False)
    for script,folder in [('integration/prepare.py','native-review'),('winui/prepare_winui.py','winui-review')]:
        subprocess.run([sys.executable,str(ROOT/script),str(repo),str(out/folder)],check=True)
    file=out/'native-review/staged/emulator/src/virtualcar.c'
    file.write_bytes(sdk_mode(file.read_bytes().decode('utf-8')).encode('utf-8'))
    print('VC108P_STAGE=PASS (source only)')
if __name__=='__main__': main()
