#!/usr/bin/env python3
"""Prepare a review-only exact-head patch; never writes to the checkout."""
import argparse
import difflib
import io
import shutil
import stat
import zipfile
import subprocess
from pathlib import Path, PurePosixPath
BASE = 'b5671a5f0662d9be75e66314fb7968b2cca61a81'
SOURCE = 'emulator/src/virtualcar.c'
# Each exact anchor is taken from the reviewed BASE. Fail closed if not unique.
EDITS = [
('''#include "vc0663_identity.h"''','''#include "vc0663_identity.h"
#ifdef VC108N_EXTERNAL_STATE
#include "vc108n/integration/vc108n_bridge.h"
#include "vc108n/integration/vc108n_policy.h"
#endif'''),
('''static U32 g_open;''','''static U32 g_open;
#ifdef VC108N_EXTERNAL_STATE
/* Protected by the existing state lock. closing: 1 retryable, 2 join in progress. */
static U32 g_vc108n_external,g_vc108n_ready,g_vc108n_ignition,g_vc108n_closing;
#endif'''),
('''        count=lab_current_frames(data,len,c->baud,c->flags,tx_flags,c->d2_frame);''','''#ifdef VC108N_EXTERNAL_STATE
        if(g_vc108n_external && !g_vc108n_ready && vc108n_d2_voltage(data,len)){
            backend_event(c,c->active_trace,"request_completed",route,"no_response","no_response");return 1;
        }
#endif
        count=lab_current_frames(data,len,c->baud,c->flags,tx_flags,c->d2_frame);'''),
('''        res[3]=g_b3a157_posii_candidate?0x07u:0x04u;''','''#ifdef VC108N_EXTERNAL_STATE
        if(g_vc108n_external){
            if(!g_vc108n_ready || !vc108n_cem_ignition(g_vc108n_ignition,res+3u))return 0;
        }else
#endif
        res[3]=g_b3a157_posii_candidate?0x07u:0x04u;'''),
('''        res[0]=0x62u;res[1]=0xDDu;res[2]=0x02u;res[3]=lab_cem_voltage_byte(g_b3a324_supply_sync,g_battery_mv);''','''#ifdef VC108N_EXTERNAL_STATE
        if(g_vc108n_external && !g_vc108n_ready)return 0;
#endif
        res[0]=0x62u;res[1]=0xDDu;res[2]=0x02u;res[3]=lab_cem_voltage_byte(g_b3a324_supply_sync,g_battery_mv);'''),
('''static void ecm_lab_refresh(void){
    if(g_open && g_ecm_lab_dynamic_active){''','''static void ecm_lab_refresh(void){
#ifdef VC108N_EXTERNAL_STATE
    if(g_vc108n_external){
        vc_state_snapshot snapshot;
        g_vc108n_ready=0;
        if(g_open && vc108n_snapshot(&snapshot)){
            ECM_LAB_STATE next;
            next.battery_mv=snapshot.battery_mv;next.rpm=snapshot.rpm;
            next.speed_kph=snapshot.speed_kph;next.pedal_permille=snapshot.pedal_permille;
            next.load_permille=snapshot.load_permille;next.maf_centi_gps=snapshot.maf_centi_gps;
            next.ambient_kpa=snapshot.ambient_kpa;next.manifold_kpa=snapshot.manifold_kpa;
            next.coolant_c=snapshot.coolant_c;next.intake_c=snapshot.intake_c;next.ecm_c=snapshot.ecm_c;
            if(ecm_lab_state_valid(&next)){
                g_ecm_lab_dynamic_state=next;g_ecm_lab_dynamic_active=1u;
                g_battery_mv=next.battery_mv;g_vc108n_ignition=snapshot.ignition;g_vc108n_ready=1u;
            }
        }
        return; /* Never advance or fall back to B3A329 in external mode. */
    }
#endif
    if(g_open && g_ecm_lab_dynamic_active){'''),
('''        } else {
            sz=answer_b3a314_ecm_live_lab(c,ecu,id,msg->TxFlags,payload,n,answer);''','''#ifdef VC108N_EXTERNAL_STATE
        } else if(g_vc108n_external && !g_vc108n_ready && ecu->req==0x18DA10F1u &&
                  id==ecu->req && n==3u && payload[0]==0x22u &&
                  vc108n_ecm_did(((U32)payload[1]<<8)|payload[2])){
            sz=0; /* Do not fall through to generic configured DID fixtures. */
#endif
        } else {
            sz=answer_b3a314_ecm_live_lab(c,ecu,id,msg->TxFlags,payload,n,answer);'''),
('''    if(g_open){unlock_state();return error(ERR_DEVICE_IN_USE);}
    g_open=1;bytes_zero(g_ch,sizeof(g_ch));p2_bridge_init(&g_vehicle_bridge);load_config();
    ecm_lab_dynamic_start(g_b3a329_dynamic_lab,GetTickCount());ecm_lab_refresh();*device=1;''','''    if(g_open){unlock_state();return error(ERR_DEVICE_IN_USE);}
#ifdef VC108N_EXTERNAL_STATE
    if(g_vc108n_closing){unlock_state();return error(ERR_DEVICE_IN_USE);}
#endif
    g_open=1;bytes_zero(g_ch,sizeof(g_ch));p2_bridge_init(&g_vehicle_bridge);load_config();
#ifdef VC108N_EXTERNAL_STATE
    {
        int started=vc108n_start(g_profile_path,g_b3a309_ecm_live_lab && g_b3a314_ecm_live_lab &&
            g_b3a267_current_lab && g_b3a150_ggd_cem_lab && g_b3a320_rem_sync && g_b3a324_supply_sync);
        g_vc108n_external=started!=0;g_vc108n_ready=0;
        if(started<0){g_open=0;unlock_state();return error(ERR_FAILED);}
    }
    ecm_lab_dynamic_start(g_vc108n_external?0u:g_b3a329_dynamic_lab,GetTickCount());
#else
    ecm_lab_dynamic_start(g_b3a329_dynamic_lab,GetTickCount());
#endif
    ecm_lab_refresh();*device=1;'''),
('''    lock_state();
    if(!g_open){unlock_state();return error(ERR_INVALID_DEVICE_ID);}
    for(i=0;i<MAX_CHANNELS;i++)if(g_ch[i].used)''','''    lock_state();
#ifdef VC108N_EXTERNAL_STATE
    if(g_vc108n_closing){
        if(g_vc108n_closing==2u){unlock_state();return error(ERR_DEVICE_IN_USE);}
        goto vc108n_join;
    }
#endif
    if(!g_open){unlock_state();return error(ERR_INVALID_DEVICE_ID);}
    for(i=0;i<MAX_CHANNELS;i++)if(g_ch[i].used)'''),
('''    g_open=0;bytes_zero(g_ch,sizeof(g_ch));p2_bridge_init(&g_vehicle_bridge);
    logline("PassThruClose",0,0);unlock_state();return error(ERR_OK);''','''    g_open=0;bytes_zero(g_ch,sizeof(g_ch));p2_bridge_init(&g_vehicle_bridge);
#ifdef VC108N_EXTERNAL_STATE
    if(g_vc108n_external){
        int joined;
vc108n_join:
        g_vc108n_ready=0;g_vc108n_closing=2u;
        unlock_state(); /* Never wait under the J2534 state lock. */
        joined=vc108n_stop();
        lock_state();g_vc108n_closing=joined?0u:1u;
        if(!joined){unlock_state();return error(ERR_TIMEOUT);}
    }
#endif
    logline("PassThruClose",0,0);unlock_state();return error(ERR_OK);'''),
('''        lock_state();ecm_lab_refresh();
        *(U32*)output=g_battery_mv;''','''        lock_state();ecm_lab_refresh();
#ifdef VC108N_EXTERNAL_STATE
        if(g_vc108n_external && !g_vc108n_ready){unlock_state();return error(ERR_DEVICE_NOT_CONNECTED);}
#endif
        *(U32*)output=g_battery_mv;'''),
]

def transform(source):
    for old,new in EDITS:
        if source.count(old)!=1:
            raise ValueError(f'Anchor missing/ambiguous: {old[:90]!r}')
        source=source.replace(old,new,1)
    return source

def main():
    p=argparse.ArgumentParser();p.add_argument('checkout',type=Path);p.add_argument('output',type=Path)
    args=p.parse_args();repo=args.checkout.resolve();out=args.output.resolve()
    if out==repo or repo in out.parents: raise SystemExit('Output must be outside checkout')
    def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
    if git('rev-parse','HEAD').decode().strip()!=BASE:raise SystemExit('Exact HEAD required')
    if git('rev-parse',f'{BASE}:{SOURCE}').decode().strip()!='80cee49fc7712d86e3b3d9d1840f8d1598f0f125':raise SystemExit('Exact source blob required')
    subprocess.run(['git','-C',str(repo),'diff','--quiet','HEAD','--',SOURCE],check=True)
    raw=git('show',f'{BASE}:{SOURCE}')
    source=raw.decode('utf-8');candidate=transform(source)
    out.mkdir(parents=True,exist_ok=False)
    (out/'virtualcar.c').write_bytes(candidate.encode('utf-8'))
    patch=''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='a/'+SOURCE,tofile='b/'+SOURCE))
    (out/'virtualcar.c.patch').write_bytes(patch.encode('utf-8'))
    subprocess.run(['git','-C',str(repo),'apply','--check',str(out/'virtualcar.c.patch')],check=True)
    # Copy committed native tree into a new directory outside the working repo.
    stage=out/'staged'
    with zipfile.ZipFile(io.BytesIO(git('archive','--format=zip',BASE,'emulator/src'))) as z:
        for entry in z.infolist():
            name=PurePosixPath(entry.filename)
            if name.is_absolute() or '..' in name.parts or stat.S_ISLNK(entry.external_attr>>16):
                raise ValueError('Unsafe source archive entry')
            if name.parts not in [('emulator',),('emulator','src')] and name.parts[:2]!=('emulator','src'):
                raise ValueError('Unexpected source archive entry')
        z.extractall(stage)
    src=stage/'emulator'/'src'
    (src/'virtualcar.c').write_bytes(candidate.encode('utf-8'))
    root=Path(__file__).resolve().parent.parent
    vc=src/'vc108n'
    files={
      'native':['vehicle_state_wire','state_transport','session_credentials','live_state_slot','worker_lifecycle'],
      'windows':['state_windows','session_windows','state_worker'],
      'integration':['vc108n_bridge','vc108n_policy'],
    }
    for folder,names in files.items():
        dest=vc/folder;dest.mkdir(parents=True,exist_ok=False)
        for name in names:
            for ext in ('.h','.c'):
                file=root/folder/(name+ext)
                if file.exists():shutil.copyfile(file,dest/file.name)
    shutil.copyfile(root/'native'/'byte_equal.h',vc/'native'/'byte_equal.h')
    print(f'VC108N_REVIEW_PATCH=PASS {len(EDITS)}/{len(EDITS)} (git apply --check; not a build)')
    print('VC108N_STAGED_SOURCE='+str(src))

if __name__=='__main__':main()
