"""Compile selected actual generated Open/Close/refresh hooks with OS mocks.
Not a substitute for building the full source or Win32 worker.
"""
import subprocess,tempfile
from pathlib import Path
from prepare import EDITS
here=Path(__file__).resolve().parent
# Exercise the exact replacement snippets, not a second hand-written algorithm.
by_old=lambda starts:next(new for old,new in EDITS if old.startswith(starts))
refresh=by_old('static void ecm_lab_refresh(void){')+'''\n        ecm_lab_dynamic_tick(GetTickCount());\n        g_battery_mv=g_ecm_lab_state.battery_mv;\n    }\n}\n'''
open_src='''U32 PassThruOpen(void *name,U32 *device){(void)name;lock_state();\n'''+by_old('    if(g_open){unlock_state();return error(ERR_DEVICE_IN_USE);}')+'''\n    logline("PassThruOpen -> device 1",0,0);unlock_state();return error(ERR_OK);\n}\n'''
close_src='''U32 PassThruClose(U32 device){U32 i;if(device!=1)return error(ERR_INVALID_DEVICE_ID);\n'''+by_old('    lock_state();\n    if(!g_open){unlock_state();return error(ERR_INVALID_DEVICE_ID);}')+'''\n        backend_cancel_channel(&g_ch[i],"device_close",0);\n'''+by_old('    g_open=0;bytes_zero(g_ch,sizeof(g_ch));p2_bridge_init(&g_vehicle_bridge);')+'\n}\n'
common=r'''
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "vc108n_bridge.h"
typedef unsigned U32;
typedef struct {U32 battery_mv,rpm,speed_kph,pedal_permille,load_permille,maf_centi_gps,ambient_kpa,manifold_kpa;int coolant_c,intake_c,ecm_c;} ECM_LAB_STATE;
static U32 g_open,g_battery_mv=12500,g_ecm_lab_dynamic_active,g_b3a329_dynamic_lab=1;
static U32 g_b3a309_ecm_live_lab=1,g_b3a314_ecm_live_lab=1,g_b3a267_current_lab=1,g_b3a150_ggd_cem_lab=1,g_b3a320_rem_sync=1,g_b3a324_supply_sync=1;
static U32 g_vc108n_external,g_vc108n_ready,g_vc108n_ignition,g_vc108n_closing;
static ECM_LAB_STATE g_ecm_lab_dynamic_state;
#define g_ecm_lab_state g_ecm_lab_dynamic_state
#define ERR_OK 0u
#define ERR_FAILED 7u
#define ERR_TIMEOUT 9u
#define ERR_DEVICE_IN_USE 14u
#define ERR_INVALID_DEVICE_ID 26u
#define MAX_CHANNELS 1
static struct {int used;} g_ch[1];
static int g_vehicle_bridge;
static char g_profile_path[]="lab.ini";
static int locked,mode=1,available,stop_ok,starts,ticks,stops;
static vc_state_snapshot mock;
static void lock_state(void){assert(!locked);locked=1;}
static void unlock_state(void){assert(locked);locked=0;}
static U32 error(U32 n){return n;}
static U32 GetTickCount(void){return 0;}
static void bytes_zero(void *p,size_t n){memset(p,0,n);}
static void p2_bridge_init(int *p){*p=0;}
static void load_config(void){}
static void logline(const char *s,int a,int b){(void)s;(void)a;(void)b;}
static void backend_cancel_channel(void *p,const char *s,int x){(void)p;(void)s;(void)x;}
static int ecm_lab_state_valid(const ECM_LAB_STATE *s){return s->battery_mv<=20000;}
static void ecm_lab_dynamic_start(U32 enabled,U32 now){(void)now;starts++;g_ecm_lab_dynamic_active=enabled;}
static void ecm_lab_dynamic_tick(U32 now){(void)now;ticks++;g_ecm_lab_dynamic_state.battery_mv=14200;}
int vc108n_start(const char *p,int ready){(void)p;return mode&& !ready?-1:mode;}
int vc108n_stop(void){assert(!locked);stops++;return stop_ok;}
int vc108n_snapshot(vc_state_snapshot *out){assert(locked);if(!available)return 0;*out=mock;return 1;}
'''
tests=r'''
int main(void){
    U32 device=99;
    mode=0;assert(PassThruOpen(0,&device)==ERR_OK&&device==1&&ticks==1&&g_battery_mv==14200);
    assert(PassThruClose(1)==ERR_OK&&stops==0);puts("PASS legacy behavior");
    mode=1;g_b3a324_supply_sync=0;device=99;assert(PassThruOpen(0,&device)==ERR_FAILED&&device==99&&!g_open);
    g_b3a324_supply_sync=1;assert(PassThruOpen(0,&device)==ERR_OK&&g_open&&g_vc108n_external&&!g_vc108n_ready&&ticks==1);puts("PASS gates and no legacy fallback");
    mock.battery_mv=14000;mock.rpm=700;mock.ignition=2;mock.coolant_c=90;available=1;
    lock_state();ecm_lab_refresh();unlock_state();assert(g_vc108n_ready&&g_battery_mv==14000&&g_ecm_lab_state.rpm==700&&g_ecm_lab_state.coolant_c==90&&g_vc108n_ignition==2&&ticks==1);puts("PASS coherent external snapshot");
    available=0;lock_state();ecm_lab_refresh();unlock_state();assert(!g_vc108n_ready&&ticks==1);puts("PASS expired source not replaced by legacy");
    mock.battery_mv=30000;available=1;lock_state();ecm_lab_refresh();unlock_state();assert(!g_vc108n_ready&&g_battery_mv==14000);puts("PASS invalid snapshot");
    mock.battery_mv=12500;mock.rpm=0;mock.ignition=0;lock_state();ecm_lab_refresh();unlock_state();assert(g_vc108n_ready&&g_battery_mv==12500&&g_ecm_lab_state.rpm==0&&g_vc108n_ignition==0);puts("PASS recovery");
    assert(PassThruClose(1)==ERR_TIMEOUT&&!g_open&&g_vc108n_closing==1&&!g_vc108n_ready&&stops==1);
    assert(PassThruOpen(0,&device)==ERR_DEVICE_IN_USE);puts("PASS timeout retains ownership and blocks Open");
    stop_ok=1;assert(PassThruClose(1)==ERR_OK&&g_vc108n_closing==0&&stops==2&&!locked);
    assert(PassThruClose(1)==ERR_INVALID_DEVICE_ID);puts("PASS close retry joins outside lock");
    mode=0;assert(PassThruOpen(0,&device)==ERR_OK&&!g_vc108n_external&&ticks==2);assert(PassThruClose(1)==ERR_OK);puts("PASS explicit legacy reopen");
    puts("VC108N_HOOKS=PASS 9/9 (mocked OS, generated source fragments)");return 0;
}
'''
with tempfile.TemporaryDirectory() as td:
    td=Path(td);source=td/'hooks.c';source.write_text(common+refresh+open_src+close_src+tests)
    exe=td/'hooks';subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=undefined','-DVC108N_EXTERNAL_STATE','-I',str(here),str(source),'-o',str(exe)],check=True);subprocess.run([str(exe)],check=True)
