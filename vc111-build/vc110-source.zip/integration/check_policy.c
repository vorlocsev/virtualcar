#include "vc108n_policy.h"
#include <assert.h>
#include <stdio.h>
int main(void){
    unsigned char raw=0xFF;
    unsigned char rem[]={0xCD,0x46,0xA6,0xD0,0xD4,1,0,0};
    unsigned char rem2[]={0xCD,0x46,0xA6,0x1A,0x02,1,0,0};
    unsigned char other[]={0xCD,0x29,0xA6,0,0x80,1,0,0};
    unsigned count=0;
    for(unsigned i=0;i<=0xFFFFu;i++)if(vc108n_ecm_did(i))count++;
    assert(count==21 && vc108n_ecm_did(0xDA48)&&vc108n_ecm_did(0xD994));
    assert(!vc108n_ecm_did(0xF110)&&!vc108n_ecm_did(0xF190));
    assert(vc108n_cem_ignition(0,&raw)&&raw==4&&vc108n_cem_ignition(2,&raw)&&raw==7);
    assert(!vc108n_cem_ignition(1,&raw)&&raw==7&&!vc108n_cem_ignition(3,&raw));
    assert(vc108n_d2_voltage(rem,8)&&vc108n_d2_voltage(rem2,8)&&vc108n_d2_voltage(other,8));
    rem[2]=0xA3;assert(!vc108n_d2_voltage(rem,8)&&!vc108n_d2_voltage(other,7));
    other[7]=1;assert(!vc108n_d2_voltage(other,8)&&!vc108n_d2_voltage(NULL,8));
    puts("VC108N_POLICY=PASS 7/7");return 0;
}
