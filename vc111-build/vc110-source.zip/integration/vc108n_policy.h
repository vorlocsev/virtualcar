#ifndef VC108N_POLICY_H
#define VC108N_POLICY_H
#include "../native/vehicle_state_wire.h"
/* Exact existing live DID set. No route expansion, no CAN commands. */
static inline int vc108n_ecm_did(unsigned did){
    switch(did){
    case 0x120D:case 0xD998:case 0xD99B:case 0xDA48:case 0xF40C:case 0xF40D:case 0xF40F:
    case 0xD9AC:case 0xD9AD:case 0xD9B8:case 0xF404:case 0xF405:case 0xF410:case 0xF443:
    case 0xD994:case 0xF433:case 0xF449:case 0xF44A:case 0xF40B:case 0xD9A4:case 0xDA47:return 1;
    default:return 0;
    }
}
static inline int vc108n_cem_ignition(unsigned ignition, unsigned char *out){
    if(!out || (ignition!=0u && ignition!=2u))return 0;
    *out=(unsigned char)(ignition==2u?7u:4u);return 1;
}
/* Exact requests that B3A320/324 source their voltage from g_battery_mv. */
static inline int vc108n_d2_voltage(const unsigned char *p,unsigned n){
    if(!p||n!=8u||p[0]!=0xCD||p[2]!=0xA6||p[5]!=1||p[6]||p[7])return 0;
    return (p[1]==0x46 && ((p[3]==0xD0&&p[4]==0xD4)||(p[3]==0x1A&&p[4]==2)))||
           (p[1]==0x29&&p[3]==0&&p[4]==0x80);
}
#endif
