from prepare import EDITS,transform
# Anchor fixture only, not a complete native source nor a compile test.
base='\n/* fixture separator */\n'.join(old for old,_ in EDITS)
assert all(base.count(old)==1 for old,_ in EDITS)
patched=transform(base)
assert all(new in patched for _,new in EDITS)
for old,_ in EDITS:
    for bad in (base.replace(old,'',1),base+'\n'+old):
        try: transform(bad)
        except ValueError: pass
        else: raise AssertionError('missing or duplicate accepted')
try:transform(patched)
except ValueError:pass
else:raise AssertionError('double application accepted')
print(f'VC108N_ANCHORS=PASS {2*len(EDITS)+2}/{2*len(EDITS)+2} (synthetic fixture)')
