#ifndef VC108N_BRIDGE_H
#define VC108N_BRIDGE_H
#include "../native/vehicle_state_wire.h"
/* Separate translation unit: do not include windows.h in virtualcar.c. */
int vc108n_start(const char *profile,int gates_ready); /* 0 disabled, 1 launched, -1 rejected */
int vc108n_stop(void); /* bounded join, 0 retains context */
int vc108n_snapshot(vc_state_snapshot *out); /* fresh only */
#endif
