#include "vc108n_bridge.h"
#include "../windows/state_worker.h"
/* Called by serialized Open/Close owner only. snapshot uses worker's short lock.
 * Trusted launcher supplies the session directory and ID in a local lab profile.
 * No discovery, no credentials in INI. Same-user compromise is out of scope. */
static vc_win_worker worker;
static int initialized;
static int hexval(char c){if(c>='0'&&c<='9')return c-'0';if(c>='A'&&c<='F')return c-'A'+10;return -1;}
static int path_with_suffix(const char *parent,const wchar_t *suffix,wchar_t out[MAX_PATH]){
    int n=MultiByteToWideChar(CP_ACP,MB_ERR_INVALID_CHARS,parent,-1,out,MAX_PATH);
    unsigned i=0;
    if(n<=1 || out[n-2]==L'\\')return 0;
    --n;
    while(suffix[i]){if(n>=MAX_PATH-1)return 0;out[n++]=suffix[i++];}
    out[n]=0;return vc_win_trusted_path_shape(out);
}
int vc108n_start(const char *profile,int gates_ready){
    static const char section[]="VC108N_ExternalStateLab";
    char enabled[8],dir[MAX_PATH],idtext[34];uint8_t id[16];wchar_t cred[MAX_PATH],state[MAX_PATH];
    DWORD n;unsigned i;int a,b;
    if(!profile)return -1;
    n=GetPrivateProfileStringA(section,"Enabled","0",enabled,sizeof(enabled),profile);
    if(n!=1 || (enabled[0]!='0'&&enabled[0]!='1'))return -1;
    if(enabled[0]=='0')return 0;
    if(!gates_ready)return -1;
    if(!initialized){vc_win_worker_init(&worker);initialized=1;}
    n=GetPrivateProfileStringA(section,"SessionDirectory","",dir,sizeof(dir),profile);
    if(!n||n>=sizeof(dir)-1u)return -1;
    n=GetPrivateProfileStringA(section,"SessionId","",idtext,sizeof(idtext),profile);
    if(n!=32)return -1;
    for(i=0;i<16u;i++){a=hexval(idtext[i*2u]);b=hexval(idtext[i*2u+1u]);if(a<0||b<0)return -1;id[i]=(uint8_t)((a<<4)|b);}
    if(!path_with_suffix(dir,L"\\credentials.dpapi",cred)||!path_with_suffix(dir,L"\\state.bin",state))return -1;
    return vc_win_worker_start(&worker,cred,state,id)?1:-1;
}
int vc108n_stop(void){return !initialized||vc_win_worker_stop(&worker,5000u);}
int vc108n_snapshot(vc_state_snapshot *out){return initialized&&vc_win_worker_select(&worker,out)==VC_LIVE_EXTERNAL;}
