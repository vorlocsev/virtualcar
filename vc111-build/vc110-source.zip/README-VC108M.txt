VC108M — worker lifecycle prototype (cumulative E–M).
Target PR511 b5671a5f0662d9be75e66314fb7968b2cca61a81. No repo/DLL changes.

Portable worker_lifecycle serializes IDLE -> RUNNING -> STOPPING -> IDLE.
RUNNING is permission to publish, not a guarantee of authenticated data.
Stop revokes publication and invalidates snapshot immediately, before joining.
No automatic fallback: joined external mode stays unavailable; only explicit
owner action after join restores LEGACY. Generation prevents late publication.
The portable model relies on caller proving actual OS thread termination before
calling joined; a timeout must NEVER invoke joined.

Windows state_worker uses a private SRWLOCK, manual-reset stop event, CreateThread,
100 ms interruptible polling. Worker initializes DPAPI/BCrypt itself, publishes
only NEW packets using the authenticated source tick, and wipes the reader on
exit. Credential/path/session copied before thread creation, immutable until
join. Lifecycle operations serialized by owner; select concurrent. No blocking
I/O/crypto/join under either the slot lock or J2534 state lock. In a timed-out
stop, object and handles remain alive, mode remains unavailable, no restart or
unload until retry successfully joins. Synchronous disk reads/DPAPI can block;
no guarantee of bounded OS I/O cancellation. No TerminateThread. Never call
from DllMain. Caller must prevent unloading DLL while code executes and arrange
explicit shutdown outside loader lock; not implemented in PR511. No automatic
same-session reconnect or discovery; launcher must supply fresh trusted session.
Caller must reject invalid external configuration (start may reject inputs
before entering external mode). No active-profile changes. Windows wrapper
uses ordinary CRT/Win32 SDK for prototype; custom no-CRT J2534 import/build and
safe PassThruOpen/Close lock order still need integration.

Executed on Linux with GCC -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined:
 cc ... native/live_state_slot.c native/worker_lifecycle.c native/check_worker_lifecycle.c
 VC108M_LIFECYCLE=PASS 12/12
 cc ... -pthread native/live_state_slot.c native/worker_lifecycle.c native/check_worker_race.c
 VC108M_LATE_PUBLISH=PASS 100/100 (real pthread, deterministic condition barrier)
 python3 native/test_live_pipeline.py
 VC108G_NATIVE=PASS 9/9; VC108I_END_TO_END=PASS 500/500 + expiry

Windows/.NET NOT RUN. Test in x86/x64 Visual Studio Developer PowerShell:
 powershell.exe -NoProfile -File .\windows\check-worker.ps1
Expected VC108M_WINDOWS=PASS 6/6 and VC108M_MANAGED_PUBLISHER=PASS.
The test uses actual DPAPI credentials and a C# periodic publisher, not VIDA.
Windows timeout/hung-I/O test, DLL unload behavior and no-CRT build not verified.
