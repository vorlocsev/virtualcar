VC108P — isolated integrated build candidate (not a release)
Exact base: b5671a5f0662d9be75e66314fb7968b2cca61a81.

Windows x64 VMware, x86-target Visual Studio Developer PowerShell, LLVM clang-cl,
Windows 10/11 SDK, .NET 10 SDK, Python 3 and Git required. If a tool is absent,
stop; do not install or register drivers automatically. Use a fresh output path.
From the unpacked prototype folder:
 powershell.exe -NoProfile -File .\acceptance\build-candidate.ps1 -Checkout C:\VirtualCar-PR511 -Output C:\VC108P-review
The script stages the two existing exact-head generators, adds a SDK-link-specific
export macro (keeps normal stdcall imports and def-owned exports), compiles x86
with clang-cl, links SDK imports with /NODEFAULTLIB, audits direct imports and all
14 exports, publishes WinUI x64 with the original apphost name, runs the managed
model checks, and tests legacy Open/VBATT/Close and invalid external opt-in in a
separate x86 PowerShell process. The smoke process has its own TEMP/TMP.
No INI is copied into provider; smoke writes only its synthetic test INI.
No registry edits, registration, original VIDA changes, jobs, or release.
The original checkout and active VC107 provider are untouched.
Partial build directories are kept for debugging; retry with a fresh destination.

Expected gates, NOT observed yet on Windows:
 VC108P_STAGE=PASS (source only)
 VC108P_PE=PASS x86 exports=14 imports=bcrypt.dll,crypt32.dll,kernel32.dll
 VC108F_MANAGED=PASS 8/8
 VC108G_MANAGED=PASS 3/3
 VC108K_MANAGED=PASS 9/9
 VC108P_X86_SMOKE=PASS 6/6 (legacy and invalid opt-in only)
 VC108P_BUILD=PASS (isolated candidate, not installed; external mode and VIDA NOT TESTED)

After a successful build, start C:\VC108P-review\app\VirtualCar.WinUI.exe --live-control.
Do not register the candidate or use the active profile yet. Next gate is a direct
x86 runtime with real VCST/VCTP publisher and an isolated copy of the exact VC107
profile, then VIDA runtime; require explicit approval for provider registration.
The PE audit checks direct imports, not arbitrary dependencies of system DLLs.
A build or smoke PASS does not prove external IPC, actual Windows DPAPI/ACL,
VIDA acceptance, or correct OEM calibration.

Executed in Linux: PE auditor tests on real synthetic x86 PE fixtures and SDK
anchor tests 8/8; prior WinUI generator 6/6, native anchor generator 24/24,
mocked OS hooks 9/9. Windows SDK/.NET/PowerShell execution unavailable here;
full SDK link may require fixes. Exact-head stage has not been run on a real
checkout this turn. No actual provider DLL or executable included in this archive.
