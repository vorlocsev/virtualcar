#include "state_worker.h"
#include <stdio.h>
#include <wchar.h>
#define C(x) do{if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);goto cleanup;}}while(0)
static int nibble(wchar_t c){if(c>=L'0'&&c<=L'9')return (int)(c-L'0');if(c>=L'A'&&c<=L'F')return (int)(c-L'A'+10);return -1;}
int wmain(int argc,wchar_t **argv){
    vc_win_worker w;vc_state_snapshot out={0};uint8_t id[16],wrong[16];unsigned i;int a,b,rc=1;uint64_t started;
    if(argc!=4||wcslen(argv[3])!=32)return 2;
    for(i=0;i<16;i++){a=nibble(argv[3][2*i]);b=nibble(argv[3][2*i+1]);if(a<0||b<0)return 2;id[i]=(uint8_t)((a<<4)|b);wrong[i]=id[i];}
    wrong[0]^=1;vc_win_worker_init(&w);
    C(vc_win_worker_select(&w,&out)==VC_LIVE_LEGACY);puts("PASS legacy default");
    C(vc_win_worker_start(&w,argv[1],argv[2],wrong));
    C(vc_win_worker_stop(&w,5000));C(vc_win_worker_select(&w,&out)==VC_LIVE_UNAVAILABLE);puts("PASS wrong session stop/join");
    C(vc_win_worker_start(&w,argv[1],argv[2],id));
    C(!vc_win_worker_start(&w,argv[1],argv[2],id)&&!vc_win_worker_legacy(&w));puts("PASS duplicate lifecycle rejected");
    started=GetTickCount64();
    while(vc_win_worker_select(&w,&out)!=VC_LIVE_EXTERNAL&&GetTickCount64()-started<10000u)Sleep(20);
    C(vc_win_worker_select(&w,&out)==VC_LIVE_EXTERNAL&&out.rpm==700&&out.battery_mv==14000);puts("PASS live DPAPI/BCrypt worker");
    C(vc_win_worker_stop(&w,5000));C(vc_win_worker_select(&w,&out)==VC_LIVE_UNAVAILABLE);puts("PASS joined no fallback");
    C(vc_win_worker_stop(&w,5000)&&vc_win_worker_legacy(&w)&&vc_win_worker_select(&w,&out)==VC_LIVE_LEGACY);puts("PASS idempotent stop explicit legacy");
    puts("VC108M_WINDOWS=PASS 6/6");rc=0;
cleanup:
    if(!vc_win_worker_stop(&w,5000)){/* test process must not return with a live stack context */ ExitProcess(3);}
    return rc;
}
