#include "session_windows.h"
#include <stdio.h>
#include <wchar.h>
static int nibble(wchar_t c){if(c>=L'0'&&c<=L'9')return (int)(c-L'0');if(c>=L'A'&&c<=L'F')return (int)(c-L'A'+10);return -1;}
int wmain(int argc,wchar_t **argv){
    vc_win_reader r={0};uint8_t id[16],wrong[16];unsigned i;int a,b;int ok=0;
    if(argc!=4||wcslen(argv[2])!=32)return 2;
    for(i=0;i<16;i++){a=nibble(argv[2][2*i]);b=nibble(argv[2][2*i+1]);if(a<0||b<0)return 2;id[i]=(uint8_t)((a<<4)|b);wrong[i]=id[i];}
    wrong[0]^=1;
    if(vc_win_init_protected(&r,argv[1],wrong))goto end;
    if(!vc_win_init_protected(&r,argv[1],id))goto end;
    if(vc_win_init_protected(&r,argv[1],id))goto end;
    vc_win_close(&r);
    if(vc_win_init_protected(&r,argv[3],id))goto end;
    puts("VC108L_WINDOWS_RECEIVER=PASS 4/4");ok=1;
end:vc_win_close(&r);return ok?0:1;
}
