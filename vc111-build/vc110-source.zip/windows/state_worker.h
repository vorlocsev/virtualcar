#ifndef VC_STATE_WORKER_H
#define VC_STATE_WORKER_H
#include "session_windows.h"
#include "../native/worker_lifecycle.h"
/* Explicitly initialize once, before use; no copy after initialization.
 * Lifecycle calls serialized by the owning control thread (not DllMain).
 * select may be called concurrently. Never wait while holding DLL state lock.
 * On stop timeout/error keep this object, handles and DLL loaded; retry stop.
 * The caller must guarantee no select calls before freeing the object. */
typedef struct {
    SRWLOCK lock;
    vc_worker_lifecycle lifecycle;
    HANDLE thread, stop_event;
#ifdef VC108N_DLL_WORKER
    HMODULE module_ref;
#endif
    uint64_t generation;
    wchar_t credentials[MAX_PATH], state_path[MAX_PATH];
    uint8_t session[16];
} vc_win_worker;
void vc_win_worker_init(vc_win_worker *);
int vc_win_worker_start(vc_win_worker *,const wchar_t *,const wchar_t *,const uint8_t [16]);
/* Returns 1 only when no worker remains; 0 means do NOT free/unload/restart. */
int vc_win_worker_stop(vc_win_worker *,DWORD timeout_ms);
int vc_win_worker_legacy(vc_win_worker *);
vc_live_result vc_win_worker_select(vc_win_worker *,vc_state_snapshot *);
#endif
