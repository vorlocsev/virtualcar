#ifndef VC_SESSION_WINDOWS_H
#define VC_SESSION_WINDOWS_H
#include "state_windows.h"
/* Caller supplies trusted, absolute path and expected session. Directory
 * ownership/ancestor validation is a launcher responsibility. No discovery.
 * r must be zero initialized; failure must not replace an active reader. */
int vc_win_init_protected(vc_win_reader *r,const wchar_t *path,const uint8_t session[16]);
#endif
