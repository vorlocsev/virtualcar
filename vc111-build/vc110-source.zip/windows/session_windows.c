#include "session_windows.h"
#include "../native/session_credentials.h"
#include <wincrypt.h>
/* Exact local file path from trusted launcher; reject final reparse points.
 * The launcher must ensure all ancestors are local and not reparsed. */
int vc_win_init_protected(vc_win_reader *r,const wchar_t *path,const uint8_t session[16]){
    HANDLE f=INVALID_HANDLE_VALUE;BY_HANDLE_FILE_INFORMATION info;
    uint8_t *blob=NULL,key[32]={0},extra=0;DWORD n=0,tail=0;int ok=0;
    DATA_BLOB input={0,NULL},output={0,NULL};
    if(!r||r->alg||!session||!vc_win_trusted_path_shape(path))return 0;
    f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,NULL);
    if(f==INVALID_HANDLE_VALUE)goto end;
    if(GetFileType(f)!=FILE_TYPE_DISK||!GetFileInformationByHandle(f,&info)||
       (info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))||
       info.nFileSizeHigh||!info.nFileSizeLow||info.nFileSizeLow>4096u)goto end;
    blob=(uint8_t *)HeapAlloc(GetProcessHeap(),0,info.nFileSizeLow);
    if(!blob)goto end;
    if(!ReadFile(f,blob,info.nFileSizeLow,&n,NULL)||n!=info.nFileSizeLow||
       !ReadFile(f,&extra,1,&tail,NULL)||tail)goto end;
    input.cbData=n;input.pbData=blob;
    if(!CryptUnprotectData(&input,NULL,NULL,NULL,NULL,CRYPTPROTECT_UI_FORBIDDEN,&output))goto end;
    if(!vc_credentials_decode(output.pbData,output.cbData,session,key))goto end;
    ok=vc_win_init(r,session,key);
end:
    if(output.pbData){SecureZeroMemory(output.pbData,output.cbData);LocalFree(output.pbData);}
    SecureZeroMemory(key,sizeof(key));
    if(blob){SecureZeroMemory(blob,info.nFileSizeLow);HeapFree(GetProcessHeap(),0,blob);}
    if(f!=INVALID_HANDLE_VALUE)CloseHandle(f);
    return ok;
}
