$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'Use an x86 or x64 Visual Studio Developer PowerShell.' }
if (-not (Get-Command dotnet.exe -ErrorAction SilentlyContinue)) { throw '.NET 10 SDK required' }
$out = Join-Path $env:TEMP ('VC108M-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $out | Out-Null
try {
    Push-Location $out
    try {
        $sources = @('native\vehicle_state_wire.c','native\state_transport.c','native\session_credentials.c','native\live_state_slot.c','native\worker_lifecycle.c','windows\state_windows.c','windows\session_windows.c','windows\state_worker.c','windows\check_worker_windows.c') | ForEach-Object { Join-Path $root $_ }
        & cl.exe /nologo /std:c11 /W4 /WX /O2 /D_WIN32_WINNT=0x0A00 $sources /Fe:check-worker.exe /link bcrypt.lib crypt32.lib
        if ($LASTEXITCODE -ne 0) { throw 'Worker build failed' }
    } finally { Pop-Location }
    & dotnet.exe run --project (Join-Path $root 'WorkerChecks\WorkerChecks.csproj') --configuration Release -- (Join-Path $out 'check-worker.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Worker checks failed' }
} finally { Remove-Item -LiteralPath $out -Recurse -Force }
