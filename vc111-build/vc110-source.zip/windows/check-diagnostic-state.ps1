$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'Use a Visual Studio Developer PowerShell.' }
$out = Join-Path $env:TEMP ('VC108J-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $out | Out-Null
try {
    Push-Location $out
    try {
        & cl.exe /nologo /std:c11 /W4 /WX /O2 (Join-Path $root 'native\live_state_slot.c') (Join-Path $root 'native\diagnostic_state.c') (Join-Path $root 'native\check_diagnostic_state.c') /Fe:check-diagnostic-state.exe
        if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
        & .\check-diagnostic-state.exe
        if ($LASTEXITCODE -ne 0) { throw 'Diagnostic state checks failed' }
    } finally { Pop-Location }
} finally { Remove-Item -LiteralPath $out -Recurse -Force }
