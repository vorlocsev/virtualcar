#include "state_worker.h"
#include <string.h>
/* Bound both path scans, avoiding a new wcslen CRT dependency. */
static size_t path_len(const wchar_t *s){size_t n=0;while(n<MAX_PATH && s[n])n++;return n;}
#define VC_POLL_MS 100u
#ifdef VC108N_DLL_WORKER
static const char worker_module_anchor=0;
#endif
static DWORD WINAPI run_worker(LPVOID context){
    vc_win_worker *w=(vc_win_worker *)context;
#ifdef VC108N_DLL_WORKER
    HMODULE module=w->module_ref;
#endif
    vc_win_reader reader={0};vc_state_snapshot state;
    if(WaitForSingleObject(w->stop_event,0)!=WAIT_TIMEOUT)goto end;
    if(!vc_win_init_protected(&reader,w->credentials,w->session))goto end;
    for(;;){
        if(WaitForSingleObject(w->stop_event,0)!=WAIT_TIMEOUT)break;
        if(vc_win_poll(&reader,w->state_path,&state)==VC_WIN_NEW){
            AcquireSRWLockExclusive(&w->lock);
            (void)vc_worker_publish(&w->lifecycle,w->generation,&state,reader.cache.accepted_tick,GetTickCount64());
            ReleaseSRWLockExclusive(&w->lock);
        }
        if(WaitForSingleObject(w->stop_event,VC_POLL_MS)!=WAIT_TIMEOUT)break;
    }
end:
    vc_win_close(&reader);
    AcquireSRWLockExclusive(&w->lock);
    (void)vc_worker_exited(&w->lifecycle,w->generation);
    ReleaseSRWLockExclusive(&w->lock);
#ifdef VC108N_DLL_WORKER
    /* Atomic release + exit; no instruction executes after unloading module. */
    FreeLibraryAndExitThread(module,0);
#else
    return 0;
#endif
}
void vc_win_worker_init(vc_win_worker *w){
    if(!w)return;ZeroMemory(w,sizeof(*w));InitializeSRWLock(&w->lock);
}
static void clear_context(vc_win_worker *w){
    SecureZeroMemory(w->credentials,sizeof(w->credentials));
    SecureZeroMemory(w->state_path,sizeof(w->state_path));
    SecureZeroMemory(w->session,sizeof(w->session));w->generation=0;
}
int vc_win_worker_start(vc_win_worker *w,const wchar_t *credentials,const wchar_t *state,const uint8_t session[16]){
    size_t a,b;unsigned i;uint8_t any=0;int begun;
    if(!w||w->thread||w->stop_event||!credentials||!state||!session)return 0;
    a=path_len(credentials);b=path_len(state);
    if(a>=MAX_PATH||b>=MAX_PATH||!vc_win_trusted_path_shape(credentials)||!vc_win_trusted_path_shape(state))return 0;
    for(i=0;i<16u;i++)any|=session[i];if(!any)return 0;
    AcquireSRWLockExclusive(&w->lock);
    begun=vc_worker_begin(&w->lifecycle,&w->generation);
    ReleaseSRWLockExclusive(&w->lock);
    if(!begun)return 0;
    memcpy(w->credentials,credentials,(a+1)*sizeof(wchar_t));
    memcpy(w->state_path,state,(b+1)*sizeof(wchar_t));memcpy(w->session,session,16);
    w->stop_event=CreateEventW(NULL,TRUE,FALSE,NULL);
#ifdef VC108N_DLL_WORKER
    if(w->stop_event && GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
        &worker_module_anchor,&w->module_ref)){
        w->thread=CreateThread(NULL,0,run_worker,w,0,NULL);
        if(!w->thread){FreeLibrary(w->module_ref);w->module_ref=NULL;}
    }
#else
    if(w->stop_event)w->thread=CreateThread(NULL,0,run_worker,w,0,NULL);
#endif
    if(w->thread)return 1; /* means thread launched, not credentials accepted */
    if(w->stop_event){CloseHandle(w->stop_event);w->stop_event=NULL;}
    AcquireSRWLockExclusive(&w->lock);
    (void)vc_worker_request_stop(&w->lifecycle);
    (void)vc_worker_joined(&w->lifecycle,w->generation);
    ReleaseSRWLockExclusive(&w->lock);
    clear_context(w);return 0;
}
int vc_win_worker_stop(vc_win_worker *w,DWORD timeout_ms){
    int joined;
    if(!w||timeout_ms==INFINITE)return 0;
    if(!w->thread)return 1;
    AcquireSRWLockExclusive(&w->lock);
    (void)vc_worker_request_stop(&w->lifecycle);
    ReleaseSRWLockExclusive(&w->lock);
    if(!SetEvent(w->stop_event))return 0;
    if(WaitForSingleObject(w->thread,timeout_ms)!=WAIT_OBJECT_0)return 0;
    AcquireSRWLockExclusive(&w->lock);
    joined=vc_worker_joined(&w->lifecycle,w->generation);
    ReleaseSRWLockExclusive(&w->lock);
    if(!joined)return 0;
    CloseHandle(w->thread);CloseHandle(w->stop_event);w->thread=NULL;w->stop_event=NULL;
#ifdef VC108N_DLL_WORKER
    w->module_ref=NULL; /* worker already released it */
#endif
    clear_context(w);return 1;
}
int vc_win_worker_legacy(vc_win_worker *w){
    int ok;if(!w||w->thread||w->stop_event)return 0;
    AcquireSRWLockExclusive(&w->lock);ok=vc_worker_legacy(&w->lifecycle);ReleaseSRWLockExclusive(&w->lock);return ok;
}
vc_live_result vc_win_worker_select(vc_win_worker *w,vc_state_snapshot *out){
    vc_live_result result;if(!w||!out)return VC_LIVE_UNAVAILABLE;
    AcquireSRWLockShared(&w->lock);
    result=vc_worker_select(&w->lifecycle,GetTickCount64(),out);
    ReleaseSRWLockShared(&w->lock);return result;
}
