#include "state_windows.h"
#include <string.h>

static int verify_mac(const uint8_t *p,size_t n,const uint8_t *mac,void *ctx){
    vc_win_reader *r=(vc_win_reader *)ctx;
    BCRYPT_HASH_HANDLE hash=NULL;
    uint8_t actual[32]={0};
    unsigned i,diff=0;
    int ok=0;
    if(!r||!r->alg||n!=96u)return 0;
    /* Windows 7+ permits NULL object buffer: provider owns hash storage. */
    if(BCryptCreateHash(r->alg,&hash,NULL,0,r->key,32,0)<0)goto end;
    if(BCryptHashData(hash,(PUCHAR)p,(ULONG)n,0)<0)goto end;
    if(BCryptFinishHash(hash,actual,32,0)<0)goto end;
    for(i=0;i<32u;i++)diff|=(unsigned)(actual[i]^mac[i]);
    ok=diff==0u;
end:
    if(hash)BCryptDestroyHash(hash);
    SecureZeroMemory(actual,sizeof(actual));
    return ok;
}
int vc_win_init(vc_win_reader *r,const uint8_t session[16],const uint8_t key[32]){
    unsigned i;uint8_t any=0;
    if(!r||r->alg||!session||!key)return 0;
    for(i=0;i<32u;i++)any|=key[i];
    if(!any||!vc_transport_init(&r->cache,session))return 0;
    if(BCryptOpenAlgorithmProvider(&r->alg,BCRYPT_SHA256_ALGORITHM,NULL,BCRYPT_ALG_HANDLE_HMAC_FLAG)<0){
        SecureZeroMemory(r,sizeof(*r));return 0;
    }
    memcpy(r->key,key,32);return 1;
}
void vc_win_close(vc_win_reader *r){
    if(!r)return;
    if(r->alg)BCryptCloseAlgorithmProvider(r->alg,0);
    SecureZeroMemory(r,sizeof(*r));
}
/* Reject UNC, device paths, relative paths, alternate data streams and dot
 * components. This is not an ancestor ACL or junction security boundary. */
int vc_win_trusted_path_shape(const wchar_t *p){
    wchar_t root[4];const wchar_t *q,*start;
    if(!p||!((p[0]>=L'A'&&p[0]<=L'Z')||(p[0]>=L'a'&&p[0]<=L'z'))||p[1]!=L':'||p[2]!=L'\\'||!p[3])return 0;
    root[0]=p[0];root[1]=L':';root[2]=L'\\';root[3]=0;
    if(GetDriveTypeW(root)!=DRIVE_FIXED)return 0;
    start=p+3;
    for(q=start;;q++){
        if(*q==L':'||*q==L'/'||*q==L'*'||*q==L'?'||*q==L'"'||*q==L'<'||*q==L'>'||*q==L'|'||(*q&&*q<32))return 0;
        if(!*q||*q==L'\\'){
            if(q==start||q[-1]==L'.'||q[-1]==L' ')return 0;
            if(!*q)break;
            start=q+1;
        }
    }
    return 1;
}
static int read_frame(const wchar_t *path,uint8_t frame[VC_TRANSPORT_SIZE]){
    HANDLE f; BY_HANDLE_FILE_INFORMATION info; DWORD count=0,extra_count=0;
    uint8_t extra=0;int ok=0;
    if(!vc_win_trusted_path_shape(path))return 0;
    f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,
        OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT|FILE_FLAG_SEQUENTIAL_SCAN,NULL);
    if(f==INVALID_HANDLE_VALUE)return 0;
    if(GetFileType(f)!=FILE_TYPE_DISK||!GetFileInformationByHandle(f,&info))goto end;
    if(info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))goto end;
    if(info.nFileSizeHigh||info.nFileSizeLow!=VC_TRANSPORT_SIZE)goto end;
    if(!ReadFile(f,frame,VC_TRANSPORT_SIZE,&count,NULL)||count!=VC_TRANSPORT_SIZE)goto end;
    if(!ReadFile(f,&extra,1,&extra_count,NULL)||extra_count!=0)goto end;
    ok=1;
end:
    CloseHandle(f);return ok;
}
vc_win_result vc_win_poll(vc_win_reader *r,const wchar_t *path,vc_state_snapshot *out){
    uint8_t wire[VC_TRANSPORT_SIZE];int accepted=0;uint64_t now;
    if(!r||!r->alg||!out)return VC_WIN_STALE;
    if(read_frame(path,wire)){
        now=GetTickCount64();
        accepted=vc_transport_accept(&r->cache,wire,sizeof(wire),now,verify_mac,r);
    }
    /* Re-evaluate age after I/O and crypto; errors never renew cached tick. */
    now=GetTickCount64();
    if(!vc_transport_get(&r->cache,now,out))return VC_WIN_STALE;
    return accepted?VC_WIN_NEW:VC_WIN_CACHED;
}
