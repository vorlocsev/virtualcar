$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'Use a Visual Studio Developer PowerShell.' }
$out = Join-Path $env:TEMP ('VC108K-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $out | Out-Null
try {
    Push-Location $out
    try {
        & cl.exe /nologo /std:c11 /W4 /WX /O2 (Join-Path $root 'native\vehicle_state_wire.c') (Join-Path $root 'native\live_state_slot.c') (Join-Path $root 'native\diagnostic_state.c') (Join-Path $root 'native\check_accelerator.c') /Fe:check-accelerator.exe
        if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
        & .\check-accelerator.exe (Join-Path $root 'native\accelerator-golden.bin')
        if ($LASTEXITCODE -ne 0) { throw 'Native vector checks failed' }
    } finally { Pop-Location }
} finally { Remove-Item -LiteralPath $out -Recurse -Force }
Push-Location $root
try {
    & dotnet run --project Checks/Checks.csproj --configuration Release
    if ($LASTEXITCODE -ne 0) { throw 'Managed checks failed' }
} finally { Pop-Location }
