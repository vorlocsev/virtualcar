#ifndef VC_STATE_WINDOWS_H
#define VC_STATE_WINDOWS_H
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include "../native/state_transport.h"
/* Owned by one worker thread. Never poll under the J2534 state lock.
 * Zero initialize before first init. Destroy before reuse. */
typedef struct {
    vc_transport_cache cache;
    BCRYPT_ALG_HANDLE alg;
    uint8_t key[32];
} vc_win_reader;
typedef enum { VC_WIN_STALE=0, VC_WIN_CACHED=1, VC_WIN_NEW=2 } vc_win_result;
/* Shape and fixed-drive check only; not an ACL/ancestor validation. */
int vc_win_trusted_path_shape(const wchar_t *path);
int vc_win_init(vc_win_reader *,const uint8_t session[16],const uint8_t key[32]);
void vc_win_close(vc_win_reader *);
/* path from trusted provisioning, NOT from received envelope. Caller secures
 * all ancestor directories and ensures local NTFS, no reparse traversal. */
vc_win_result vc_win_poll(vc_win_reader *,const wchar_t *path,vc_state_snapshot *);
#endif
