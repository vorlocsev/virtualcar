$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'Use an x86 or x64 Visual Studio Developer PowerShell (MSVC + Windows SDK).' }
    $out = Join-Path $env:TEMP ('VC108H-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $out | Out-Null
    try {
        Push-Location $out
        try {
            & cl.exe /nologo /std:c11 /W4 /WX /O2 /D_WIN32_WINNT=0x0A00 (Join-Path $root 'native\vehicle_state_wire.c') (Join-Path $root 'native\state_transport.c') (Join-Path $root 'windows\state_windows.c') (Join-Path $root 'windows\check_windows.c') /Fe:check-windows.exe /link bcrypt.lib
            if ($LASTEXITCODE -ne 0) { throw 'Native Windows build failed' }
        } finally { Pop-Location }
        & (Join-Path $out 'check-windows.exe')
        if ($LASTEXITCODE -ne 0) { throw 'Native Windows checks failed' }
    } finally { Remove-Item -LiteralPath $out -Recurse -Force }
} finally { Pop-Location }
