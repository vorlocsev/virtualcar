$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command cl.exe -ErrorAction SilentlyContinue)) { throw 'Use an x86 or x64 Visual Studio Developer PowerShell (MSVC + Windows SDK).' }
if (-not (Get-Command dotnet.exe -ErrorAction SilentlyContinue)) { throw '.NET 10 SDK required' }
$out = Join-Path $env:TEMP ('VC108L-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $out | Out-Null
try {
    Push-Location $out
    try {
        $sources = @('native\vehicle_state_wire.c','native\state_transport.c','native\session_credentials.c','windows\state_windows.c','windows\session_windows.c','windows\check_session_windows.c') | ForEach-Object { Join-Path $root $_ }
        & cl.exe /nologo /std:c11 /W4 /WX /O2 /D_WIN32_WINNT=0x0A00 $sources /Fe:check-session.exe /link bcrypt.lib crypt32.lib
        if ($LASTEXITCODE -ne 0) { throw 'Native session build failed' }
    } finally { Pop-Location }
    & dotnet.exe run --project (Join-Path $root 'SessionChecks\SessionChecks.csproj') --configuration Release -- (Join-Path $out 'check-session.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Managed/native DPAPI checks failed' }
} finally { Remove-Item -LiteralPath $out -Recurse -Force }
