#include "state_windows.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
/* Public test credentials only. Never use them for deployment. */
static const uint8_t key[32]={1,2,3}, session[16]={4,5,6};
#define REQUIRE(x) do { if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);goto cleanup;} } while(0)
static void put64(uint8_t *p,uint64_t v){unsigned i;for(i=0;i<8;i++)p[i]=(uint8_t)(v>>(8u*i));}
static int sign_frame(uint8_t *w){
    BCRYPT_ALG_HANDLE alg=NULL;NTSTATUS status;
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,NULL,BCRYPT_ALG_HANDLE_HMAC_FLAG)<0)return 0;
    status=BCryptHash(alg,(PUCHAR)key,32,w,96,w+96,32);
    BCryptCloseAlgorithmProvider(alg,0);return status>=0;
}
static int load_golden(uint8_t *w){
    FILE *f=NULL;size_t n;int end,err;
    if(fopen_s(&f,"native/transport-golden.bin","rb")||!f)return 0;
    n=fread(w,1,128,f);end=fgetc(f);err=ferror(f);fclose(f);return n==128&&end==EOF&&!err;
}
static int publish(const wchar_t *path,const uint8_t *w,DWORD n){
    wchar_t tmp[MAX_PATH];DWORD written=0;HANDLE f;int ok;
    if(swprintf_s(tmp,MAX_PATH,L"%ls.stage",path)<0)return 0;
    f=CreateFileW(tmp,GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(f==INVALID_HANDLE_VALUE)return 0;
    ok=WriteFile(f,w,n,&written,NULL)&&written==n&&FlushFileBuffers(f);
    CloseHandle(f);
    if(ok)ok=MoveFileExW(tmp,path,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=0;
    if(!ok)DeleteFileW(tmp);
    return ok;
}
int main(void){
    vc_win_reader reader={0};vc_state_snapshot s={0};uint8_t w[129]={0},original[128];
    wchar_t dir[MAX_PATH]={0},path[MAX_PATH]={0};DWORD length;int rc=1;uint64_t tick;
    REQUIRE(load_golden(w));memcpy(original,w,128);
    /* Independent Python/OpenSSL fixture must reproduce byte-for-byte in BCrypt. */
    REQUIRE(sign_frame(w)&&memcmp(w,original,128)==0);puts("PASS independent HMAC vector");
    REQUIRE(vc_win_init(&reader,session,key));
    length=GetTempPathW(MAX_PATH,dir);REQUIRE(length>0&&length<MAX_PATH);
    REQUIRE(GetTempFileNameW(dir,L"vch",0,path));
    REQUIRE(vc_win_poll(&reader,path,&s)==VC_WIN_STALE);puts("PASS empty file denied");
    tick=GetTickCount64();put64(w+24,tick);REQUIRE(sign_frame(w)&&publish(path,w,128));
    REQUIRE(vc_win_poll(&reader,path,&s)==VC_WIN_NEW&&s.rpm==700&&s.sequence==1);puts("PASS authenticated file");
    REQUIRE(vc_win_poll(&reader,path,&s)==VC_WIN_CACHED&&s.sequence==1);puts("PASS replay cached only");
    put64(w+40,2);w[56]^=1;REQUIRE(publish(path,w,128));
    REQUIRE(vc_win_poll(&reader,path,&s)==VC_WIN_CACHED&&s.sequence==1);w[56]^=1;puts("PASS tampered frame denied");
    REQUIRE(sign_frame(w)&&publish(path,w,129));
    REQUIRE(vc_win_poll(&reader,path,&s)==VC_WIN_CACHED&&s.sequence==1);puts("PASS oversized file denied");
    /* Explicit expiry: do not require a scheduler to hit a specific millisecond. */
    Sleep(1100);REQUIRE(vc_win_poll(&reader,path,&s)==VC_WIN_STALE&&s.sequence==1);puts("PASS stale cache without output mutation");
    put64(w+24,GetTickCount64());REQUIRE(sign_frame(w)&&publish(path,w,128));
    REQUIRE(vc_win_poll(&reader,path,&s)==VC_WIN_NEW&&s.sequence==2);puts("PASS fresh recovery");
    vc_win_close(&reader);REQUIRE(vc_win_poll(&reader,path,&s)==VC_WIN_STALE);puts("PASS close invalidates cache");
    puts("VC108H_WINDOWS=PASS 9/9");rc=0;
cleanup:
    vc_win_close(&reader);if(path[0])DeleteFileW(path);return rc;
}
