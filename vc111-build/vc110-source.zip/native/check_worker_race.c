#include "worker_lifecycle.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#define C(x) do{if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cv=PTHREAD_COND_INITIALIZER;
static vc_worker_lifecycle worker;
static uint64_t generation;
static int entered, release_poll;
static void *late_poll(void *arg){
    vc_state_snapshot s={0};(void)arg;
    s.sequence=1;s.ignition=2;s.engine=2;s.rpm=700;
    C(!pthread_mutex_lock(&lock));entered=1;C(!pthread_cond_signal(&cv));
    while(!release_poll)C(!pthread_cond_wait(&cv,&lock));
    C(!vc_worker_publish(&worker,generation,&s,200,200));
    C(vc_worker_exited(&worker,generation));C(!pthread_mutex_unlock(&lock));return NULL;
}
int main(void){
    pthread_t thread;vc_state_snapshot out={0};uint64_t next=0;
    for(int i=0;i<100;i++){
        C(!pthread_mutex_lock(&lock));entered=release_poll=0;C(vc_worker_begin(&worker,&generation));
        C(!pthread_create(&thread,NULL,late_poll,NULL));
        while(!entered)C(!pthread_cond_wait(&cv,&lock));
        C(vc_worker_request_stop(&worker));C(vc_worker_select(&worker,200,&out)==VC_LIVE_UNAVAILABLE);
        C(!vc_worker_begin(&worker,&next));C(!vc_worker_legacy(&worker));
        release_poll=1;C(!pthread_cond_signal(&cv));C(!pthread_mutex_unlock(&lock));
        C(!pthread_join(thread,NULL));C(!pthread_mutex_lock(&lock));
        C(vc_worker_joined(&worker,generation));C(vc_worker_select(&worker,200,&out)==VC_LIVE_UNAVAILABLE);
        C(!pthread_mutex_unlock(&lock));
    }
    puts("VC108M_LATE_PUBLISH=PASS 100/100");return 0;
}
