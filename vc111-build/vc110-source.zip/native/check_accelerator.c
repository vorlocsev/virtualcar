#include "vehicle_state_wire.h"
#include "diagnostic_state.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static void expect(vc_diag_context *c,uint16_t did,const uint8_t *bytes,size_t len){
    uint8_t out[4]={0};size_t n=0;
    assert(vc_diag_read(c,VC_DIAG_ECM,did,out,sizeof(out),&n)==VC_DIAG_VALUE);
    assert(n==len&&!memcmp(out,bytes,len));
}
#define EXPECT(c,d,...) do {const uint8_t bytes[]={__VA_ARGS__};expect(c,d,bytes,sizeof(bytes));}while(0)
int main(int argc,char **argv){
    uint8_t wire[64];vc_state_snapshot s={0};vc_live_slot slot={0};vc_diag_context c={0};uint64_t gen=0;
    if(argc!=2)return 2;
    FILE *f=fopen(argv[1],"rb");if(!f)return 3;
    size_t n=fread(wire,1,sizeof(wire),f);int extra=fgetc(f);fclose(f);
    assert(n==64&&extra==EOF&&vc_state_decode(wire,n,0,&s));
    assert(s.rpm==4500&&s.pedal_permille==1000&&s.speed_kph==0);puts("PASS full pedal VCST decode");
    assert(vc_live_begin(&slot,1,&gen)&&vc_live_publish(&slot,gen,&s,1000,1000));vc_diag_capture(&c,&slot,1000);
    EXPECT(&c,0xDA48,0x45,0x8c,0xa0,0x00);EXPECT(&c,0xF40C,0x46,0x50);puts("PASS rpm encodings");
    EXPECT(&c,0xD9AC,0x03,0xe8);EXPECT(&c,0xD9AD,0x03,0xe8);EXPECT(&c,0xF449,0xff);EXPECT(&c,0xF44A,0xff);puts("PASS pedal encodings");
    EXPECT(&c,0xF404,0xd9);EXPECT(&c,0xF443,0,0xd9);puts("PASS load encodings");
    EXPECT(&c,0xD994,0x42,0x82,0,0);EXPECT(&c,0xF410,0x19,0x64);EXPECT(&c,0xF40B,95);puts("PASS MAF and MAP encodings");
    EXPECT(&c,0xF40D,0);EXPECT(&c,0xD99B,0xd0);EXPECT(&c,0x120D,0xb3,0x33);puts("PASS unchanged speed coolant voltage");
    puts("VC108K_NATIVE_VECTOR=PASS 6/6");return 0;
}
