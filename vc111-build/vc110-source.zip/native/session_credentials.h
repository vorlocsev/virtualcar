#ifndef VC_SESSION_CREDENTIALS_H
#define VC_SESSION_CREDENTIALS_H
#include <stddef.h>
#include <stdint.h>
#define VC_CREDENTIAL_SIZE 56u
/* Plaintext exists only in trusted process memory, never on disk.
 * expected_session comes from trusted provisioning, not packet contents. */
int vc_credentials_decode(const uint8_t *wire,size_t length,
    const uint8_t expected_session[16],uint8_t key_out[32]);
#endif
