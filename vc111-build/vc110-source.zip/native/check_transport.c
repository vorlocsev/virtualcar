/* Linux reference harness only; OpenSSL is not a proposed dependency of the Windows DLL. */
#include "state_transport.h"
#include <openssl/hmac.h>
#include <openssl/crypto.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
static const uint8_t key[32]={1,2,3}; /* public test credential, NEVER deploy */
static const uint8_t session[16]={4,5,6};
static int verify(const uint8_t *p,size_t n,const uint8_t *mac,void *ctx){
    uint8_t actual[32];unsigned len=0;(void)ctx;
    return HMAC(EVP_sha256(),key,32,p,n,actual,&len)!=NULL&&len==32&&CRYPTO_memcmp(actual,mac,32)==0;
}
static void sign(uint8_t *w){unsigned n=0;uint8_t mac[32];assert(HMAC(EVP_sha256(),key,32,w,96,mac,&n)&&n==32);memcpy(w+96,mac,32);}
static int readfile(const char *p,uint8_t *w){FILE *f=fopen(p,"rb");size_t n;int extra,err;if(!f)return 0;n=fread(w,1,128,f);extra=fgetc(f);err=ferror(f);fclose(f);return n==128&&extra==EOF&&!err;}
int main(int argc,char **argv){
    uint8_t w[128],x[128];vc_transport_cache c;vc_state_snapshot s;assert(vc_transport_init(&c,session));
    if(argc==3&&!strcmp(argv[1],"stream")){
        unsigned seen=0;char line[32];while(fgets(line,sizeof(line),stdin)){
            uint64_t now=(uint64_t)strtoull(line,NULL,10);
            if(readfile(argv[2],w)&&vc_transport_accept(&c,w,128,now,verify,NULL))seen++;
            if(vc_transport_get(&c,now,&s))printf("%llu %u\n",(unsigned long long)s.sequence,s.rpm);else puts("STALE");fflush(stdout);
        }fprintf(stderr,"accepted=%u\n",seen);return 0;
    }
    assert(argc==2&&readfile(argv[1],w));
    assert(!vc_transport_get(&c,1000,&s));
    assert(vc_transport_accept(&c,w,128,1000,verify,NULL)&&vc_transport_get(&c,1000,&s)&&s.rpm==700);puts("PASS golden authenticated envelope");
    assert(!vc_transport_accept(&c,w,127,1000,verify,NULL)&&!vc_transport_accept(&c,w,129,1000,verify,NULL));puts("PASS bounded length");
    memcpy(x,w,128);x[56]^=1;assert(!vc_transport_accept(&c,x,128,1000,verify,NULL));puts("PASS tampered payload");
    memcpy(x,w,128);x[8]^=1;sign(x);assert(!vc_transport_accept(&c,x,128,1000,verify,NULL));puts("PASS wrong session");
    assert(!vc_transport_accept(&c,w,128,1000,verify,NULL));puts("PASS replay denied");
    memcpy(x,w,128);x[40]=2;x[24]=0xe9;sign(x);assert(!vc_transport_accept(&c,x,128,1000,verify,NULL)); /* tick 1001 */
    memcpy(x,w,128);x[40]=2;x[24]=0xe7;sign(x);assert(!vc_transport_accept(&c,x,128,1000,verify,NULL));puts("PASS future and regressed clock");
    memcpy(x,w,128);x[40]=2;x[48]=0;sign(x);assert(!vc_transport_accept(&c,x,128,1000,verify,NULL));assert(vc_transport_get(&c,2000,&s)&&s.sequence==1&&s.rpm==700);puts("PASS invalid VCST preserves prior state");
    assert(!vc_transport_get(&c,2001,&s)&&!vc_transport_accept(&c,w,128,2001,verify,NULL));puts("PASS expiry without replay extension");
    memcpy(x,w,128);x[40]=2;x[24]=0xd1;x[25]=7;sign(x);assert(vc_transport_accept(&c,x,128,2001,verify,NULL)&&vc_transport_get(&c,2001,&s)&&s.sequence==2);puts("PASS fresh state after expiry");
    puts("VC108G_NATIVE=PASS 9/9");return 0;
}
