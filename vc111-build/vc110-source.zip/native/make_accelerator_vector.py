"""Independent golden VCST warm engine, 100% pedal, no vehicle movement."""
import struct
from pathlib import Path
path = Path(__file__).with_name('accelerator-golden.bin')
path.write_bytes(struct.pack('<4sHHQBBH11i', b'VCST', 1, 64, 1, 2, 2, 0,
    14000, 4500, 0, 1000, 850, 6500, 100, 95, 90, 30, 45))
