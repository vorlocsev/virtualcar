#include "diagnostic_state.h"
void vc_diag_capture(vc_diag_context *c,const vc_live_slot *s,uint64_t now){
    if(c)c->mode=vc_live_select(s,now,&c->snapshot);
}
static unsigned ecm_length(uint16_t did){
    switch(did){
    case 0xDA48:case 0xD994:return 4;
    case 0x120D:case 0xF40C:case 0xD9AC:case 0xD9AD:case 0xF410:case 0xF443:case 0xDA47:return 2;
    case 0xD998:case 0xD99B:case 0xF40D:case 0xF40F:case 0xD9B8:case 0xF404:case 0xF405:
    case 0xF433:case 0xF449:case 0xF44A:case 0xF40B:case 0xD9A4:return 1;
    default:return 0;
    }
}
/* Integer-only candidate binary32 encoding, matching PR511's encoding logic. */
static uint32_t float_ratio(uint32_t num,uint32_t den){
    uint32_t frac=0,rem,i;int exponent=127;
    if(!num)return 0;
    while(num<den){num*=2;exponent--;}
    while(num>=2*den){den*=2;exponent++;}
    rem=num-den;
    for(i=0;i<23;i++){rem*=2;frac<<=1;if(rem>=den){frac|=1;rem-=den;}}
    if(rem*2>den||(rem*2==den&&(frac&1)))frac++;
    return ((uint32_t)exponent<<23)+frac;
}
static uint32_t temp_scaled(int32_t t){return ((uint32_t)(t+40)*8+2)/5;}
static uint32_t ecm_value(const vc_state_snapshot *s,uint16_t did){
    switch(did){
    case 0x120D:{uint32_t x=(s->battery_mv*65536u+10000u)/20000u;return x>65535u?65535u:x;}
    case 0xD998:return temp_scaled(s->intake_c);
    case 0xD99B:return temp_scaled(s->coolant_c);
    case 0xDA48:return float_ratio(s->rpm,1);
    case 0xF40C:return s->rpm*4;
    case 0xF40D:return s->speed_kph;
    case 0xF40F:return (uint32_t)(s->intake_c+40);
    case 0xD9AC:case 0xD9AD:return s->pedal_permille;
    case 0xD9B8:return temp_scaled(s->ecm_c);
    case 0xF404:case 0xF443:return (s->load_permille*255+500)/1000;
    case 0xF405:return (uint32_t)(s->coolant_c+40);
    case 0xF410:return s->maf_centi_gps;
    case 0xD994:return float_ratio(s->maf_centi_gps,100);
    case 0xF433:return s->ambient_kpa;
    case 0xF449:case 0xF44A:return (s->pedal_permille*255+500)/1000;
    case 0xF40B:return s->manifold_kpa;
    case 0xD9A4:return s->ambient_kpa*2;
    case 0xDA47:return (s->manifold_kpa*65536+250)/500;
    default:return 0;
    }
}
vc_diag_result vc_diag_read(const vc_diag_context *c,vc_diag_target target,uint16_t did,uint8_t *out,size_t cap,size_t *length){
    unsigned n=target==VC_DIAG_ECM?ecm_length(did):target==VC_DIAG_CEM&&(did==0xDD02||did==0xA45F)?1u:0u;
    uint32_t raw;unsigned i;
    if(!n)return VC_DIAG_NOT_OWNED;
    if(!c)return VC_DIAG_UNAVAILABLE;
    if(c->mode==VC_LIVE_LEGACY)return VC_DIAG_LEGACY;
    if(c->mode!=VC_LIVE_EXTERNAL||!out||!length||cap<n)return VC_DIAG_UNAVAILABLE;
    if(target==VC_DIAG_ECM)raw=ecm_value(&c->snapshot,did);
    else if(did==0xA45F){
        /* Only existing lab observations 0/II. Do not invent accessory bits. */
        if(c->snapshot.ignition==1)return VC_DIAG_UNAVAILABLE;
        raw=c->snapshot.ignition==2?7u:4u;
    }else raw=(c->snapshot.battery_mv+125u)/250u; /* candidate quantization; compare exact helper before integration */
    for(i=0;i<n;i++)out[i]=(uint8_t)(raw>>(8u*(n-i-1u)));
    *length=n;return VC_DIAG_VALUE;
}
vc_diag_result vc_diag_battery(const vc_diag_context *c,uint32_t *mv){
    if(!c)return VC_DIAG_UNAVAILABLE;
    if(c->mode==VC_LIVE_LEGACY)return VC_DIAG_LEGACY;
    if(c->mode!=VC_LIVE_EXTERNAL||!mv)return VC_DIAG_UNAVAILABLE;
    *mv=c->snapshot.battery_mv;return VC_DIAG_VALUE;
}
