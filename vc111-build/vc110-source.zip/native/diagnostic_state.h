#ifndef VC_DIAGNOSTIC_STATE_H
#define VC_DIAGNOSTIC_STATE_H
#include "live_state_slot.h"
/* Capture once under the owner's state lock. This is a local simulation
 * adapter, not a CAN router. Existing route/opt-in checks remain mandatory. */
typedef struct { vc_live_result mode; vc_state_snapshot snapshot; } vc_diag_context;
typedef enum { VC_DIAG_LEGACY=0, VC_DIAG_NOT_OWNED=1, VC_DIAG_UNAVAILABLE=2, VC_DIAG_VALUE=3 } vc_diag_result;
typedef enum { VC_DIAG_ECM=1, VC_DIAG_CEM=2 } vc_diag_target;
void vc_diag_capture(vc_diag_context *, const vc_live_slot *, uint64_t now);
/* For recognized local live DIDs only. Output is raw value, not UDS frame.
 * On all non-VALUE returns output and length are unchanged. The caller must
 * not fall through to legacy values on UNAVAILABLE. */
vc_diag_result vc_diag_read(const vc_diag_context *, vc_diag_target, uint16_t did,
                            uint8_t *out, size_t capacity, size_t *length);
vc_diag_result vc_diag_battery(const vc_diag_context *, uint32_t *mv);
#endif
