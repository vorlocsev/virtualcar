#include "worker_lifecycle.h"
#include <stdio.h>
#define C(x) do{if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);return 1;}}while(0)
int main(void){
    vc_worker_lifecycle w={0};vc_state_snapshot s={0},out={0};uint64_t a=0,b=0;
    s.sequence=1;s.ignition=2;s.engine=2;s.rpm=700;s.battery_mv=14000;s.coolant_c=90;
    C(vc_worker_select(&w,0,&out)==VC_LIVE_LEGACY);puts("1 legacy default");
    C(vc_worker_begin(&w,&a)&&a!=0&&vc_worker_select(&w,100,&out)==VC_LIVE_UNAVAILABLE);puts("2 explicit start unavailable until data");
    C(!vc_worker_begin(&w,&b)&&!vc_worker_legacy(&w)&&!vc_worker_joined(&w,a));puts("3 concurrent start/legacy/early join denied");
    C(vc_worker_publish(&w,a,&s,100,100)&&vc_worker_select(&w,100,&out)==VC_LIVE_EXTERNAL&&out.rpm==700);puts("4 publish");
    C(vc_worker_select(&w,1100,&out)==VC_LIVE_EXTERNAL&&vc_worker_select(&w,1101,&out)==VC_LIVE_UNAVAILABLE);puts("5 expiry without worker progress");
    C(vc_worker_request_stop(&w)&&vc_worker_request_stop(&w));s.sequence=2;
    C(!vc_worker_publish(&w,a,&s,1101,1101)&&vc_worker_select(&w,1101,&out)==VC_LIVE_UNAVAILABLE);puts("6 stop immediately revokes in-flight publication");
    C(!vc_worker_begin(&w,&b)&&!vc_worker_legacy(&w)&&!vc_worker_joined(&w,a+1));puts("7 timeout retains ownership until exact join");
    C(vc_worker_exited(&w,a)&&vc_worker_joined(&w,a)&&vc_worker_select(&w,1101,&out)==VC_LIVE_UNAVAILABLE);puts("8 joined external stays unavailable");
    C(vc_worker_begin(&w,&b)&&b!=a&&!vc_worker_publish(&w,a,&s,1102,1102)&&!vc_worker_exited(&w,a)&&!vc_worker_joined(&w,a));puts("9 old worker isolated");
    s.sequence=1;C(vc_worker_publish(&w,b,&s,1102,1102)&&vc_worker_exited(&w,b)&&vc_worker_select(&w,1102,&out)==VC_LIVE_UNAVAILABLE);puts("10 unexpected exit revokes data");
    C(vc_worker_joined(&w,b)&&vc_worker_legacy(&w)&&vc_worker_select(&w,1102,&out)==VC_LIVE_LEGACY);puts("11 only explicit owner may restore legacy");
    w.slot.generation=UINT64_MAX;C(!vc_worker_begin(&w,&b)&&vc_worker_select(&w,1102,&out)==VC_LIVE_UNAVAILABLE);puts("12 exhaustion fails closed");
    puts("VC108M_LIFECYCLE=PASS 12/12");return 0;
}
