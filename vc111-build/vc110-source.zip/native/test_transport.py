import hashlib,hmac,struct,subprocess,tempfile,pathlib,os
base=pathlib.Path(__file__).resolve().parent
key=bytes([1,2,3])+bytes(29);session=bytes([4,5,6])+bytes(13)
def packet(seq,tick):
    v=bytearray((base/'golden.bin').read_bytes());struct.pack_into('<Q',v,8,seq)
    head=b'VCTP'+bytes([1,0,128,0])+session+struct.pack('<Q',tick)+v
    return head+hmac.digest(key,head,'sha256')
(base/'transport-golden.bin').write_bytes(packet(1,1000))
with tempfile.TemporaryDirectory() as td:
    td=pathlib.Path(td);exe=td/'check';p=td/'state.bin'
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-pedantic','-fsanitize=undefined',str(base/'vehicle_state_wire.c'),str(base/'state_transport.c'),str(base/'check_transport.c'),'-lcrypto','-o',str(exe)],check=True)
    subprocess.run([exe,base/'transport-golden.bin'],check=True)
    child=subprocess.Popen([exe,'stream',p],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    def read(tick):
        child.stdin.write(f'{tick}\n');child.stdin.flush();return child.stdout.readline().strip()
    assert read(1000)=='STALE'
    for i in range(1,501):
        tmp=td/'staging';tmp.write_bytes(packet(i,1000+i));os.replace(tmp,p)
        assert read(1000+i)==f'{i} 700'
    assert read(2500)=='500 700';assert read(2501)=='STALE'
    child.stdin.close();assert child.wait()==0
    print('VC108G_PROCESS=PASS 500/500 + expiry')
