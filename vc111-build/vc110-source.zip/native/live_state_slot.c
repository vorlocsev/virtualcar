#include "live_state_slot.h"
int vc_live_begin(vc_live_slot *s,int external,uint64_t *generation){
    if(!s||!generation||(external!=0&&external!=1))return 0;
    s->valid=0;s->source_tick=0;
    if(s->generation>=UINT64_MAX-1u){s->generation=UINT64_MAX;s->external=1;return 0;}
    s->generation++;s->external=external;*generation=s->generation;return 1;
}
static int valid_state(const vc_state_snapshot *v){
    return v->sequence && v->ignition<=2u && v->engine<=VC_ENGINE_RUNNING &&
        (v->ignition==2u||v->engine==VC_ENGINE_OFF) &&
        (v->engine!=VC_ENGINE_OFF||v->rpm==0u) &&
        v->battery_mv<=20000u && v->rpm<=16383u && v->speed_kph<=255u &&
        v->pedal_permille<=1000u && v->load_permille<=1000u && v->maf_centi_gps<=65535u &&
        v->ambient_kpa<=127u && v->manifold_kpa<=255u &&
        v->coolant_c>=-40 && v->coolant_c<=119 && v->intake_c>=-40 && v->intake_c<=119 &&
        v->ecm_c>=-40 && v->ecm_c<=119;
}
int vc_live_publish(vc_live_slot *s,uint64_t generation,const vc_state_snapshot *v,uint64_t tick,uint64_t now){
    if(!s||!v||!s->external||!generation||generation!=s->generation||s->generation==UINT64_MAX||
       !valid_state(v)||tick>now||now-tick>VC_TRANSPORT_MAX_AGE_MS||
       (s->valid&&(v->sequence<=s->state.sequence||tick<s->source_tick)))return 0;
    s->state=*v;s->source_tick=tick;s->valid=1;return 1;
}
vc_live_result vc_live_select(const vc_live_slot *s,uint64_t now,vc_state_snapshot *out){
    if(!s||!out)return VC_LIVE_UNAVAILABLE;
    if(!s->external)return VC_LIVE_LEGACY;
    if(!s->valid||now<s->source_tick||now-s->source_tick>VC_TRANSPORT_MAX_AGE_MS)return VC_LIVE_UNAVAILABLE;
    *out=s->state;return VC_LIVE_EXTERNAL;
}
