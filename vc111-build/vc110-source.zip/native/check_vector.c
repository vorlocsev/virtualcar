#include "vehicle_state_wire.h"
#include <stdio.h>
int main(int argc,char **argv){uint8_t w[64];vc_state_snapshot s={0};if(argc!=2)return 2;FILE *f=fopen(argv[1],"rb");if(!f)return 3;size_t n=fread(w,1,sizeof(w),f);int extra=fgetc(f);fclose(f);if(n!=64||extra!=EOF||!vc_state_decode(w,n,0,&s)||s.sequence!=1||s.ignition!=2||s.engine!=2||s.rpm!=700||s.battery_mv!=14000||s.coolant_c!=90||s.maf_centi_gps!=550)return 4;puts("VC108F_NATIVE_VECTOR=PASS");return 0;}
