#ifndef VC_BYTE_EQUAL_H
#define VC_BYTE_EQUAL_H
#include <stddef.h>
/* Nonsecret header/session matching; MAC check remains constant-time in BCrypt adapter. */
static inline int vc_bytes_equal(const unsigned char *a,const unsigned char *b,size_t n){
    size_t i;for(i=0;i<n;i++)if(a[i]!=b[i])return 0;return 1;
}
#endif
