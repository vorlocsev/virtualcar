#ifndef VC_LIVE_STATE_SLOT_H
#define VC_LIVE_STATE_SLOT_H
#include "state_transport.h"
/* All calls are serialized by the owning DLL state lock. No I/O here.
 * Generation binds publication to a trusted worker lifetime. Never allocate
 * a fresh generation on malformed data or timeout. Zero-init once. */
typedef enum { VC_LIVE_LEGACY=0, VC_LIVE_UNAVAILABLE=1, VC_LIVE_EXTERNAL=2 } vc_live_result;
typedef struct {
    uint64_t generation, source_tick;
    vc_state_snapshot state;
    int external, valid;
} vc_live_slot;
/* Called only by owner at trusted lifecycle transition (open/close).
 * On generation exhaustion, fail closed in external mode; no ABA. */
int vc_live_begin(vc_live_slot *s,int external,uint64_t *generation);
/* Worker publishes only NEW authenticated packets, after I/O outside lock.
 * source_tick is original VCTP time, never worker receipt time. */
int vc_live_publish(vc_live_slot *s,uint64_t generation,const vc_state_snapshot *v,
                    uint64_t source_tick,uint64_t now);
/* Called under state lock immediately before constructing a diagnostic reply.
 * Output untouched for LEGACY or UNAVAILABLE. No automatic fallback. */
vc_live_result vc_live_select(const vc_live_slot *s,uint64_t now,vc_state_snapshot *out);
#endif
