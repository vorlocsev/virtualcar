#ifndef VC_STATE_TRANSPORT_H
#define VC_STATE_TRANSPORT_H
#include "vehicle_state_wire.h"
#define VC_TRANSPORT_SIZE 128u
#define VC_TRANSPORT_MAX_AGE_MS 1000u
/* Callback verifies HMAC-SHA256 of first 96 bytes against final 32, using
 * a separately provisioned 32-byte key. Must compare MAC in constant time. */
typedef int (*vc_mac_verify)(const uint8_t *, size_t, const uint8_t *, void *);
typedef struct {
    uint8_t session[16];
    uint64_t accepted_tick;
    vc_state_snapshot snapshot;
    int valid;
} vc_transport_cache;
/* Call under the same lock as the diagnostic state. Reinitialize only on
 * trusted session establishment, not on file contents or failure. */
int vc_transport_init(vc_transport_cache *, const uint8_t session[16]);
int vc_transport_accept(vc_transport_cache *, const uint8_t *, size_t, uint64_t now, vc_mac_verify, void *);
int vc_transport_get(const vc_transport_cache *, uint64_t now, vc_state_snapshot *);
#endif
