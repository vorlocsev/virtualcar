#include "diagnostic_state.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static vc_state_snapshot state(uint64_t seq){
    vc_state_snapshot v={0};v.sequence=seq;v.ignition=2;v.engine=VC_ENGINE_RUNNING;
    v.battery_mv=14000;v.rpm=700;v.load_permille=180;v.maf_centi_gps=550;v.ambient_kpa=100;v.manifold_kpa=35;
    v.coolant_c=90;v.intake_c=30;v.ecm_c=45;return v;
}
static void expect(vc_diag_context *c,vc_diag_target target,uint16_t did,const uint8_t *bytes,size_t len){
    uint8_t out[4]={0};size_t n=0;assert(vc_diag_read(c,target,did,out,sizeof(out),&n)==VC_DIAG_VALUE);assert(n==len&&!memcmp(out,bytes,len));
}
#define EXPECT(c,t,d,...) do { const uint8_t bytes[]={__VA_ARGS__};expect(c,t,d,bytes,sizeof(bytes)); } while(0)
#define PASS(s) puts("PASS " s)
int main(void){
    vc_live_slot slot={0};vc_diag_context c={0};vc_state_snapshot s=state(1);uint64_t g=0;uint8_t out[4]={0xAA};size_t len=99;uint32_t mv=99;
    vc_diag_capture(&c,&slot,1000);assert(vc_diag_read(&c,VC_DIAG_ECM,0xDA48,out,4,&len)==VC_DIAG_LEGACY&&out[0]==0xAA&&len==99);PASS("legacy unchanged");
    assert(vc_live_begin(&slot,1,&g));vc_diag_capture(&c,&slot,1000);assert(vc_diag_read(&c,VC_DIAG_ECM,0xDA48,out,4,&len)==VC_DIAG_UNAVAILABLE&&vc_diag_battery(&c,&mv)==VC_DIAG_UNAVAILABLE&&mv==99);PASS("external startup fails closed");
    assert(vc_live_publish(&slot,g,&s,1000,1000));vc_diag_capture(&c,&slot,1000);
    EXPECT(&c,VC_DIAG_ECM,0xDA48,0x44,0x2F,0,0);EXPECT(&c,VC_DIAG_ECM,0xF40C,0x0A,0xF0);PASS("RPM observed and alternative encoding");
    EXPECT(&c,VC_DIAG_ECM,0xD994,0x40,0xB0,0,0);EXPECT(&c,VC_DIAG_ECM,0xF410,0x02,0x26);EXPECT(&c,VC_DIAG_ECM,0xD99B,0xD0);EXPECT(&c,VC_DIAG_ECM,0xF405,0x82);PASS("MAF and coolant vectors");
    EXPECT(&c,VC_DIAG_ECM,0x120D,0xB3,0x33);EXPECT(&c,VC_DIAG_CEM,0xDD02,0x38);assert(vc_diag_battery(&c,&mv)==VC_DIAG_VALUE&&mv==14000);PASS("ECM CEM battery consistency");
    EXPECT(&c,VC_DIAG_CEM,0xA45F,7);s.sequence++;s.ignition=0;s.engine=0;s.rpm=0;s.battery_mv=12500;assert(vc_live_publish(&slot,g,&s,1010,1010));
    EXPECT(&c,VC_DIAG_CEM,0xA45F,7);EXPECT(&c,VC_DIAG_ECM,0xDA48,0x44,0x2F,0,0);vc_diag_capture(&c,&slot,1010);EXPECT(&c,VC_DIAG_CEM,0xA45F,4);EXPECT(&c,VC_DIAG_ECM,0xDA48,0,0,0,0);EXPECT(&c,VC_DIAG_CEM,0xDD02,0x32);PASS("coherent capture and next request update");
    s.sequence++;s.ignition=1;assert(vc_live_publish(&slot,g,&s,1020,1020));vc_diag_capture(&c,&slot,1020);assert(vc_diag_read(&c,VC_DIAG_CEM,0xA45F,out,4,&len)==VC_DIAG_UNAVAILABLE);PASS("no invented accessory bits");
    assert(vc_diag_read(&c,VC_DIAG_CEM,0xF110,out,4,&len)==VC_DIAG_NOT_OWNED&&vc_diag_read(&c,VC_DIAG_ECM,0xF190,out,4,&len)==VC_DIAG_NOT_OWNED);PASS("identity not intercepted");
    assert(vc_diag_read(&c,VC_DIAG_ECM,0xDA48,out,3,&len)==VC_DIAG_UNAVAILABLE&&len==99&&out[0]==0xAA);PASS("bounded output");
    vc_diag_capture(&c,&slot,2021);assert(vc_diag_read(&c,VC_DIAG_CEM,0xDD02,out,4,&len)==VC_DIAG_UNAVAILABLE&&vc_diag_read(&c,VC_DIAG_ECM,0xDA48,out,4,&len)==VC_DIAG_UNAVAILABLE&&vc_diag_battery(&c,&mv)==VC_DIAG_UNAVAILABLE);PASS("expiry across all consumers");
    s=state(4);s.pedal_permille=500;s.speed_kph=60;s.coolant_c=-40;assert(vc_live_publish(&slot,g,&s,2022,2022));vc_diag_capture(&c,&slot,2022);EXPECT(&c,VC_DIAG_ECM,0xD9AC,1,0xF4);EXPECT(&c,VC_DIAG_ECM,0xF449,128);EXPECT(&c,VC_DIAG_ECM,0xF40D,60);EXPECT(&c,VC_DIAG_ECM,0xF405,0);PASS("fresh recovery and parameter boundaries");
    assert(vc_live_begin(&slot,0,&g));vc_diag_capture(&c,&slot,2023);assert(vc_diag_read(&c,VC_DIAG_CEM,0xDD02,out,4,&len)==VC_DIAG_LEGACY);PASS("explicit return to legacy");
    puts("VC108J_DIAG=PASS 12/12");return 0;
}
