#include "session_credentials.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){
    uint8_t w[56]={ 'V','C','K','1',1,0,56,0 },id[16]={1},key[32],old[32];
    w[8]=1;w[24]=2;memset(key,0xA5,32);assert(vc_credentials_decode(w,56,id,key)&&key[0]==2&&key[31]==0);puts("PASS exact descriptor");
    memcpy(old,key,32);assert(!vc_credentials_decode(w,55,id,key)&&!vc_credentials_decode(w,57,id,key));puts("PASS size bounds");
    w[4]=2;assert(!vc_credentials_decode(w,56,id,key));w[4]=1;w[5]=1;assert(!vc_credentials_decode(w,56,id,key));w[5]=0;w[7]=1;assert(!vc_credentials_decode(w,56,id,key));w[7]=0;puts("PASS version reserved");
    w[0]='X';assert(!vc_credentials_decode(w,56,id,key));w[0]='V';w[6]=55;assert(!vc_credentials_decode(w,56,id,key));w[6]=56;puts("PASS magic length");
    id[1]=1;assert(!vc_credentials_decode(w,56,id,key));id[1]=0;puts("PASS session binding");
    w[8]=id[0]=0;assert(!vc_credentials_decode(w,56,id,key));w[8]=id[0]=1;puts("PASS empty session");
    w[24]=0;assert(!vc_credentials_decode(w,56,id,key));puts("PASS empty key");
    assert(!vc_credentials_decode(NULL,56,id,key)&&!vc_credentials_decode(w,56,NULL,key)&&!vc_credentials_decode(w,56,id,NULL)&&!memcmp(key,old,32));puts("PASS no mutation on failure");
    puts("VC108L_CREDENTIAL_WIRE=PASS 8/8");return 0;
}
