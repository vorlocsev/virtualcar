#ifndef VC108_VEHICLE_STATE_WIRE_H
#define VC108_VEHICLE_STATE_WIRE_H
#include <stdint.h>
#include <stddef.h>
/* Experimental local simulation snapshot, not an ECU command. Wire: LE. */
#define VC_STATE_WIRE_SIZE 64u
#define VC_STATE_WIRE_VERSION 1u
#define VC_ENGINE_OFF 0u
#define VC_ENGINE_CRANKING 1u
#define VC_ENGINE_RUNNING 2u

typedef struct {
    uint64_t sequence;
    uint8_t ignition, engine;
    uint32_t battery_mv, rpm, speed_kph, pedal_permille, load_permille, maf_centi_gps;
    uint32_t ambient_kpa, manifold_kpa;
    int32_t coolant_c, intake_c, ecm_c;
} vc_state_snapshot;

/* last_sequence belongs to a separately authenticated publisher instance.
 * No I/O, allocation, locking or native struct serialization. On rejection
 * caller's previous snapshot is unchanged. Freshness/lifetime is transport policy. */
int vc_state_decode(const uint8_t *wire, size_t length, uint64_t last_sequence,
                    vc_state_snapshot *out);
#endif
