#include "state_transport.h"
#include <string.h>
#include "byte_equal.h"
static uint64_t read64(const uint8_t *p) {
    uint64_t v=0; unsigned i; for(i=0;i<8;i++) v|=(uint64_t)p[i]<<(8u*i); return v;
}
int vc_transport_init(vc_transport_cache *c,const uint8_t session[16]) {
    unsigned i; uint8_t any=0; if(!c||!session)return 0;
    for(i=0;i<16;i++) any|=session[i];
    if(!any)return 0;
    memset(c,0,sizeof(*c)); memcpy(c->session,session,16);return 1;
}
int vc_transport_accept(vc_transport_cache *c,const uint8_t *w,size_t n,uint64_t now,vc_mac_verify verify,void *ctx) {
    uint64_t t; vc_state_snapshot next;
    if(!c||!w||!verify||n!=VC_TRANSPORT_SIZE)return 0;
    if(!vc_bytes_equal(w,(const unsigned char *)"VCTP",4)||w[4]!=1||w[5]||w[6]!=VC_TRANSPORT_SIZE||w[7]||!vc_bytes_equal(w+8,c->session,16))return 0;
    if(!verify(w,96,w+96,ctx))return 0;
    t=read64(w+24);
    if(t>now||now-t>VC_TRANSPORT_MAX_AGE_MS||(c->valid&&t<c->accepted_tick))return 0;
    if(!vc_state_decode(w+32,VC_STATE_WIRE_SIZE,c->valid?c->snapshot.sequence:0,&next))return 0;
    c->snapshot=next;c->accepted_tick=t;c->valid=1;return 1;
}
int vc_transport_get(const vc_transport_cache *c,uint64_t now,vc_state_snapshot *out) {
    if(!c||!out||!c->valid||now<c->accepted_tick||now-c->accepted_tick>VC_TRANSPORT_MAX_AGE_MS)return 0;
    *out=c->snapshot;return 1;
}
