#include "vehicle_state_wire.h"
static uint32_t read32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}
static int32_t read_temp(uint32_t x) {
    /* Valid temperature range is small. Avoid implementation-defined signed casts. */
    if (x <= 119u) return (int32_t)x;
    if (x >= UINT32_MAX-39u) return -1-(int32_t)(UINT32_MAX-x);
    return 120;
}
int vc_state_decode(const uint8_t *w, size_t n, uint64_t last, vc_state_snapshot *out) {
    vc_state_snapshot s = {0};
    if (!w || !out || n != VC_STATE_WIRE_SIZE) return 0;
    if (w[0]!='V'||w[1]!='C'||w[2]!='S'||w[3]!='T'||w[4]!=VC_STATE_WIRE_VERSION||w[5]||w[6]!=VC_STATE_WIRE_SIZE||w[7]||w[18]||w[19]) return 0;
    s.sequence=(uint64_t)read32(w+8)|((uint64_t)read32(w+12)<<32);
    s.ignition=w[16]; s.engine=w[17];
    s.battery_mv=read32(w+20); s.rpm=read32(w+24); s.speed_kph=read32(w+28);
    s.pedal_permille=read32(w+32); s.load_permille=read32(w+36); s.maf_centi_gps=read32(w+40);
    s.ambient_kpa=read32(w+44); s.manifold_kpa=read32(w+48);
    s.coolant_c=read_temp(read32(w+52)); s.intake_c=read_temp(read32(w+56)); s.ecm_c=read_temp(read32(w+60));
    if (!s.sequence || s.sequence<=last || s.ignition>2 || s.engine>2 ||
        (s.ignition!=2 && s.engine!=VC_ENGINE_OFF) || (s.engine==VC_ENGINE_OFF && s.rpm!=0) ||
        s.battery_mv>20000 || s.rpm>16383 || s.speed_kph>255 || s.pedal_permille>1000 || s.load_permille>1000 ||
        s.maf_centi_gps>65535 || s.ambient_kpa>127 || s.manifold_kpa>255 ||
        s.coolant_c>119 || s.intake_c>119 || s.ecm_c>119) return 0;
    *out=s; return 1;
}
