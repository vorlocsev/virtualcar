#include "worker_lifecycle.h"
int vc_worker_begin(vc_worker_lifecycle *w,uint64_t *generation){
    if(!w||!generation||w->phase!=VC_WORKER_IDLE)return 0;
    if(!vc_live_begin(&w->slot,1,generation))return 0;
    w->active_generation=*generation;w->phase=VC_WORKER_RUNNING;return 1;
}
int vc_worker_request_stop(vc_worker_lifecycle *w){
    if(!w||w->phase==VC_WORKER_IDLE)return 0;
    w->phase=VC_WORKER_STOPPING;w->slot.valid=0;w->slot.source_tick=0;return 1;
}
int vc_worker_exited(vc_worker_lifecycle *w,uint64_t generation){
    if(!w||!generation||generation!=w->active_generation)return 0;
    return vc_worker_request_stop(w);
}
int vc_worker_joined(vc_worker_lifecycle *w,uint64_t generation){
    if(!w||w->phase!=VC_WORKER_STOPPING||!generation||generation!=w->active_generation)return 0;
    w->active_generation=0;w->phase=VC_WORKER_IDLE;return 1;
}
int vc_worker_legacy(vc_worker_lifecycle *w){
    uint64_t unused;
    if(!w||w->phase!=VC_WORKER_IDLE)return 0;
    return vc_live_begin(&w->slot,0,&unused);
}
int vc_worker_publish(vc_worker_lifecycle *w,uint64_t generation,const vc_state_snapshot *s,uint64_t tick,uint64_t now){
    if(!w||w->phase!=VC_WORKER_RUNNING||generation!=w->active_generation)return 0;
    return vc_live_publish(&w->slot,generation,s,tick,now);
}
vc_live_result vc_worker_select(const vc_worker_lifecycle *w,uint64_t now,vc_state_snapshot *out){
    return w?vc_live_select(&w->slot,now,out):VC_LIVE_UNAVAILABLE;
}
