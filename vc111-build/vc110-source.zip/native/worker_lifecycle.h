#ifndef VC_WORKER_LIFECYCLE_H
#define VC_WORKER_LIFECYCLE_H
#include "live_state_slot.h"
/* Owner and worker serialize these transitions with one short lock.
 * No I/O or wait under the lock. A stopped external session stays unavailable.
 * Only a confirmed OS join permits reuse of worker context. */
typedef enum { VC_WORKER_IDLE=0, VC_WORKER_RUNNING=1, VC_WORKER_STOPPING=2 } vc_worker_phase;
typedef struct { vc_live_slot slot; vc_worker_phase phase; uint64_t active_generation; } vc_worker_lifecycle;
int vc_worker_begin(vc_worker_lifecycle *,uint64_t *);
int vc_worker_request_stop(vc_worker_lifecycle *);
int vc_worker_exited(vc_worker_lifecycle *,uint64_t);
int vc_worker_joined(vc_worker_lifecycle *,uint64_t);
int vc_worker_legacy(vc_worker_lifecycle *);
int vc_worker_publish(vc_worker_lifecycle *,uint64_t,const vc_state_snapshot *,uint64_t,uint64_t);
vc_live_result vc_worker_select(const vc_worker_lifecycle *,uint64_t,vc_state_snapshot *);
#endif
