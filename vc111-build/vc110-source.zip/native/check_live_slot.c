#include "live_state_slot.h"
#include <assert.h>
#include <stdio.h>
#define CHECK(x) do {if(!(x)){fprintf(stderr,"FAIL line %d\n",__LINE__);return 1;}}while(0)
int main(void){
    vc_live_slot s={0};vc_state_snapshot v={0},out={0};uint64_t gen=0,old=0;
    v.sequence=1;v.ignition=2;v.engine=2;v.rpm=700;v.battery_mv=14000;v.coolant_c=90;v.maf_centi_gps=550;
    out.rpm=99;
    CHECK(vc_live_select(&s,0,&out)==VC_LIVE_LEGACY&&out.rpm==99);
    CHECK(!vc_live_publish(&s,0,&v,1000,1000));puts("1 legacy unchanged PASS");
    CHECK(vc_live_begin(&s,1,&gen)&&gen==1&&vc_live_select(&s,1000,&out)==VC_LIVE_UNAVAILABLE&&out.rpm==99);puts("2 external opt-in no fallback PASS");
    CHECK(vc_live_publish(&s,gen,&v,1000,1050));CHECK(vc_live_select(&s,1050,&out)==VC_LIVE_EXTERNAL&&out.rpm==700&&out.battery_mv==14000&&out.coolant_c==90&&out.maf_centi_gps==550);puts("3 coherent publication PASS");
    CHECK(vc_live_select(&s,2000,&out)==VC_LIVE_EXTERNAL);out.rpm=99;CHECK(vc_live_select(&s,2001,&out)==VC_LIVE_UNAVAILABLE&&out.rpm==99);puts("4 expiry independent of worker PASS");
    CHECK(!vc_live_publish(&s,gen,&v,2001,2001));CHECK(vc_live_select(&s,2001,&out)==VC_LIVE_UNAVAILABLE);puts("5 replay cannot renew expiry PASS");
    v.sequence=2;CHECK(!vc_live_publish(&s,gen,&v,1000,2001));CHECK(!vc_live_publish(&s,gen,&v,2002,2001));CHECK(!vc_live_publish(&s,gen,&v,999,1000));puts("6 stale/future/regressing tick PASS");
    v.rpm=800;CHECK(vc_live_publish(&s,gen,&v,2001,2001));CHECK(vc_live_select(&s,2001,&out)==VC_LIVE_EXTERNAL&&out.rpm==800);puts("7 recovery PASS");
    v.sequence=3;v.ignition=0;CHECK(!vc_live_publish(&s,gen,&v,2002,2002));CHECK(vc_live_select(&s,2002,&out)==VC_LIVE_EXTERNAL&&out.rpm==800);v.ignition=2;v.coolant_c=-41;CHECK(!vc_live_publish(&s,gen,&v,2002,2002));v.coolant_c=90;puts("8 invalid state atomic rejection PASS");
    old=gen;CHECK(vc_live_begin(&s,0,&gen)&&gen!=old);CHECK(!vc_live_publish(&s,old,&v,2002,2002));CHECK(vc_live_select(&s,2002,&out)==VC_LIVE_LEGACY);CHECK(vc_live_begin(&s,1,&gen));CHECK(!vc_live_publish(&s,old,&v,2002,2002));CHECK(vc_live_select(&s,2002,&out)==VC_LIVE_UNAVAILABLE);v.sequence=1;CHECK(vc_live_publish(&s,gen,&v,2002,2002));puts("9 close/reopen rejects old worker PASS");
    s.generation=UINT64_MAX;CHECK(!vc_live_begin(&s,0,&gen));CHECK(!vc_live_publish(&s,UINT64_MAX,&v,2003,2003));CHECK(vc_live_select(&s,2003,&out)==VC_LIVE_UNAVAILABLE);puts("10 generation overflow fail closed PASS");
    puts("VC108I_LIVE_SLOT=PASS 10/10");return 0;
}
