#include "session_credentials.h"
#include <string.h>
#include "byte_equal.h"
int vc_credentials_decode(const uint8_t *w,size_t n,const uint8_t expected[16],uint8_t key[32]){
    unsigned i;uint8_t any_id=0,any_key=0;
    if(!w||!expected||!key||n!=VC_CREDENTIAL_SIZE)return 0;
    if(!vc_bytes_equal(w,(const unsigned char *)"VCK1",4)||w[4]!=1||w[5]||w[6]!=VC_CREDENTIAL_SIZE||w[7])return 0;
    if(!vc_bytes_equal(w+8,expected,16))return 0;
    for(i=0;i<16;i++)any_id|=w[8+i];
    for(i=0;i<32;i++)any_key|=w[24+i];
    if(!any_id||!any_key)return 0;
    memcpy(key,w+24,32);return 1;
}
