VC108J — local diagnostic projection prototype, not a patch to virtualcar.c.
Base: VC108I; target PR511 b5671a5f0662d9be75e66314fb7968b2cca61a81.

New native/diagnostic_state.{h,c} captures one validated slot snapshot under
caller lock. Recognized ECM/CEM live DIDs and battery consumer have explicit
LEGACY, UNAVAILABLE, VALUE results; unowned DIDs are NOT_OWNED. No CAN routing,
service selection, negative response policy or J2534 call occurs in this code.
An UNAVAILABLE result must not fall through to static or B3A329 replies.
The caller must recapture before each request/IOCTL, not reuse contexts across
requests. Contexts are request-local and must not be exposed to untrusted input.

ECM encoding mirrors the previously retrieved PR511 ecm_lab_encode excerpt;
CEM DD02 rounding is a candidate (nearest 250mV), checked only at the observed
12.5/14.0V values, not against the unavailable exact helper. A45F mapping
0=04 and II=07 is laboratory evidence; I returns UNAVAILABLE. Existing route,
service, enable and extended DID checks MUST be retained before using these
values. REM format not verified and intentionally absent. No generic CAN
command, ECU programming, or DTC mutation interface added.

Production integration: reuse the existing ecm_lab_encode and voltage helpers
rather than duplicate encoding. Map the eleven ECM_LAB_STATE fields explicitly
from the captured snapshot, gate all live consumers (including READ_VBATT,
D2 current data, and REM after exact-source review), preserve identification,
DTC and legacy behavior. Do not use the old dynamic tick while external mode
is selected. Worker lifetime, secure provisioning, no-CRT imports/linking and
unavailable-response policy are not solved by this prototype.

Linux tests performed:
 cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined native/live_state_slot.c native/diagnostic_state.c native/check_diagnostic_state.c -o /tmp/vc108j-check
 /tmp/vc108j-check  # VC108J_DIAG=PASS 12/12
 python3 native/test_live_pipeline.py # transport 9/9, pipeline 500/500 + expiry
 cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined native/live_state_slot.c native/check_live_slot.c -o /tmp/vc108j-slot
 /tmp/vc108j-slot # 10/10
Windows test supplied, NOT run:
 powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows\check-diagnostic-state.ps1
Expected VC108J_DIAG=PASS 12/12. No Windows or .NET SDK available here.
No actual DLL, WinUI, VIDA, INI, repo or PR was modified. GitHub source fetch failed.
