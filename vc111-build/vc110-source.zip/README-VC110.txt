VC110 cumulative source candidate: VC108R + VC109C + raw J2534 log rotation
Exact base: b5671a5f0662d9be75e66314fb7968b2cca61a81
Original native source blob: 80cee49fc7712d86e3b3d9d1840f8d1598f0f125.

New native trace: %TEMP%\VirtualCar-VC110.log plus .1, .2, .3; 32 MiB per
segment (128 MiB total in normal operation), .lck sidecar. The old trace
SectorVVirtualCar.log is never opened, removed, truncated, or rotated by
this patch. Optional dev47-backend.jsonl telemetry is unchanged.
The sidecar is opened exclusively with GENERIC_READ, share=0, for the entire
size/rotation/write sequence. No retry loop: competing writes can be skipped.
MoveFileExA(REPLACE_EXISTING) shifts older slots then active; a blocked move
prevents append, active is not truncated. Readers allowing delete sharing
can continue across rotation. No transactional guarantee for multi-file
rotation after crash or disk error; a partial write on a failing filesystem
is possible. Assumes cooperative writers and no external modifications to
the new files/directories. No logging result changes the diagnostic API.

Build in x86 Visual Studio developer environment on Windows with .NET 10:
  powershell -NoProfile -File .\acceptance\build-only.ps1 -Checkout C:\VirtualCar-PR511 -Output C:\VC110-review -Python <absolute python.exe>
Use the actual runner Python path from E:\VirtualCar\Tools\python312.path.
Source preparation verifies the exact VC108 baseline, applies native and
WinUI patches to fresh separate directories. PE audit is mandatory.
No runtime tests, VIDA, driver registration or deployment in build-only.

Output: app/, provider/, provider-package.zip. Package all THREE as siblings.
The provider-only ZIP is sealed BEFORE WinUI publish; its hash and exact build
commit are substituted into a generated copy of prepare_profile.py. Its new
hash is bound in ProviderFlow.cs before compiling. This avoids dependence on
the previous VC108R ZIP and the circular hash of the full application archive.
App defaults to the sibling provider-package.zip. Do not mix builds or edit
sealed utilities. Python is still required on the machine performing profile
preparation and elevated registration. Registry changes remain explicit.

Validation here: C policy 14/14 with ASan/UBSan and 10,000 sequential writes;
patch fixture 5/5; provider-seal fixture 4/4; VC109 profile 17/17, switch 13/13,
WinUI patch 8/8; previous PE audit 8/8, integration anchors 24/24,
WinUI staging 6/6, mocked J2534 hooks 9/9. Exact native source anchor counts
confirmed against GitHub blob (1,1,1,2). No actual Windows SDK compilation,
Windows file sharing, VM run, UI or VIDA acceptance yet for VC110.
