/* Portable reference of runtime phases; not an actual J2534 or Windows test. */
#include "state_transport.h"
#include "worker_lifecycle.h"
#include "diagnostic_state.h"
#include <assert.h>
#include <openssl/hmac.h>
#include <openssl/crypto.h>
#include <stdio.h>
#include <string.h>
static const uint8_t key[32]={1,2,3}, session[16]={4,5,6}; /* public fixture only */
static int verify(const uint8_t *p,size_t n,const uint8_t *mac,void *unused){
    uint8_t out[32];unsigned len=0;(void)unused;
    return HMAC(EVP_sha256(),key,32,p,n,out,&len)!=NULL&&len==32&&CRYPTO_memcmp(out,mac,32)==0;
}
static void expect(vc_diag_context *c,vc_diag_target target,uint16_t did,const uint8_t *b,size_t n){
    uint8_t out[4];size_t len=0;
    assert(vc_diag_read(c,target,did,out,sizeof(out),&len)==VC_DIAG_VALUE&&len==n&&!memcmp(b,out,n));
}
#define EXPECT(c,t,d,...) do{const uint8_t b[]={__VA_ARGS__};expect(c,t,d,b,sizeof(b));}while(0)
static void battery(vc_diag_context *c,uint32_t expected){uint32_t mv=0;assert(vc_diag_battery(c,&mv)==VC_DIAG_VALUE&&mv==expected);}
int main(int argc,char **argv){
    FILE *f;uint8_t wire[128],out[4];size_t n=0;uint64_t gen=0;uint32_t mv=0xdeadbeef;
    vc_transport_cache cache;vc_worker_lifecycle worker={0};vc_diag_context c={0};vc_state_snapshot s;
    static const uint64_t ticks[]={1000,1100,1200,1300,2401,2500};
    assert(argc==2&&(f=fopen(argv[1],"rb"))!=NULL);
    assert(vc_transport_init(&cache,session)&&vc_worker_begin(&worker,&gen));
    for(unsigned i=0;i<6;i++){
        uint64_t tick=ticks[i];assert(fread(wire,1,sizeof(wire),f)==sizeof(wire));
        assert(vc_transport_accept(&cache,wire,sizeof(wire),tick,verify,NULL)&&vc_transport_get(&cache,tick,&s));
        assert(vc_worker_publish(&worker,gen,&s,cache.accepted_tick,tick));vc_diag_capture(&c,&worker.slot,tick);
        switch(i){
        case 0:battery(&c,12500);EXPECT(&c,VC_DIAG_ECM,0xF40C,0,0);EXPECT(&c,VC_DIAG_CEM,0xA45F,4);puts("PASS stationary");break;
        case 1:EXPECT(&c,VC_DIAG_CEM,0xA45F,7);puts("PASS ignition II");break;
        case 2:battery(&c,14000);EXPECT(&c,VC_DIAG_ECM,0xDA48,0x44,0x2f,0,0);EXPECT(&c,VC_DIAG_ECM,0xD99B,0xd0);EXPECT(&c,VC_DIAG_ECM,0xD994,0x40,0xb0,0,0);EXPECT(&c,VC_DIAG_ECM,0x120D,0xb3,0x33);EXPECT(&c,VC_DIAG_CEM,0xDD02,0x38);puts("PASS warm state");break;
        case 3:EXPECT(&c,VC_DIAG_ECM,0xF40C,0x46,0x50);EXPECT(&c,VC_DIAG_ECM,0xD9AC,3,0xe8);EXPECT(&c,VC_DIAG_ECM,0xF410,0x19,0x64);puts("PASS full pedal");
            vc_diag_capture(&c,&worker.slot,tick+1001);
            assert(!vc_transport_get(&cache,tick+1001,&s)&&!vc_transport_accept(&cache,wire,sizeof(wire),tick+1001,verify,NULL));
            assert(vc_diag_battery(&c,&mv)==VC_DIAG_UNAVAILABLE&&mv==0xdeadbeef);
            assert(vc_diag_read(&c,VC_DIAG_ECM,0xF40C,out,sizeof(out),&n)==VC_DIAG_UNAVAILABLE);
            assert(vc_diag_read(&c,VC_DIAG_CEM,0xDD02,out,sizeof(out),&n)==VC_DIAG_UNAVAILABLE);
            assert(vc_diag_read(&c,VC_DIAG_ECM,0xF187,out,sizeof(out),&n)==VC_DIAG_NOT_OWNED);puts("PASS expiry and no identity interception");break;
        case 4:battery(&c,14000);EXPECT(&c,VC_DIAG_ECM,0xF40C,0x46,0x50);puts("PASS fresh recovery");break;
        case 5:battery(&c,12500);EXPECT(&c,VC_DIAG_ECM,0xF40C,0,0);EXPECT(&c,VC_DIAG_ECM,0xD9AC,0,0);EXPECT(&c,VC_DIAG_CEM,0xA45F,7);puts("PASS stop");break;
        }
    }
    assert(fgetc(f)==EOF);fclose(f);
    assert(vc_worker_request_stop(&worker)&&vc_worker_exited(&worker,gen)&&vc_worker_joined(&worker,gen));
    assert(vc_worker_select(&worker,2500,&s)==VC_LIVE_UNAVAILABLE);puts("PASS closed external state unavailable");
    puts("VC108Q_REFERENCE=PASS 8/8 (portable fixture; Windows runtime not tested)");return 0;
}
