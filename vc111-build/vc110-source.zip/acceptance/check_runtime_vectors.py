"""Independent Python fixture to portable C pipeline, not the C# publisher."""
import hmac, struct, pathlib, tempfile, subprocess
root=pathlib.Path(__file__).resolve().parent.parent
stationary=(12500,0,0,0,0,0,100,100,20,20,20)
warm=(14000,700,0,0,180,550,100,35,90,30,45)
pedal=(14000,4500,0,1000,850,6500,100,95,90,30,45)
key=bytes([1,2,3])+bytes(29);session=bytes([4,5,6])+bytes(13)
phases=[(1000,0,0,stationary),(1100,2,0,stationary),(1200,2,2,warm),(1300,2,2,pedal),(2401,2,2,pedal),(2500,2,0,stationary)]
with tempfile.TemporaryDirectory() as td:
    td=pathlib.Path(td); fixture=td/'phases.bin'; exe=td/'check'; data=b''
    for seq,(tick,ignition,engine,values) in enumerate(phases,1):
        vcst=b'VCST'+bytes([1,0,64,0])+struct.pack('<QBBH11i',seq,ignition,engine,0,*values)
        head=b'VCTP'+bytes([1,0,128,0])+session+struct.pack('<Q',tick)+vcst
        data+=head+hmac.digest(key,head,'sha256')
    fixture.write_bytes(data)
    native=root/'native'
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=undefined','-I',str(native),*(str(native/(name+'.c')) for name in ['vehicle_state_wire','state_transport','live_state_slot','worker_lifecycle','diagnostic_state']),str(root/'acceptance/check_runtime_vectors.c'),'-lcrypto','-o',str(exe)],check=True)
    subprocess.run([exe,fixture],check=True)
