"""VC108R: run actual Windows gates, retaining evidence; no registry or VIDA."""
import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
from pathlib import Path
from audit_pe import audit

ROOT = Path(__file__).resolve().parent.parent
BASE = 'b5671a5f0662d9be75e66314fb7968b2cca61a81'
BUILD = {
    'stage': 'VC108P_STAGE=PASS (source only)',
    'pe': 'VC108P_PE=PASS x86 exports=14',
    'managed_model': 'VC108F_MANAGED=PASS 8/8',
    'managed_transport': 'VC108G_MANAGED=PASS 3/3',
    'managed_accelerator': 'VC108K_MANAGED=PASS 9/9',
    'smoke_x86': 'VC108P_X86_SMOKE=PASS 6/6',
    'build': 'VC108P_BUILD=PASS (isolated candidate, not installed; external mode and VIDA NOT TESTED)',
}
RUNTIME = {**{f'gate_{i}': f'VC108Q_GATE_{i}=PASS' for i in range(1,9)},
           'runtime_x86': 'VC108Q_X86_RUNTIME=PASS 8/8',
           'runtime_managed': 'VC108Q_MANAGED_RUNTIME=PASS (x86 consumer completed all phases)'}

def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''): digest.update(chunk)
    return digest.hexdigest().upper()

def has_marker(lines, marker):
    return sum(x == marker or x.startswith(marker+' ') for x in lines) == 1

def assess(lines, rc, markers):
    result = {k: 'PASS' if has_marker(lines,v) else 'NOT_TESTED' for k,v in markers.items()}
    # Earlier markers remain useful evidence, but cannot override process failure.
    return result, rc == 0 and all(v == 'PASS' for v in result.values())

def apphost_x64(data):
    if len(data)<64 or data[:2]!=b'MZ': raise ValueError('Missing apphost MZ')
    p=struct.unpack_from('<I',data,60)[0]
    if p+26>len(data) or data[p:p+4]!=b'PE\0\0': raise ValueError('Missing apphost PE')
    if struct.unpack_from('<H',data,p+4)[0]!=0x8664 or struct.unpack_from('<H',data,p+24)[0]!=0x20b or struct.unpack_from('<H',data,p+22)[0]&0x2000:
        raise ValueError('Not x64 PE32+ executable')

def run(cmd, log):
    # Binary log preserves the exact child stream; PowerShell console encoding may vary.
    # ASCII PASS tokens survive common Windows OEM/ANSI codepages.
    lines=[]
    with log.open('xb') as f, subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT) as p:
        for raw in iter(p.stdout.readline,b''):
            f.write(raw); f.flush()
            line=raw.decode('utf-8',errors='replace').rstrip('\r\n')
            lines.append(line)
            print(line,flush=True)
        rc=p.wait()
    return lines,rc

def ensure_disjoint(a,b):
    if a==b or a in b.parents or b in a.parents: raise ValueError(f'Paths must be separate: {a} / {b}')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkout',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True)
    p.add_argument('--evidence',type=Path,required=True);p.add_argument('--reuse',action='store_true',help='Use existing candidate; earlier build is not attested')
    a=p.parse_args(); repo=a.checkout.resolve(); candidate=a.candidate.resolve(); evidence=a.evidence.resolve()
    if os.name!='nt' or struct.calcsize('P')!=8 or platform.machine().lower() not in ('amd64','x86_64'): p.error('Windows x64 and 64-bit Python required; no runtime claim on this host')
    for x,y in [(repo,candidate),(repo,evidence),(candidate,evidence),(ROOT,evidence),(ROOT,candidate)]: ensure_disjoint(x,y)
    if evidence.exists(): p.error('Fresh evidence directory required')
    if a.reuse != candidate.exists(): p.error('Existing candidate requires --reuse; otherwise use fresh candidate path')
    evidence.mkdir(parents=True,exist_ok=False)
    report={'base_expected':BASE,'candidate':str(candidate),'reuse':a.reuse,'build':{k:'NOT_TESTED' for k in BUILD},'runtime':{k:'NOT_TESTED' for k in RUNTIME},'vida':'NOT_TESTED','winui_interactive':'NOT_TESTED','status':'FAIL'}
    def save():
        temp=evidence/'result.tmp';temp.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');temp.replace(evidence/'result.json')
    save()
    try:
        if not repo.is_dir(): raise ValueError('Source checkout missing')
        head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
        report['checkout_head']=head
        if head!=BASE: raise ValueError('Exact HEAD required')
        ps=Path(os.environ['WINDIR'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
        if not ps.is_file(): raise ValueError('Windows PowerShell missing')
        if not a.reuse:
            lines,rc=run([str(ps),'-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'acceptance/build-candidate.ps1'),'-Checkout',str(repo),'-Output',str(candidate)],evidence/'build.log')
            report['build'],ok=assess(lines,rc,BUILD);report['build_exit']=rc;save()
            if not ok: raise RuntimeError('Build gates incomplete or failed; inspect build.log')
        dll=candidate/'provider/VirtualCarJ2534.dll';app=candidate/'app/VirtualCar.WinUI.exe'
        exports,imports=audit(dll.read_bytes());apphost_x64(app.read_bytes())
        report['pe']={'dll':'x86','exports':exports,'imports':imports,'apphost':'x64'}
        report['sha256']={'dll':sha(dll),'apphost':sha(app)};save()
        # Compile C# checks in evidence folder, not the original unpacked prototype.
        work=evidence/'runtime-source';work.mkdir()
        for folder in ('Core','RuntimeChecks','acceptance'):
            shutil.copytree(ROOT/folder,work/folder,ignore=shutil.ignore_patterns('bin','obj','__pycache__'))
        lines,rc=run(['dotnet','run','--project',str(work/'RuntimeChecks/RuntimeChecks.csproj'),'--configuration','Release','--',str(dll),str(evidence/'runtime'),str(work/'acceptance/runtime-x86.ps1')],evidence/'runtime.log')
        report['runtime'],ok=assess(lines,rc,RUNTIME);report['runtime_exit']=rc
        claimed=re.findall(r'^VC108Q_DLL_SHA256=([0-9A-F]{64})$', '\n'.join(lines),re.M)
        copied=evidence/'runtime/VirtualCarJ2534.dll'
        if claimed!=[report['sha256']['dll']] or sha(dll)!=report['sha256']['dll'] or sha(app)!=report['sha256']['apphost'] or not copied.is_file() or sha(copied)!=report['sha256']['dll']:
            raise RuntimeError('Candidate identity mismatch or not evidenced')
        if not ok: raise RuntimeError('Runtime gates incomplete or failed; inspect runtime.log')
        report['status']='PASS_RUNTIME_EXISTING_BUILD_NOT_ATTESTED' if a.reuse else 'PASS_BUILD_AND_RUNTIME'
        print('VC108R='+report['status'])
        return 0
    except Exception as exc:
        report['error']=str(exc);print('VC108R=FAIL '+str(exc),file=sys.stderr);return 1
    finally:
        save();print('VC108R_EVIDENCE='+str(evidence/'result.json'))

if __name__=='__main__': sys.exit(main())
