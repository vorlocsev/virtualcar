param([Parameter(Mandatory=$true)][string]$Directory)
$ErrorActionPreference='Stop'
if([IntPtr]::Size -ne 4){throw 'x86 required'}
Add-Type -Path (Join-Path $PSScriptRoot 'RuntimeConsumer.cs')
[VC108QConsumer]::Run([IO.Path]::GetFullPath($Directory))
