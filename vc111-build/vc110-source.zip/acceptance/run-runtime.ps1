param([Parameter(Mandatory=$true)][string]$Candidate,[Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$dll=Join-Path ([IO.Path]::GetFullPath($Candidate)) 'provider\VirtualCarJ2534.dll'
$out=[IO.Path]::GetFullPath($Output)
if(Test-Path -LiteralPath $out){throw 'Fresh output required'}
if(-not (Test-Path -LiteralPath $dll -PathType Leaf)){throw 'Build VC108P candidate first'}
& py -3 (Join-Path $PSScriptRoot 'audit_pe.py') $dll
if($LASTEXITCODE -ne 0){throw 'PE audit failed'}
& dotnet run --project (Join-Path $root 'RuntimeChecks\RuntimeChecks.csproj') --configuration Release -- $dll $out (Join-Path $PSScriptRoot 'runtime-x86.ps1')
if($LASTEXITCODE -ne 0){throw 'Runtime check failed'}
