using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

// .NET Framework-compatible x86 consumer, using standard J2534 ABI only.
public sealed class VC108QConsumer : IDisposable {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,ExactSpelling=true,SetLastError=true)] static extern IntPtr LoadLibraryW(string p);
    [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true,SetLastError=true)] static extern IntPtr GetProcAddress(IntPtr m,string n);
    [DllImport("kernel32.dll",ExactSpelling=true)] static extern bool FreeLibrary(IntPtr m);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate uint Open(IntPtr name,out uint dev);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate uint Close(uint dev);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate uint Connect(uint dev,uint protocol,uint flags,uint baud,out uint ch);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate uint Disconnect(uint ch);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate uint Transfer(uint ch,IntPtr msg,ref uint count,uint timeout);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate uint Ioctl(uint ch,uint cmd,IntPtr input,ref uint output);
    IntPtr module, msg; uint device,hs,ms; bool opened,hsOpen,msOpen;
    Close close; Disconnect disconnect; Transfer write,read; Ioctl ioctl;
    const int Size=24+4128;
    T Get<T>(string name) where T:class { IntPtr p=GetProcAddress(module,"PassThru"+name); if(p==IntPtr.Zero) throw new Exception(name); return Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T; }
    static void Require(bool good,string why){if(!good)throw new InvalidOperationException(why);}
    static void Ok(uint rc,string why){Require(rc==0,why+" rc="+rc);}
    VC108QConsumer(string dll) {
        module=LoadLibraryW(dll);Require(module!=IntPtr.Zero,"LoadLibraryW: "+Marshal.GetLastWin32Error());
        try {
            close=Get<Close>("Close");disconnect=Get<Disconnect>("Disconnect");write=Get<Transfer>("WriteMsgs");read=Get<Transfer>("ReadMsgs");ioctl=Get<Ioctl>("Ioctl");
            msg=Marshal.AllocHGlobal(Size);
            Ok(Get<Open>("Open")(IntPtr.Zero,out device),"Open");opened=true;
            var connect=Get<Connect>("Connect");Ok(connect(device,6,0x100,500000,out hs),"HS connect");hsOpen=true;
            Ok(connect(device,5,0x100,125000,out ms),"MS connect");msOpen=true;
        } catch {Dispose();throw;}
    }
    static byte[] Hex(string s){string[] a=s.Split(' ');byte[] b=new byte[a.Length];for(int i=0;i<a.Length;i++)b[i]=Convert.ToByte(a[i],16);return b;}
    static bool Equal(byte[] a,byte[] b){if(a==null||a.Length!=b.Length)return false;for(int i=0;i<b.Length;i++)if(a[i]!=b[i])return false;return true;}
    byte[] Query(uint ch,uint protocol,string request) {
        byte[] raw=Hex(request);byte[] zero=new byte[Size];Marshal.Copy(zero,0,msg,Size);
        Marshal.WriteInt32(msg,0,(int)protocol);Marshal.WriteInt32(msg,8,0x100);Marshal.WriteInt32(msg,16,raw.Length);Marshal.Copy(raw,0,IntPtr.Add(msg,24),raw.Length);
        uint n=1;Ok(write(ch,msg,ref n,100),"WriteMsgs");Require(n==1,"TX count");
        n=1;uint rc=read(ch,msg,ref n,200);
        if((rc==9||rc==16)&&n==0)return null;
        Ok(rc,"ReadMsgs");Require(n==1,"RX count");
        int len=Marshal.ReadInt32(msg,16);Require(len>=4&&len<=4128,"RX size");Require(Marshal.ReadInt32(msg,0)==protocol,"RX protocol");
        byte[] response=new byte[len];Marshal.Copy(IntPtr.Add(msg,24),response,0,len);return response;
    }
    byte[] Did(bool cem,string did){return Query(hs,6,(cem?"18 DA 50 F1":"18 DA 10 F1")+" 22 "+did);}
    bool Match(bool cem,string did,string expected){return Equal(Did(cem,did),Hex((cem?"18 DA F1 50":"18 DA F1 10")+" 62 "+did+" "+expected));}
    uint Battery(out uint mv){mv=0xdeadbeef;return ioctl(device,3,IntPtr.Zero,ref mv);}
    bool Voltage(uint expected){uint v;return Battery(out v)==0&&v==expected;}
    bool Unavailable(){uint v;return Battery(out v)==8&&v==0xdeadbeef;}
    static void Wait(Func<bool> check,string why){var sw=Stopwatch.StartNew();while(sw.ElapsedMilliseconds<8000){if(check())return;Thread.Sleep(100);}throw new TimeoutException(why);}
    static void Phase(string dir,int n){using(File.Open(Path.Combine(dir,"phase-"+n),FileMode.CreateNew,FileAccess.Write,FileShare.Read)){} }
    static void Pass(int n,string s){Console.WriteLine("VC108Q_GATE_"+n+"=PASS "+s);}
    public static void Run(string dir){
        Require(IntPtr.Size==4,"x86 required");
        using(var c=new VC108QConsumer(Path.Combine(dir,"VirtualCarJ2534.dll"))){
            Wait(()=>c.Voltage(12500)&&c.Match(false,"F4 0C","00 00")&&c.Match(true,"A4 5F","04"),"initial state");Pass(1,"stationary + ignition off");
            Phase(dir,1);Wait(()=>c.Match(true,"A4 5F","07"),"ignition II");Pass(2,"ignition II");
            Phase(dir,2);Wait(()=>c.Voltage(14000)&&c.Match(false,"DA 48","44 2F 00 00")&&c.Match(false,"D9 9B","D0")&&c.Match(false,"D9 94","40 B0 00 00")&&c.Match(false,"12 0D","B3 33")&&c.Match(true,"DD 02","38"),"warm state");Pass(3,"warm ECM/CEM/VBATT");
            Require(Equal(c.Query(c.ms,5,"00 0F FF FE CD 46 A6 D0 D4 01 00 00"),Hex("00 80 00 03 CD 46 E6 D0 D4 70 00 00")),"REM D2 voltage");Pass(4,"REM voltage 14V");
            Phase(dir,3);Wait(()=>c.Match(false,"F4 0C","46 50")&&c.Match(false,"D9 AC","03 E8")&&c.Match(false,"F4 10","19 64"),"accelerator");Pass(5,"4500 rpm / 100% pedal / 65 g/s");
            Phase(dir,4);Wait(()=>c.Unavailable(),"publisher stale");Require(c.Did(false,"F4 0C")==null&&c.Did(true,"DD 02")==null&&c.Did(true,"A4 5F")==null,"stale live DID returned");Require(c.Query(c.ms,5,"00 0F FF FE CD 46 A6 D0 D4 01 00 00")==null,"stale REM returned");Require(c.Match(false,"F1 87","4C 41 42 2D 45 43 4D"),"identity lost");Pass(6,"stale denied; identity retained");
            Phase(dir,5);Wait(()=>c.Voltage(14000)&&c.Match(false,"F4 0C","46 50"),"recovery");Pass(7,"same-session recovery");
            Phase(dir,6);Wait(()=>c.Voltage(12500)&&c.Match(false,"F4 0C","00 00")&&c.Match(false,"D9 AC","00 00")&&c.Match(true,"A4 5F","07"),"stop");c.End();Pass(8,"stop + disconnect + close");
        }
        Console.WriteLine("VC108Q_X86_RUNTIME=PASS 8/8");
    }
    void End(){if(msOpen){Ok(disconnect(ms),"MS disconnect");msOpen=false;}if(hsOpen){Ok(disconnect(hs),"HS disconnect");hsOpen=false;}if(opened){Ok(close(device),"Close");opened=false;}}
    public void Dispose(){try{End();}finally{if(msg!=IntPtr.Zero){Marshal.FreeHGlobal(msg);msg=IntPtr.Zero;}if(module!=IntPtr.Zero){Require(FreeLibrary(module),"FreeLibrary failed");module=IntPtr.Zero;}}}
}
