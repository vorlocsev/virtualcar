"""Exercise the candidate staging edit and PE auditor with real synthetic PE files.
No claim of J2534 runtime or Windows SDK validation."""
import pathlib, subprocess, tempfile, struct, unittest
from audit_pe import audit, EXPECTED
from prepare_all import sdk_mode, ANCHOR
class TestAcceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(); cls.path=pathlib.Path(cls.tmp.name)
        def run(*a): subprocess.run(a,cwd=cls.path,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        for lib,sym in [('kernel32','DemoKernel'),('bcrypt','DemoCrypto'),('crypt32','DemoProtect'),('msvcrt','DemoCrt')]:
            (cls.path/(lib+'.def')).write_text(f'LIBRARY {lib}.dll\nEXPORTS\n {sym}\n')
            run('lld-link','/lib','/machine:x86','/def:'+lib+'.def','/out:'+lib+'.lib')
        def build(name,crt=False,extra=False):
            names=sorted(EXPECTED|({'Unexpected'} if extra else set()))
            src='__declspec(dllimport) int DemoKernel(void),DemoCrypto(void),DemoProtect(void);\n'
            if crt: src+='__declspec(dllimport) int DemoCrt(void);\n'
            src+='\n'.join(f'int {n}(void){{return DemoKernel()+DemoCrypto()+DemoProtect()'+('+DemoCrt()' if crt else '')+';}' for n in names)
            (cls.path/'a.c').write_text(src);(cls.path/'a.def').write_text('LIBRARY test\nEXPORTS\n'+'\n'.join(names)+'\n')
            run('clang','-target','i686-pc-windows-msvc','-c','-fno-stack-protector','a.c','-o','a.obj')
            run('lld-link','/dll','/noentry','/machine:x86','/nodefaultlib','/def:a.def','/out:'+name,'a.obj','kernel32.lib','bcrypt.lib','crypt32.lib',*(['msvcrt.lib'] if crt else []))
            return (cls.path/name).read_bytes()
        cls.good=build('good.dll');cls.crt=build('crt.dll',crt=True);cls.extra=build('extra.dll',extra=True)
    @classmethod
    def tearDownClass(cls): cls.tmp.cleanup()
    def test_exact(self): self.assertEqual(set(audit(self.good)[0]),EXPECTED)
    def test_crt(self):
        with self.assertRaises(ValueError):audit(self.crt)
    def test_extra(self):
        with self.assertRaises(ValueError):audit(self.extra)
    def test_truncated(self):
        with self.assertRaises(ValueError):audit(self.good[:512])
    def test_machine(self):
        b=bytearray(self.good);struct.pack_into('<H',b,struct.unpack_from('<I',b,60)[0]+4,0x8664)
        with self.assertRaises(ValueError):audit(b)
    def test_anchor(self): self.assertIn('VC108P_SDK',sdk_mode(ANCHOR))
    def test_missing_anchor(self):
        with self.assertRaises(ValueError):sdk_mode('nothing')
    def test_duplicate_anchor(self):
        with self.assertRaises(ValueError):sdk_mode(ANCHOR+'\n'+ANCHOR)
if __name__=='__main__':unittest.main(verbosity=2)
