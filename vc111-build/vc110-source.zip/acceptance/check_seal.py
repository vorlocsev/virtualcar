import tempfile,unittest,shutil,sys,importlib.util
from pathlib import Path
from seal_provider import ROOT,seal,sha,DLL
class SealTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.out=Path(self.tmp.name)
  self.dll=self.out/DLL;self.dll.parent.mkdir();self.dll.write_bytes(b'fixture only')
  self.live=self.out/'winui-review/emulator/managed/VirtualCar.WinUI/LiveControl';self.live.mkdir(parents=True)
  for n in ('ProviderFlow.cs','LiveControlWindow.cs'):shutil.copyfile(ROOT/'vc109/winui'/n,self.live/n)
 def tearDown(self):self.tmp.cleanup()
 def test_seal(self):
  digest=seal(self.out,'1'*40);package=self.out/'provider-package.zip';self.assertEqual(digest,sha(package.read_bytes()))
  prep=self.out/'sealed-tools/prepare_profile.py';spec=importlib.util.spec_from_file_location('sealed_prep',prep);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  self.assertEqual(m.extract_dll(package),self.dll.read_bytes());self.assertEqual(m.COMMIT,'1'*40)
  self.assertIn(sha(prep.read_bytes()),(self.live/'ProviderFlow.cs').read_text());self.assertIn('provider-package.zip',(self.live/'LiveControlWindow.cs').read_text())
  package.write_bytes(package.read_bytes()+b'x')
  with self.assertRaises(ValueError):m.extract_dll(package)
 def test_no_overwrite(self):
  seal(self.out,'1'*40)
  with self.assertRaises(ValueError):seal(self.out,'1'*40)
 def test_bad_commit(self):
  with self.assertRaises(ValueError):seal(self.out,'main')
 def test_bad_source(self):
  (self.live/'ProviderFlow.cs').write_text('unexpected')
  with self.assertRaises(ValueError):seal(self.out,'1'*40)
if __name__=='__main__':unittest.main(verbosity=2)
