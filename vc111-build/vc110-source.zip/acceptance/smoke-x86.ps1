param([Parameter(Mandatory=$true)][string]$Directory)
$ErrorActionPreference='Stop'
if([IntPtr]::Size -ne 4){throw 'x86 process required'}
$d=[IO.Path]::GetFullPath($Directory); $dll=Join-Path $d 'VirtualCarJ2534.dll';$ini=Join-Path $d 'virtualcar.ini'
if(Test-Path -LiteralPath $ini){throw 'Fresh isolated smoke directory required'}
# Process-local only: keep native diagnostic log separate from the active VIDA log.
$env:TEMP=$d; $env:TMP=$d
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class VC108PSmoke {
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true,ExactSpelling=true)] public static extern IntPtr LoadLibraryW(string p);
 [DllImport("kernel32.dll",SetLastError=true,ExactSpelling=true)] public static extern IntPtr GetProcAddress(IntPtr m,string n);
 [DllImport("kernel32.dll")] public static extern bool FreeLibrary(IntPtr m);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] public delegate uint Open(IntPtr n,out uint d);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] public delegate uint Close(uint d);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)] public delegate uint Ioctl(uint d,uint code,IntPtr input,ref uint output);
 public static Delegate Get(IntPtr m,string n,Type t) { IntPtr p=GetProcAddress(m,n); if(p==IntPtr.Zero) throw new Exception(n); return Marshal.GetDelegateForFunctionPointer(p,t); }
}
'@
$m=[VC108PSmoke]::LoadLibraryW($dll); if($m -eq [IntPtr]::Zero){throw "LoadLibrary failed: $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"}
$opened=$false; [uint32]$id=0
try {
 $open=[VC108PSmoke]::Get($m,'PassThruOpen',[VC108PSmoke+Open]);$close=[VC108PSmoke]::Get($m,'PassThruClose',[VC108PSmoke+Close]);$io=[VC108PSmoke]::Get($m,'PassThruIoctl',[VC108PSmoke+Ioctl]);
 [IO.File]::WriteAllText($ini,"[Vehicle]`r`nBatteryMv=12500`r`n[VC108N_ExternalStateLab]`r`nEnabled=0`r`n",[Text.Encoding]::ASCII)
 if($open.Invoke([IntPtr]::Zero,[ref]$id) -ne 0 -or $id -ne 1){throw 'Legacy open failed'}; $opened=$true
 [uint32]$v=0; if($io.Invoke($id,3,[IntPtr]::Zero,[ref]$v) -ne 0 -or $v -ne 12500){throw 'Legacy VBATT failed'}
 if($close.Invoke($id) -ne 0){throw 'Legacy close failed'};$opened=$false
 [IO.File]::WriteAllText($ini,"[VC108N_ExternalStateLab]`r`nEnabled=1`r`n",[Text.Encoding]::ASCII)
 $rc=$open.Invoke([IntPtr]::Zero,[ref]$id);if($rc -eq 0){$opened=$true;throw 'Invalid external profile accepted'};if($rc -ne 7){throw "Unexpected failure $rc"}
 [IO.File]::WriteAllText($ini,"[Vehicle]`r`nBatteryMv=12500`r`n[VC108N_ExternalStateLab]`r`nEnabled=0`r`n",[Text.Encoding]::ASCII)
 if($open.Invoke([IntPtr]::Zero,[ref]$id) -ne 0){throw 'Reopen failed'};$opened=$true
 if($close.Invoke($id) -ne 0){throw 'Reclose failed'};$opened=$false
 Write-Host 'VC108P_X86_SMOKE=PASS 6/6 (legacy and invalid opt-in only)'
} finally { if($opened){[void]$close.Invoke($id)}; [void][VC108PSmoke]::FreeLibrary($m) }
