import unittest,struct
from pathlib import Path
import tempfile
# Load hyphenated script without renaming it.
import importlib.util
spec=importlib.util.spec_from_file_location('gates',Path(__file__).with_name('run-windows-gates.py'));g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
class Gates(unittest.TestCase):
    def test_complete(self): self.assertTrue(g.assess(list(g.RUNTIME.values()),0,g.RUNTIME)[1])
    def test_missing(self): self.assertFalse(g.assess(list(g.RUNTIME.values())[:-1],0,g.RUNTIME)[1])
    def test_exit(self): self.assertFalse(g.assess(list(g.RUNTIME.values()),1,g.RUNTIME)[1])
    def test_duplicate(self): self.assertFalse(g.assess(list(g.RUNTIME.values())+[g.RUNTIME['gate_1']],0,g.RUNTIME)[1])
    def test_prefix(self): self.assertFalse(g.has_marker(['VC108Q_GATE_1=PASSING'],'VC108Q_GATE_1=PASS'))
    def test_detail(self): self.assertTrue(g.has_marker(['VC108Q_GATE_1=PASS initial'],'VC108Q_GATE_1=PASS'))
    def test_pe(self):
        b=bytearray(128);b[:2]=b'MZ';struct.pack_into('<I',b,60,64);b[64:68]=b'PE\0\0';struct.pack_into('<H',b,68,0x8664);struct.pack_into('<H',b,88,0x20b);g.apphost_x64(b)
        struct.pack_into('<H',b,68,0x14c)
        with self.assertRaises(ValueError):g.apphost_x64(b)
    def test_overlap(self):
        with tempfile.TemporaryDirectory() as t:
            a=Path(t);g.ensure_disjoint(a/'one',a/'two')
            with self.assertRaises(ValueError):g.ensure_disjoint(a,a/'two')
    def test_missing_build(self):
        s,ok=g.assess([],0,g.BUILD);self.assertFalse(ok);self.assertTrue(all(v=='NOT_TESTED' for v in s.values()))
if __name__=='__main__':unittest.main(verbosity=2)
