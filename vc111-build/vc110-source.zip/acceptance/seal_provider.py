"""Seal the already audited DLL into a provider-only package before compiling WinUI.
No self-referential hash of the full application ZIP. No registration or profile access.
"""
import argparse, hashlib, re, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
BASE='b5671a5f0662d9be75e66314fb7968b2cca61a81'
OLD_COMMIT='d70a86113a89c19a7294f426256af9861cf4a99b'
OLD_SHA='2AFC83A052A3A08EDB2659B7A4671BC79C6B45196BE00BAD1C7DC1944FF0A5CE'
OLD_PATH='@"E:\\VirtualCar\\Builds\\VC108R-45858063194-1\\VirtualCar-VC108R-development.zip"'
DLL='provider/VirtualCarJ2534.dll'
def sha(data):return hashlib.sha256(data).hexdigest().upper()
def replace_once(text,a,b):
    if text.count(a)!=1:raise ValueError('Missing or ambiguous binding: '+a[:60])
    return text.replace(a,b,1)
def seal(out,commit):
    if not re.fullmatch('[0-9a-f]{40}',commit):raise ValueError('Exact build commit required')
    out=Path(out); package=out/'provider-package.zip'; helper=out/'sealed-tools'; live=out/'winui-review/emulator/managed/VirtualCar.WinUI/LiveControl'
    flow=live/'ProviderFlow.cs'; window=live/'LiveControlWindow.cs'; src=ROOT/'vc109'; dll=(out/DLL).read_bytes()
    if package.exists() or helper.exists():raise ValueError('Fresh provider seal required')
    orig_prepare=(src/'prepare_profile.py').read_bytes(); orig_switch=(src/'switch_provider.py').read_bytes()
    flow_text=flow.read_text(encoding='utf-8'); win_text=window.read_text(encoding='utf-8')
    if sha(orig_prepare) not in flow_text or sha(orig_switch) not in flow_text:raise ValueError('Helper binding mismatch')
    win_text=replace_once(win_text,OLD_PATH,'System.IO.Path.GetFullPath(System.IO.Path.Combine(AppContext.BaseDirectory,"..","provider-package.zip"))')
    win_text=replace_once(win_text,'Original VC108R inner ZIP / Исходный ZIP VC108R','Sealed provider ZIP / Пакет провайдера')
    with zipfile.ZipFile(package,'x',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr(DLL,dll);z.writestr('BUILD-INFO.txt',f'VC110 provider-only package\nBase: {BASE}\nBuild commit: {commit}\nRuntime and VIDA NOT TESTED\n')
        z.writestr('SHA256SUMS.txt',sha(dll)+'  '+DLL+'\n')
    digest=sha(package.read_bytes())
    prepare=replace_once(orig_prepare.decode(),OLD_SHA,digest)
    prepare=replace_once(prepare,OLD_COMMIT,commit).encode()
    helper.mkdir();(helper/'prepare_profile.py').write_bytes(prepare);(helper/'switch_provider.py').write_bytes(orig_switch)
    flow_text=replace_once(flow_text,sha(orig_prepare),sha(prepare))
    flow.write_bytes(flow_text.encode('utf-8'));window.write_bytes(win_text.encode('utf-8'))
    print('VC110_PROVIDER_SEAL='+digest)
    return digest
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('commit');a=p.parse_args();seal(a.output,a.commit)
