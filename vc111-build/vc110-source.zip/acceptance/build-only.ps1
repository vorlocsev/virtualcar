param([Parameter(Mandatory=$true)][string]$Checkout,[Parameter(Mandatory=$true)][string]$Output,[string]$Python="py.exe")
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
function Run-VC108P([string]$exe,[string[]]$argv) { & $exe @argv; if($LASTEXITCODE -ne 0){throw "$exe failed: $LASTEXITCODE"} }
foreach($tool in @($Python,'git.exe','dotnet.exe','clang-cl.exe','link.exe')){if(-not (Get-Command $tool -ErrorAction SilentlyContinue)){throw "Missing $tool (Visual Studio x86 Developer PowerShell, LLVM, .NET 10 required)"}}
if($env:VSCMD_ARG_TGT_ARCH -ne 'x86'){throw 'Use x86 target Developer PowerShell (host may be x64)'}
if(-not ((& dotnet.exe --list-sdks) -match '^10\.')){throw '.NET 10 SDK required'}
$out=[IO.Path]::GetFullPath($Output)
$pyArgs=@(); if($Python -eq 'py.exe'){$pyArgs=@('-3')}
Run-VC108P $Python ($pyArgs+@((Join-Path $PSScriptRoot 'prepare_all.py'),$Checkout,$out))
$src=Join-Path $out 'native-review\staged\emulator\src'; $obj=Join-Path $out 'obj'; $provider=Join-Path $out 'provider'; $app=Join-Path $out 'app'
New-Item -ItemType Directory -Path $obj,$provider | Out-Null
$sources=@('virtualcar.c','p2core\p2_cem_router.c','p2core\p2_ls_observer.c','p2core\p2_vehicle_core.c','p2core\p2_j2534_bridge.c','p2core\freestanding_memory.c','vc108n\native\vehicle_state_wire.c','vc108n\native\state_transport.c','vc108n\native\session_credentials.c','vc108n\native\live_state_slot.c','vc108n\native\worker_lifecycle.c','vc108n\windows\state_windows.c','vc108n\windows\session_windows.c','vc108n\windows\state_worker.c','vc108n\integration\vc108n_bridge.c','vc110\rotation_windows.c')
$objects=@()
foreach($source in $sources){$o=Join-Path $obj (([IO.Path]::GetFileNameWithoutExtension($source))+'.obj'); $objects+=$o; Run-VC108P 'clang-cl.exe' @('--target=i686-pc-windows-msvc','/nologo','/c','/O2','/GS-','/Zl','/TC','/clang:-fno-builtin','/DVC108P_SDK','/DVC108N_EXTERNAL_STATE','/DVC108N_DLL_WORKER','/D_WIN32_WINNT=0x0A00',('/Fo'+$o),(Join-Path $src $source))}
$dll=Join-Path $provider 'VirtualCarJ2534.dll'
Run-VC108P 'link.exe' (@('/NOLOGO','/DLL','/MACHINE:X86','/ENTRY:DllMain@12','/NODEFAULTLIB',('/DEF:'+(Join-Path $src 'virtualcar.def')),('/OUT:'+$dll))+$objects+@('kernel32.lib','bcrypt.lib','crypt32.lib'))
Run-VC108P $Python ($pyArgs+@((Join-Path $PSScriptRoot 'audit_pe.py'),$dll))
$buildCommit=$env:GITHUB_SHA
if(-not $buildCommit){$buildCommit=(& git.exe -C $Checkout rev-parse HEAD).Trim();if($LASTEXITCODE -ne 0){throw 'Missing build commit'}}
Run-VC108P $Python ($pyArgs+@((Join-Path $PSScriptRoot 'seal_provider.py'),$out,$buildCommit))
$project=Join-Path $out 'winui-review\emulator\managed\VirtualCar.WinUI\VirtualCar.WinUI.csproj'
Run-VC108P 'dotnet.exe' @('publish',$project,'-c','Release','-r','win-x64','--self-contained','true','-o',$app)
if(-not (Test-Path -LiteralPath (Join-Path $app 'VirtualCar.WinUI.exe') -PathType Leaf)){throw 'WinUI apphost missing'}
$tools=Join-Path $app 'VC109-tools';New-Item -ItemType Directory -Path $tools | Out-Null
foreach($name in @('prepare_profile.py','switch_provider.py')){Copy-Item -LiteralPath (Join-Path $out ('sealed-tools\'+$name)) -Destination $tools}
$exe=Join-Path $app 'VirtualCar.WinUI.exe'
$b=[IO.File]::ReadAllBytes($exe);$off=[BitConverter]::ToInt32($b,60)
if($b[0] -ne 77 -or $b[1] -ne 90 -or [BitConverter]::ToUInt32($b,$off) -ne 0x4550 -or [BitConverter]::ToUInt16($b,$off+4) -ne 0x8664){throw 'Wrong apphost architecture'}
Get-FileHash -Algorithm SHA256 -LiteralPath $dll,$exe | Format-List
Write-Host 'VC110_BUILD=COMPILED (runtime and VIDA NOT TESTED)'
