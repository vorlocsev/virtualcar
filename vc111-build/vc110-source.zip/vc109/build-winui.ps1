param([Parameter(Mandatory=$true)][string]$Prototype,[Parameter(Mandatory=$true)][string]$Checkout,[Parameter(Mandatory=$true)][string]$Output,[string]$Python='py.exe')
$ErrorActionPreference='Stop'
$out=[IO.Path]::GetFullPath($Output)
if(Test-Path -LiteralPath $out){throw 'Fresh output directory required'}
New-Item -ItemType Directory -Path $out | Out-Null
if($Python -eq 'py.exe'){$argsPy=@('-3')}else{$argsPy=@()}
& $Python @argsPy (Join-Path $PSScriptRoot 'winui\stage_winui.py') --prototype $Prototype --checkout $Checkout --output (Join-Path $out 'source')
if($LASTEXITCODE -ne 0){throw 'Stage failed'}
$app=Join-Path $out 'app'
& dotnet.exe publish (Join-Path $out 'source\emulator\managed\VirtualCar.WinUI\VirtualCar.WinUI.csproj') -c Release -r win-x64 --self-contained true -o $app
if($LASTEXITCODE -ne 0){throw 'WinUI publish failed'}
if(-not (Test-Path -LiteralPath (Join-Path $app 'VirtualCar.WinUI.exe') -PathType Leaf)){throw 'Missing apphost'}
$tools=Join-Path $app 'VC109-tools';New-Item -ItemType Directory -Path $tools | Out-Null
foreach($name in @('prepare_profile.py','switch_provider.py')){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $tools}
Write-Host 'VC109C_WINUI=COMPILED (runtime NOT_TESTED; registry unchanged)'
