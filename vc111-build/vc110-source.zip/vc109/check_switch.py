import unittest
from switch_provider import *
OLD=r'C:\VC099-VIDA-511\provider\VirtualCarJ2534.dll'
NEW=r'C:\VC109-provider\VirtualCarJ2534.dll'
R=dict(old=OLD,new=NEW,old_dll_sha='A'*64,old_ini_sha='B'*64,new_dll_sha='C'*64,new_ini_sha='D'*64,build_sha=BUILD_SHA)
class Fake:
    def __init__(self,lib=OLD,ignore=False): self.lib=lib; self.writes=[]; self.ignore=ignore
    def read(self): return self.lib
    def write(self,p):
        self.writes.append(p)
        if not self.ignore: self.lib=p
class Tests(unittest.TestCase):
    def test_canonical(self): self.assertEqual(verify_registry(dict(FIXED,FunctionLibrary=(OLD,REG_SZ)),0,False),OLD)
    def test_legacy(self):
        with self.assertRaises(ValueError): verify_registry(dict(FIXED,FunctionLibrary=(OLD,REG_SZ)),0,True)
    def test_children(self):
        with self.assertRaises(ValueError): verify_registry(dict(FIXED,FunctionLibrary=(OLD,REG_SZ)),1,False)
    def test_extra_value(self):
        with self.assertRaises(ValueError): verify_registry(dict(FIXED,FunctionLibrary=(OLD,REG_SZ),Unknown=(1,REG_DWORD)),0,False)
    def test_type(self):
        with self.assertRaises(ValueError): verify_registry(dict(FIXED,FunctionLibrary=(OLD,2)),0,False)
    def test_metadata(self):
        with self.assertRaises(ValueError): verify_registry(dict(FIXED,FunctionLibrary=(OLD,REG_SZ),CAN=(0,REG_DWORD)),0,False)
    def test_switch_undo(self):
        f=Fake(); switch(f,R); self.assertEqual(f.lib,NEW); switch(f,R,True); self.assertEqual(f.lib,OLD); self.assertEqual(f.writes,[NEW,OLD])
    def test_conflict(self):
        f=Fake(r'C:\Other\VirtualCarJ2534.dll');
        with self.assertRaises(ValueError): switch(f,R)
        self.assertEqual(f.writes,[])
    def test_double_switch(self):
        f=Fake(NEW)
        with self.assertRaises(ValueError): switch(f,R)
        self.assertEqual(f.writes,[])
    def test_readback(self):
        with self.assertRaises(ValueError): switch(Fake(ignore=True),R)
    def test_rollback_conflict(self):
        f=Fake()
        with self.assertRaises(ValueError): switch(f,R,True)
        self.assertEqual(f.writes,[])
    def test_path(self):
        for p in (r'\\server\share\VirtualCarJ2534.dll',r'C:\a\..\VirtualCarJ2534.dll',r'C:\a\other.dll',r'C:\a\VirtualCarJ2534.dll:stream'):
            self.assertFalse(path_ok(p),p)
    def test_record(self):
        for r in (dict(R,build_sha='0'*64),dict(R,new=OLD),dict(R,old_dll_sha='oops'),dict(R,extra='x')):
            with self.assertRaises(ValueError): validate_record(r)
if __name__=='__main__': unittest.main(verbosity=2)
