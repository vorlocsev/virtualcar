"""VC109A: stage a verified VC108R provider + a byte-preserved local lab profile.
No registry changes, no DLL loading, no access to real hardware.
"""
import argparse, ctypes, hashlib, io, json, os, re, stat, sys, zipfile
from pathlib import Path, PureWindowsPath
BUILD_SHA='2AFC83A052A3A08EDB2659B7A4671BC79C6B45196BE00BAD1C7DC1944FF0A5CE'
BASE='b5671a5f0662d9be75e66314fb7968b2cca61a81'
COMMIT='d70a86113a89c19a7294f426256af9861cf4a99b'
SECTION='VC108N_ExternalStateLab'
GATES=[('Diagnostics','EnableGGDCemLab')]+[(s,'Enabled') for s in ('B3A309_EcmLiveDataLab','B3A314_EcmExtendedLiveLab','B3A267_CurrentDataLab','B3A320_RemVoltageSyncLab','B3A324_SupplyVoltageSyncLab')]
DLL='provider/VirtualCarJ2534.dll'

def sha(data): return hashlib.sha256(data).hexdigest().upper()
def require(ok,msg):
    if not ok: raise ValueError(msg)

def decode_ini(raw):
    require(raw and len(raw)<=8*1024*1024,'INI empty or too large')
    if raw.startswith(b'\xff\xfe'):
        text=raw[2:].decode('utf-16-le'); enc='utf-16-le'
    else:
        require(not raw.startswith((b'\xfe\xff',b'\xef\xbb\xbf')), 'Unsupported INI BOM; use original ANSI or UTF-16LE profile')
        # Latin-1 is a byte-preserving view; keys under inspection are ASCII.
        text=raw.decode('latin-1'); enc='ascii'
    require('\x00' not in text,'Embedded NUL in INI')
    return text,enc

def parse_ini(text):
    sections={}; current=None
    for n,line in enumerate(text.split('\n'),1):
        line=line.strip(' \t\r')
        if not line or line.startswith(';'): continue
        if line.startswith('['):
            require(re.fullmatch(r'\[[^\[\]]+\]',line) is not None,f'Invalid section at line {n}')
            current=line[1:-1].strip().casefold(); require(current not in sections,f'Duplicate section at line {n}'); sections[current]={}; continue
        require(current is not None and '=' in line,f'Unsupported INI line {n}')
        k,v=line.split('=',1); k=k.strip().casefold(); v=v.strip(' \t'); require(k and k not in sections[current],f'Duplicate/empty key at line {n}'); sections[current][k]=v
    return sections

def val(s,section,key): return s.get(section.casefold(),{}).get(key.casefold())
def profile_check(s):
    require(SECTION.casefold() not in s,'External state section already present; use pristine VC107 source')
    for sect,key in GATES: require(val(s,sect,key)=='1',f'Prerequisite missing: [{sect}] {key}=1')
    require(val(s,'J2534_2','Enabled')=='1','J2534-2 gate missing for VIDA profile')
    require(re.fullmatch(r'[A-HJ-NPR-Z0-9]{17}',val(s,'Vehicle','VIN') or '') is not None,'Missing or invalid VIN')
    ecus=val(s,'Vehicle','ECUCount') or ''; require(ecus.isdecimal() and 2<=int(ecus)<=32,'Invalid ECUCount')
    routes=[(val(s,f'ECU{i}','RequestId'),val(s,f'ECU{i}','ResponseId'),val(s,f'ECU{i}','ExpectedBaud')) for i in range(int(ecus))]
    for req,resp in [('18DA10F1','18DAF110'),('18DA50F1','18DAF150')]:
        def norm(x): return (x or '').upper().removeprefix('0X')
        require(sum(norm(a)==req and norm(b)==resp and c=='500000' for a,b,c in routes)==1,'Required ECM/CEM physical route absent or duplicated')

def session_check(text,localappdata):
    s=parse_ini(text); require(set(s)=={SECTION.casefold()},'Copy exactly the Live Control session section')
    v=s[SECTION.casefold()]; require(set(v)=={'enabled','sessiondirectory','sessionid'} and v['enabled']=='1','Unexpected session keys')
    sid=v['sessionid']; directory=v['sessiondirectory']; require(re.fullmatch('[0-9A-F]{32}',sid) is not None and int(sid,16)!=0,'Invalid session ID')
    require(len(directory)<=220 and all(32<=ord(c)<=126 for c in directory),'Unsupported session path')
    require(re.fullmatch(r'[A-Za-z]:\\[^:/\*?"<>|]+',directory) is not None,'Session must be a local Windows path')
    p=PureWindowsPath(directory); require(str(p)==directory and all(not x.endswith((' ','.')) for x in p.parts[1:]),'Ambiguous session path')
    expected=PureWindowsPath(localappdata)/('vc108-'+sid)
    require(p==expected and p.name=='vc108-'+sid,'Session not in the current user Live Control directory')
    return directory,sid

def merge(raw,session_text,localappdata):
    original,enc=decode_ini(raw); s=parse_ini(original); profile_check(s)
    directory,sid=session_check(session_text,localappdata)
    suffix=f'\r\n\r\n[{SECTION}]\r\nEnabled=1\r\nSessionDirectory={directory}\r\nSessionId={sid}\r\n'
    merged=raw+suffix.encode(enc)
    new,_=decode_ini(merged); after=parse_ini(new); del after[SECTION.casefold()]
    require(after==s,'Original settings changed'); return merged,directory

def no_reparse(p):
    for item in [p,*p.parents]:
        info=item.stat(follow_symlinks=False)
        require(not getattr(info,'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT,'Reparse point rejected')

def fixed_ntfs(path):
    root=path.anchor; require(len(root)==3 and root[1:]==':\\','Local drive required')
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    require(k.GetDriveTypeW(ctypes.c_wchar_p(root))==3,'Fixed local drive required')
    fs=ctypes.create_unicode_buffer(32)
    require(k.GetVolumeInformationW(ctypes.c_wchar_p(root),None,0,None,None,None,fs,len(fs)) and fs.value=='NTFS','NTFS required')

def readback(ini,original):
    k=ctypes.WinDLL('kernel32',use_last_error=True); f=k.GetPrivateProfileStringA
    f.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_char_p,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_char_p]; f.restype=ctypes.c_uint32
    path=str(ini).encode('ascii'); s=parse_ini(decode_ini(original)[0]); keys=GATES+[(SECTION,'Enabled'),(SECTION,'SessionDirectory'),(SECTION,'SessionId'),('Vehicle','VIN'),('J2534_2','Enabled')]
    for section,key in keys:
        b=ctypes.create_string_buffer(1024); n=f(section.encode(),key.encode(),b'!MISSING!',b,len(b),path)
        require(0<n<len(b)-1 and b.value==val(s,section,key).encode('ascii'),f'Win32 profile readback mismatch [{section}] {key}')

def extract_dll(package):
    raw=package.read_bytes(); require(sha(raw)==BUILD_SHA,'Wrong inner build ZIP or SHA256 mismatch')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        require(z.namelist().count(DLL)==1,'Missing or duplicate provider DLL')
        info=z.read('BUILD-INFO.txt').decode('utf-8-sig'); require(BASE in info and COMMIT in info,'Build provenance mismatch')
        sums=z.read('SHA256SUMS.txt').decode('utf-8-sig').splitlines()
        found=[line.split('  ',1)[0].upper() for line in sums if '  ' in line and line.split('  ',1)[1].replace('\\','/')==DLL]
        dll=z.read(DLL); require(found==[sha(dll)],'DLL manifest hash mismatch')
        return dll

def main():
    p=argparse.ArgumentParser(); p.add_argument('--build',required=True,type=Path); p.add_argument('--source',required=True,type=Path); p.add_argument('--output',required=True,type=Path); p.add_argument('--expected-source-sha'); a=p.parse_args()
    require(os.name=='nt','Staging requires Windows; tests use pure functions only')
    source=Path(os.path.abspath(a.source)); output=Path(os.path.abspath(a.output)); package=Path(os.path.abspath(a.build))
    require(not output.exists() and output.parent.is_dir(),'Choose a new output directory with existing parent')
    require(output!=source.parent and source.parent not in output.parents,'Output must be outside working provider directory')
    for q in (source,output.parent,package): no_reparse(q); fixed_ntfs(q)
    require(all(32<=ord(c)<=126 for c in str(output)) and len(str(output/'virtualcar.ini'))<480,'Output path incompatible with native INI API')
    raw=source.read_bytes(); require(not a.expected_source_sha or sha(raw)==a.expected_source_sha.upper(),'Source profile hash mismatch')
    merged,directory=merge(raw,sys.stdin.read(4096),os.environ['LOCALAPPDATA'])
    session=Path(directory); no_reparse(session); fixed_ntfs(session)
    for file in ('credentials.dpapi','state.bin'):
        q=session/file; no_reparse(q); require(q.is_file(),'Session file missing')
    # State file may be atomically replaced by the publisher at any time. No read/verify of HMAC here.
    dll=extract_dll(package)
    require(source.read_bytes()==raw,'Source changed during preparation')
    output.mkdir(); ini=output/'virtualcar.ini'; dp=output/'VirtualCarJ2534.dll'
    # No overwrite; on failure leave only the new review directory, no registration.
    with dp.open('xb') as f: f.write(dll)
    with ini.open('xb') as f: f.write(merged)
    require(ini.read_bytes()==merged and dp.read_bytes()==dll and source.read_bytes()==raw,'Copy verification failed')
    readback(ini,merged)
    report={'source_sha256':sha(raw),'candidate_ini_sha256':sha(merged),'candidate_dll_sha256':sha(dll),'build_zip_sha256':BUILD_SHA,'required_gates':len(GATES),'original_preserved':True,'registry_changed':False,'runtime':'NOT_TESTED'}
    (output/'VC109-evidence.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print('VC109_PROFILE=PASS (staged only, not registered)'); print('VC109_PROVIDER='+str(dp)); print('VC109_EVIDENCE='+str(output/'VC109-evidence.json'))

if __name__=='__main__':
    try: main()
    except (ValueError,OSError,KeyError,UnicodeError,zipfile.BadZipFile) as e: print('VC109_PROFILE=FAIL: '+str(e),file=sys.stderr); sys.exit(1)
