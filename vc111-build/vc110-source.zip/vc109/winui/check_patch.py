import hashlib,pathlib,unittest
from patch_window import transform
P=pathlib.Path(__file__).resolve().parent
raw=(P/'LiveControlWindow.base.cs').read_bytes()
class Checks(unittest.TestCase):
 def test_exact(self): self.assertEqual(transform(raw),(P/'LiveControlWindow.cs').read_bytes())
 def test_modified_base(self):
  with self.assertRaises(ValueError): transform(raw+b'\n')
 def test_idempotence_denied(self):
  with self.assertRaises(ValueError): transform(transform(raw))
 def test_script_hashes(self):
  source=(P/'ProviderFlow.cs').read_text()
  for f in ('prepare_profile.py','switch_provider.py'):
   self.assertIn(hashlib.sha256((P.parent/f).read_bytes()).hexdigest().upper(),source)
 def test_end_guard(self):
  self.assertIn('flow is not null && !flow.Restored()',transform(raw).decode())
 def test_explicit_attestation(self):
  s=transform(raw).decode();self.assertIn('flow is null || clientsClosed.IsChecked!=true',s);self.assertIn('clientsClosed.IsChecked=false;RefreshBinding()',s)
 def test_separate_journal(self):
  s=(P/'ProviderFlow.cs').read_text();self.assertIn('vc109-rollback-',s);self.assertIn('vc109-provider-',s);self.assertIn('psi.Verb="runas"',s)
 def test_no_reapply(self):
  s=(P/'ProviderFlow.cs').read_text();self.assertIn('Prepared && !File.Exists(Journal)',s)
if __name__=='__main__':unittest.main(verbosity=2)
