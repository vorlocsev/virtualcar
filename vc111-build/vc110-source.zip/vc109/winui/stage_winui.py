"""Stage VC109C from the immutable VC108R prototype, outside the original checkout."""
import argparse, pathlib, subprocess, sys, shutil
from patch_window import transform
ROOT=pathlib.Path(__file__).resolve().parent.parent
UI=pathlib.Path('emulator/managed/VirtualCar.WinUI')
def stage(proto, checkout, out):
    if out.exists(): raise ValueError('Fresh output required')
    # The original preparer validates exact base SHA and app/project blobs.
    raw=(proto/'winui/LiveControlWindow.cs').read_bytes()
    modified=transform(raw)
    if modified!=(ROOT/'winui/LiveControlWindow.cs').read_bytes(): raise ValueError('Generated patch mismatch')
    subprocess.run([sys.executable,str(proto/'winui/prepare_winui.py'),str(checkout),str(out)],check=True)
    live=out/UI/'LiveControl'; dest=live/'LiveControlWindow.cs'
    if dest.read_bytes()!=raw: raise ValueError('Staged window mismatch')
    dest.write_bytes(modified)
    shutil.copyfile(ROOT/'winui/ProviderFlow.cs',live/'ProviderFlow.cs')
    print('VC109C_STAGE=PASS (source only)')
    print('VC109C_PROJECT='+str(out/UI/'VirtualCar.WinUI.csproj'))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--prototype',required=True,type=pathlib.Path);p.add_argument('--checkout',required=True,type=pathlib.Path);p.add_argument('--output',required=True,type=pathlib.Path);a=p.parse_args();stage(a.prototype.resolve(),a.checkout.resolve(),a.output.resolve())
