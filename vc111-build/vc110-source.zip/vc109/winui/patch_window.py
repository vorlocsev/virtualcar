"""Exact-source patch for VC108R LiveControlWindow. No registry access."""
import hashlib, pathlib, sys
BASE='600a54147162ad50ae02fd4f203989627e2824f4f554c370b6abd8f2aa786221'
def transform(raw):
 if hashlib.sha256(raw).hexdigest()!=BASE: raise ValueError('Unexpected VC108R window source')
 s=raw.decode('utf-8')
 def replace(a,b):
  nonlocal s
  if s.count(a)!=1: raise ValueError('Missing or ambiguous anchor')
  s=s.replace(a,b,1)
 replace('    private LivePublisher? publisher;', '''    private LivePublisher? publisher;
    private ProviderFlow? flow;
    private readonly TextBox pythonPath = new() { Header = "Python executable / Интерпретатор Python" };
    private readonly TextBox toolsPath = new() { Header = "VC109 utility directory / Каталог утилит", Text = System.IO.Path.Combine(AppContext.BaseDirectory,"VC109-tools") };
    private readonly TextBox buildPath = new() { Header = "Original VC108R inner ZIP / Исходный ZIP VC108R", Text = @"E:\\VirtualCar\\Builds\\VC108R-45858063194-1\\VirtualCar-VC108R-development.zip" };
    private readonly TextBox sourcePath = new() { Header = "Existing provider / Рабочий провайдер", Text = @"C:\\VC099-VIDA-511\\provider" };
    private readonly Button stageProvider = new() { Content = "Prepare profile / Подготовить профиль" };
    private readonly Button applyProvider = new() { Content = "Activate provider (UAC) / Подключить" };
    private readonly Button restoreProvider = new() { Content = "Restore provider (UAC) / Вернуть" };
    private readonly TextBlock binding = new() { TextWrapping = TextWrapping.Wrap };
    private bool restored = true, active;
''')
 replace('Synthetic lab only. No hardware or registry changes. / Только виртуальный автомобиль. Без изменения реестра.', 'Synthetic lab only. Provider switch requires explicit approval and UAC. / Только виртуальный автомобиль. Переключение требует подтверждения и UAC.')
 replace('        Content = new ScrollViewer { Content = panel };', '''        foreach (var item in new FrameworkElement[] { pythonPath,toolsPath,buildPath,sourcePath,stageProvider,applyProvider,restoreProvider,binding }) panel.Children.Insert(panel.Children.Count-1,item);
        stageProvider.Click += async (_,_) => await PrepareProviderAsync();
        applyProvider.Click += async (_,_) => await ChangeProviderAsync(false);
        restoreProvider.Click += async (_,_) => await ChangeProviderAsync(true);
        Content = new ScrollViewer { Content = panel };''')
 replace('    private async Task EndAsync()', '''    private void RefreshBinding()
    {
        restored = flow?.Restored() ?? true;
        active = flow?.Active() ?? false;
        binding.Text = flow is null ? "No provider staged / Профиль не подготовлен" :
            (active ? "Candidate registered (receipt unverified)" : restored ? "Original registered" : "UNKNOWN — inspect registry before ending session") + "\\n" + flow.Candidate + "\\nRollback: " + flow.Journal;
    }
    private async Task PrepareProviderAsync()
    {
        if(busy || publisher is null || flow is not null || publisher.Read().Snapshot is null) return;
        busy=true; Render();
        try {
            var candidate=new ProviderFlow(pythonPath.Text,toolsPath.Text,buildPath.Text,sourcePath.Text,publisher.SessionId);
            flow=candidate;
            await candidate.PrepareAsync(profile.Text);
            notice="Profile prepared; registry unchanged / Профиль готов, реестр не изменён";
        } catch(Exception ex) { notice="Preparation failed / Ошибка: "+ex.Message; }
        finally { RefreshBinding();busy=false;Render(); }
    }
    private async Task ChangeProviderAsync(bool rollback)
    {
        if(busy || flow is null || clientsClosed.IsChecked!=true) return;
        if(rollback ? !flow.Active() : (!flow.CanApply || !flow.Restored() || publisher?.Read().Snapshot is null)) return;
        busy=true;Render();
        try { if(rollback) await flow.RollbackAsync(); else await flow.ApplyAsync(); notice=rollback?"Original restored / Восстановлен":"Candidate registered / Подключён"; }
        catch(Exception ex) { notice="Switch incomplete / Ошибка: "+ex.Message; }
        finally { clientsClosed.IsChecked=false;RefreshBinding();busy=false;Render(); }
    }
    private async Task EndAsync()''')
 replace('        if (busy || publisher is null || clientsClosed.IsChecked != true) return;', '        if (busy || publisher is null || clientsClosed.IsChecked != true || (flow is not null && !flow.Restored())) return;')
 replace('finally { publisher = null; profile.Text = "";', 'finally { publisher = null; flow = null; RefreshBinding(); profile.Text = "";')
 replace('            end.IsEnabled = clientsClosed.IsEnabled && clientsClosed.IsChecked == true;', '''            end.IsEnabled = clientsClosed.IsEnabled && clientsClosed.IsChecked == true && restored;
            stageProvider.IsEnabled=ready && flow is null;
            applyProvider.IsEnabled=ready && flow?.CanApply==true && restored && clientsClosed.IsChecked==true;
            restoreProvider.IsEnabled=!busy && flow is not null && active && clientsClosed.IsChecked==true;
            pythonPath.IsEnabled=toolsPath.IsEnabled=buildPath.IsEnabled=sourcePath.IsEnabled=!busy && flow is null;''')
 # Refresh when operator changes attestation, also permits recovery from manual rollback.
 replace('clientsClosed.Checked += (_,_) => Render(); clientsClosed.Unchecked += (_,_) => Render();','clientsClosed.Checked += (_,_) => { RefreshBinding(); Render(); }; clientsClosed.Unchecked += (_,_) => { RefreshBinding(); Render(); };')
 return s.encode('utf-8')
if __name__=='__main__':
 src=pathlib.Path(sys.argv[1]); dest=pathlib.Path(sys.argv[2]); data=transform(src.read_bytes());
 with dest.open('xb') as f: f.write(data)
