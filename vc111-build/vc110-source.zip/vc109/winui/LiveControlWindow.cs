using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Automation;
using VirtualCar.LivePrototype;

namespace VirtualCar.WinUI;

// Explicit isolated lab mode only. No provider registration or INI writes.
internal sealed class LiveControlWindow : Window
{
    private readonly Button create = new() { Content = "Create session / Создать сеанс" };
    private readonly Button end = new() { Content = "End session / Завершить сеанс" };
    private readonly CheckBox clientsClosed = new() { Content = "VIDA and all readers closed / VIDA и клиенты закрыты" };
    private readonly ComboBox ignition = new() { Header = "Ignition / Зажигание", HorizontalAlignment = HorizontalAlignment.Stretch };
    private readonly Button start = new() { Content = "Start" }, stop = new() { Content = "Stop" }, reset = new() { Content = "Reset" };
    private readonly Slider pedal = new() { Header = "Accelerator / Акселератор (%)", Minimum = 0, Maximum = 100, StepFrequency = 1 };
    private readonly TextBlock status = new() { TextWrapping = TextWrapping.Wrap };
    private readonly TextBlock values = new() { FontSize = 20, TextWrapping = TextWrapping.Wrap };
    private readonly TextBox profile = new() { Header = "Candidate INI section / Секция тестового INI", IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap };
    private readonly DispatcherTimer timer = new() { Interval = TimeSpan.FromMilliseconds(100) };
    private LivePublisher? publisher;
    private ProviderFlow? flow;
    private readonly TextBox pythonPath = new() { Header = "Python executable / Интерпретатор Python" };
    private readonly TextBox toolsPath = new() { Header = "VC109 utility directory / Каталог утилит", Text = System.IO.Path.Combine(AppContext.BaseDirectory,"VC109-tools") };
    private readonly TextBox buildPath = new() { Header = "Original VC108R inner ZIP / Исходный ZIP VC108R", Text = @"E:\VirtualCar\Builds\VC108R-45858063194-1\VirtualCar-VC108R-development.zip" };
    private readonly TextBox sourcePath = new() { Header = "Existing provider / Рабочий провайдер", Text = @"C:\VC099-VIDA-511\provider" };
    private readonly Button stageProvider = new() { Content = "Prepare profile / Подготовить профиль" };
    private readonly Button applyProvider = new() { Content = "Activate provider (UAC) / Подключить" };
    private readonly Button restoreProvider = new() { Content = "Restore provider (UAC) / Вернуть" };
    private readonly TextBlock binding = new() { TextWrapping = TextWrapping.Wrap };
    private bool restored = true, active;

    private bool busy, rendering;
    private ulong renderedSequence;
    private string notice = "";
    public LiveControlWindow()
    {
        Title = "Virtual Car — Live Control Lab";
        var panel = new StackPanel { Padding = new Thickness(24), Spacing = 12 };
        panel.Children.Add(new TextBlock { Text = "Live vehicle control / Управление автомобилем", FontSize = 26, TextWrapping = TextWrapping.Wrap });
        panel.Children.Add(new TextBlock { Text = "Synthetic lab only. Provider switch requires explicit approval and UAC. / Только виртуальный автомобиль. Переключение требует подтверждения и UAC.", TextWrapping = TextWrapping.Wrap });
        foreach (var item in new FrameworkElement[] { create, status, profile, ignition }) panel.Children.Add(item);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        buttons.Children.Add(start); buttons.Children.Add(stop); buttons.Children.Add(reset); panel.Children.Add(buttons);
        foreach (var item in new FrameworkElement[] { pedal, values, clientsClosed, end }) panel.Children.Add(item);
        foreach (var item in new FrameworkElement[] { pythonPath,toolsPath,buildPath,sourcePath,stageProvider,applyProvider,restoreProvider,binding }) panel.Children.Insert(panel.Children.Count-1,item);
        stageProvider.Click += async (_,_) => await PrepareProviderAsync();
        applyProvider.Click += async (_,_) => await ChangeProviderAsync(false);
        restoreProvider.Click += async (_,_) => await ChangeProviderAsync(true);
        Content = new ScrollViewer { Content = panel };
        foreach (var item in new[] { "0 — Off", "I — Accessory (CEM not verified)", "II — On" }) ignition.Items.Add(item);
        foreach (var pair in new (DependencyObject Element, string Id)[] { (create,"Create"),(end,"End"),(clientsClosed,"ReadersClosed"),(ignition,"Ignition"),(start,"Start"),(stop,"Stop"),(reset,"Reset"),(pedal,"Pedal"),(status,"Status"),(values,"Values"),(profile,"Profile") })
            AutomationProperties.SetAutomationId(pair.Element,"VC108O."+pair.Id);
        create.Click += async (_,_) => await CreateAsync();
        end.Click += async (_,_) => await EndAsync();
        ignition.SelectionChanged += (_,_) => { if (!rendering && ignition.SelectedIndex >= 0) Act(p => p.SetIgnition((Ignition)ignition.SelectedIndex)); };
        start.Click += (_,_) => Act(p => p.Start()); stop.Click += (_,_) => Act(p => p.Stop()); reset.Click += (_,_) => Act(p => p.Reset());
        pedal.ValueChanged += (_,_) => { if (!rendering) Act(p => p.Pedal((int)Math.Round(pedal.Value * 10))); };
        clientsClosed.Checked += (_,_) => { RefreshBinding(); Render(); }; clientsClosed.Unchecked += (_,_) => { RefreshBinding(); Render(); };
        timer.Tick += (_,_) => Render();
        AppWindow.Closing += (_,args) => { if (publisher is not null || busy) { args.Cancel = true; notice = "Close diagnostic readers, then End session. / Закройте клиентов и завершите сеанс."; Render(); } };
        Closed += (_,_) => timer.Stop();
        Render(); timer.Start();
    }
    private void Act(Action<LivePublisher> action)
    {
        if (busy || publisher is null) return;
        try { action(publisher); notice = ""; } catch (InvalidOperationException) { notice = "Command rejected / Команда отклонена"; Render(); }
    }
    private async Task CreateAsync()
    {
        if (busy || publisher is not null) return;
        busy = true; notice = ""; Render();
        try
        {
            publisher = await Task.Run(LivePublisher.Create);
            profile.Text = "[VC108N_ExternalStateLab]\r\nEnabled=1\r\nSessionDirectory=" + publisher.DirectoryPath + "\r\nSessionId=" + publisher.SessionId;
        }
        catch (Exception ex) { notice = "Session creation failed / Ошибка создания: " + ex.GetType().Name; }
        finally { busy = false; Render(); }
    }
    private void RefreshBinding()
    {
        restored = flow?.Restored() ?? true;
        active = flow?.Active() ?? false;
        binding.Text = flow is null ? "No provider staged / Профиль не подготовлен" :
            (active ? "Candidate registered (receipt unverified)" : restored ? "Original registered" : "UNKNOWN — inspect registry before ending session") + "\n" + flow.Candidate + "\nRollback: " + flow.Journal;
    }
    private async Task PrepareProviderAsync()
    {
        if(busy || publisher is null || flow is not null || publisher.Read().Snapshot is null) return;
        busy=true; Render();
        try {
            var candidate=new ProviderFlow(pythonPath.Text,toolsPath.Text,buildPath.Text,sourcePath.Text,publisher.SessionId);
            flow=candidate;
            await candidate.PrepareAsync(profile.Text);
            notice="Profile prepared; registry unchanged / Профиль готов, реестр не изменён";
        } catch(Exception ex) { notice="Preparation failed / Ошибка: "+ex.Message; }
        finally { RefreshBinding();busy=false;Render(); }
    }
    private async Task ChangeProviderAsync(bool rollback)
    {
        if(busy || flow is null || clientsClosed.IsChecked!=true) return;
        if(rollback ? !flow.Active() : (!flow.CanApply || !flow.Restored() || publisher?.Read().Snapshot is null)) return;
        busy=true;Render();
        try { if(rollback) await flow.RollbackAsync(); else await flow.ApplyAsync(); notice=rollback?"Original restored / Восстановлен":"Candidate registered / Подключён"; }
        catch(Exception ex) { notice="Switch incomplete / Ошибка: "+ex.Message; }
        finally { clientsClosed.IsChecked=false;RefreshBinding();busy=false;Render(); }
    }
    private async Task EndAsync()
    {
        if (busy || publisher is null || clientsClosed.IsChecked != true || (flow is not null && !flow.Restored())) return;
        busy = true; Render();
        var current = publisher;
        try { await current.EndAsync(); notice = "Session ended / Сеанс завершён"; }
        catch (Exception ex) { notice = "Cleanup incomplete / Очистка не завершена: " + ex.GetType().Name; }
        finally { publisher = null; flow = null; RefreshBinding(); profile.Text = ""; clientsClosed.IsChecked = false; busy = false; Render(); }
    }
    private void Render()
    {
        rendering = true;
        try
        {
            var state = publisher?.Read(); var s = state?.Snapshot;
            bool ready = !busy && state?.Failed == false && s.HasValue;
            create.IsEnabled = !busy && publisher is null; clientsClosed.IsEnabled = !busy && publisher is not null;
            end.IsEnabled = clientsClosed.IsEnabled && clientsClosed.IsChecked == true && restored;
            stageProvider.IsEnabled=ready && flow is null;
            applyProvider.IsEnabled=ready && flow?.CanApply==true && restored && clientsClosed.IsChecked==true;
            restoreProvider.IsEnabled=!busy && flow is not null && active && clientsClosed.IsChecked==true;
            pythonPath.IsEnabled=toolsPath.IsEnabled=buildPath.IsEnabled=sourcePath.IsEnabled=!busy && flow is null;
            ignition.IsEnabled = reset.IsEnabled = ready;
            start.IsEnabled = ready && s!.Value.Ignition == Ignition.On && s.Value.Engine == Engine.Off;
            stop.IsEnabled = ready && s!.Value.Engine != Engine.Off;
            pedal.IsEnabled = ready && s!.Value.Engine == Engine.Running;
            if (s.HasValue && s.Value.Sequence != renderedSequence)
            {
                renderedSequence = s.Value.Sequence;
                ignition.SelectedIndex = (int)s.Value.Ignition;
                pedal.Value = s.Value.Ecm.PedalPermille / 10.0;
            }
            else if (!s.HasValue) { renderedSequence = 0; ignition.SelectedIndex = 0; pedal.Value = 0; }
            string message = busy ? "Busy / Выполняется" : state?.Failed == true ? "Publishing failed; no live data / Ошибка публикации" : ready ? "Published locally; DLL receipt unverified / Опубликовано, приём DLL не проверен" : publisher is null ? "No session / Нет сеанса" : "Waiting for fresh publication / Ожидание актуального снимка";
            status.Text = message + (notice.Length == 0 ? "" : "\n" + notice);
            if (s is VehicleSnapshot v)
            {
                var e = v.Ecm;
                values.Text = $"{v.Engine} · {e.Rpm} rpm\n{e.BatteryMv/1000.0:F2} V · {e.CoolantC} °C\nMAF {e.MafCentiGps/100.0:F2} g/s · MAP {e.ManifoldKpa} kPa\nLoad {e.LoadPermille/10.0:F1}% · {e.SpeedKph} km/h\nSequence: {v.Sequence}";
            }
            else values.Text = "—";
        }
        finally { rendering = false; }
    }
}
