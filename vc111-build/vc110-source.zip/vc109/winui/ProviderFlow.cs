using System.Diagnostics;
using System.Security.Cryptography;
using Microsoft.Win32;

namespace VirtualCar.WinUI;

// Uses the already-reviewed VC109A/B utilities. The original provider stays untouched.
// A separate journal is kept outside the DPAPI session so rollback survives UI exit.
internal sealed class ProviderFlow
{
    private const string RegistryPath = @"SOFTWARE\PassThruSupport.04.04\J2534 Lab Adapter";
    private const string Dll = "VirtualCarJ2534.dll";
    private readonly string python, tools, build, source;
    private const string PrepareHash = "86EBA3912A0CCEE4A2EBD75B6D444FD0B68AD6D2A4C62029FBD215BCE91BD0D1";
    private const string SwitchHash = "8F936059CC7483C992DA5421DBF6D359939517318EB3E1F89FC36463F1E59ED6";
    public string Candidate { get; }
    public string Journal { get; }
    public string Original => Path.Combine(source,Dll);
    public string Target => Path.Combine(Candidate,Dll);
    public bool Prepared { get; private set; }
    public bool CanApply => Prepared && !File.Exists(Journal);
    public ProviderFlow(string interpreter,string toolDirectory,string package,string sourceDirectory,string sessionId)
    {
        python=LocalPath(interpreter); tools=LocalPath(toolDirectory); build=LocalPath(package); source=LocalPath(sourceDirectory);
        if (!File.Exists(python) || !File.Exists(build) || !Directory.Exists(tools) || !Directory.Exists(source)) throw new IOException("Required paths missing");
        if (sessionId.Length!=32 || sessionId.Any(c=>!Uri.IsHexDigit(c))) throw new ArgumentException("Invalid session ID");
        var parent=LocalPath(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
        Candidate=Path.Combine(parent,"vc109-provider-"+sessionId); Journal=Path.Combine(parent,"vc109-rollback-"+sessionId+".json");
        if (Directory.Exists(Candidate)||File.Exists(Candidate)||File.Exists(Journal)||Directory.Exists(Journal)) throw new IOException("Candidate or journal already exists");
        if (!Restored()) throw new InvalidOperationException("Original registration not selected");
        VerifyTools();
    }
    private static string LocalPath(string p)
    {
        if (!Path.IsPathFullyQualified(p) || p.StartsWith(@"\\",StringComparison.Ordinal)) throw new ArgumentException("Absolute local path required");
        string full=Path.GetFullPath(p);
        if (new DriveInfo(Path.GetPathRoot(full)!).DriveType!=DriveType.Fixed) throw new IOException("Fixed drive required");
        for (string? item=full;item is not null;item=Path.GetDirectoryName(item))
            if ((File.Exists(item)||Directory.Exists(item)) && (File.GetAttributes(item)&FileAttributes.ReparsePoint)!=0) throw new IOException("Reparse path rejected");
        return full;
    }
    private string Script(string name,string expected)
    {
        string p=LocalPath(Path.Combine(tools,name));
        using var f=File.OpenRead(p);
        if (!Convert.ToHexString(SHA256.HashData(f)).Equals(expected,StringComparison.Ordinal)) throw new IOException("Utility fingerprint mismatch: "+name);
        return p;
    }
    private void VerifyTools(){ _=Script("prepare_profile.py",PrepareHash); _=Script("switch_provider.py",SwitchHash); }
    private static string? ReadProvider()
    {
        using var root=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,RegistryView.Registry32);
        using var key=root.OpenSubKey(RegistryPath);
        return key?.GetValue("FunctionLibrary",null,RegistryValueOptions.DoNotExpandEnvironmentNames) as string;
    }
    private static bool Same(string? a,string b)=>string.Equals(a,b,StringComparison.OrdinalIgnoreCase);
    public bool Restored(){try{return Same(ReadProvider(),Original);}catch{return false;}}
    public bool Active(){try{return Same(ReadProvider(),Target);}catch{return false;}}
    private string[] SwitchArgs(string action)=>[action,"--source",source,"--candidate",Candidate,"--build",build,"--journal",Journal];
    public async Task PrepareAsync(string section)
    {
        VerifyTools();
        await RunAsync(Script("prepare_profile.py",PrepareHash),["--source",Path.Combine(source,"virtualcar.ini"),"--output",Candidate,"--build",build],section,false);
        await RunAsync(Script("switch_provider.py",SwitchHash),SwitchArgs("plan"),null,false);
        if(!Restored()) throw new IOException("Registration changed during preparation");
        Prepared=true;
    }
    public async Task ApplyAsync()
    {
        if(!CanApply||!Restored()) throw new InvalidOperationException("Fresh prepared candidate required");
        VerifyTools();
        await RunAsync(Script("switch_provider.py",SwitchHash),[..SwitchArgs("apply"),"--clients-closed"],null,true);
        if(!Active()||!File.Exists(Journal)) throw new IOException("Switch readback failed; review journal");
    }
    public async Task RollbackAsync()
    {
        if(!Active()||!File.Exists(Journal)) throw new InvalidOperationException("No matching active candidate/journal");
        VerifyTools();
        await RunAsync(Script("switch_provider.py",SwitchHash),["rollback","--journal",Journal,"--clients-closed"],null,true);
        if(!Restored()) throw new IOException("Rollback readback failed");
    }
    private async Task RunAsync(string script,string[] args,string? input,bool elevate)
    {
        var psi=new ProcessStartInfo(python){UseShellExecute=elevate,WorkingDirectory=tools};
        // Ignore Python environment / user site and avoid writing pycache. Same-user
        // malicious processes and arbitrary administrator modifications are out of scope.
        foreach(var arg in new[]{"-E","-s","-B",script}.Concat(args)) psi.ArgumentList.Add(arg);
        if(elevate) psi.Verb="runas";
        else {psi.RedirectStandardInput=true;psi.RedirectStandardOutput=true;psi.RedirectStandardError=true;psi.CreateNoWindow=true;}
        using var p=Process.Start(psi)??throw new IOException("Could not start helper");
        if(elevate) {await p.WaitForExitAsync();if(p.ExitCode!=0) throw new IOException("Elevated helper failed: "+p.ExitCode);return;}
        var stdout=p.StandardOutput.ReadToEndAsync();var stderr=p.StandardError.ReadToEndAsync();
        try {if(input is not null) await p.StandardInput.WriteAsync(input);p.StandardInput.Close();await p.WaitForExitAsync().WaitAsync(TimeSpan.FromMinutes(2));}
        catch {if(!p.HasExited){p.Kill();await p.WaitForExitAsync();}throw;}
        _=await stdout;_=await stderr;
        if(p.ExitCode!=0) throw new IOException("Profile helper failed: "+p.ExitCode+". Review the utility manually.");
    }
}
