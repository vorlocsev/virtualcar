"""VC109B: explicit, reversible canonical J2534 registry pointer switch.
No DLL loading, registration of additional devices, or changes to existing INI/DLL.
"""
import argparse, json, os, re, sys
from pathlib import Path, PureWindowsPath
from prepare_profile import (require, sha, extract_dll, no_reparse, fixed_ntfs,
                             decode_ini, parse_ini, merge, SECTION, BUILD_SHA)
PARENT=r'SOFTWARE\PassThruSupport.04.04'
NAME='J2534 Lab Adapter'
LEGACY='SectorV Virtual Car'
REG_SZ=1; REG_DWORD=4
FIXED={'Vendor':('J2534 Lab',REG_SZ),'Name':(NAME,REG_SZ),'ConfigApplication':('',REG_SZ),'CAN':(1,REG_DWORD),'ISO15765':(1,REG_DWORD),'MessageVersion':(0x0404,REG_DWORD)}

def same(a,b): return PureWindowsPath(a)==PureWindowsPath(b)
def path_ok(s):
    p=PureWindowsPath(s)
    return (p.is_absolute() and len(p.drive)==2 and p.drive[1]==':' and
            p.name.casefold()=='virtualcarj2534.dll' and ':' not in s[2:] and
            all(x not in ('.','..') and not x.endswith((' ','.')) for x in p.parts[1:]) and
            str(p)==s)

def verify_registry(values,children,legacy):
    require(not children and not legacy,'Noncanonical/legacy registration conflict')
    require(set(values)==set(FIXED)|{'FunctionLibrary'},'Unexpected registration values')
    require(all(tuple(values[k])==v for k,v in FIXED.items()),'Provider metadata differs from canonical')
    lib,kind=values['FunctionLibrary']; require(kind==REG_SZ and isinstance(lib,str) and path_ok(lib),'Invalid FunctionLibrary')
    return lib

def verify_binding(current,expected,other):
    require(path_ok(expected) and path_ok(other) and not same(expected,other),'Invalid switch paths')
    require(same(current,expected),'Registry changed or unexpected provider path')

def hashfile(p): return sha(p.read_bytes())
def local_file(p):
    require(p.is_file(),'Required file missing: '+str(p)); no_reparse(p); fixed_ntfs(p); return p

def evidence(source,candidate,package):
    old=local_file(source/'VirtualCarJ2534.dll'); new=local_file(candidate/'VirtualCarJ2534.dll')
    oi=local_file(source/'virtualcar.ini'); ni=local_file(candidate/'virtualcar.ini')
    report=json.loads(local_file(candidate/'VC109-evidence.json').read_text(encoding='utf-8'))
    raw=oi.read_bytes(); merged=ni.read_bytes()
    require(report.get('source_sha256')==sha(raw) and report.get('candidate_ini_sha256')==sha(merged),'Staging INI evidence mismatch')
    require(report.get('build_zip_sha256')==BUILD_SHA and report.get('candidate_dll_sha256')==hashfile(new),'Staging DLL evidence mismatch')
    require(new.read_bytes()==extract_dll(local_file(package)),'Candidate DLL differs from verified build')
    ini=parse_ini(decode_ini(merged)[0]); sess=ini[SECTION.casefold()]
    session_text='['+SECTION+']\r\n'+''.join(k+'='+v+'\r\n' for k,v in sess.items())
    expected,directory=merge(raw,session_text,os.environ['LOCALAPPDATA'])
    require(expected==merged,'Candidate INI is not the exact staged profile')
    for name in ('credentials.dpapi','state.bin'): local_file(Path(directory)/name)
    return {'old':str(old),'new':str(new),'old_dll_sha':hashfile(old),'old_ini_sha':sha(raw),'new_dll_sha':hashfile(new),'new_ini_sha':sha(merged),'build_sha':BUILD_SHA}

def validate_record(r):
    require(isinstance(r,dict) and set(r)=={'old','new','old_dll_sha','old_ini_sha','new_dll_sha','new_ini_sha','build_sha'},'Invalid rollback record')
    require(all(isinstance(x,str) for x in r.values()),'Invalid rollback fields')
    require(path_ok(r['old']) and path_ok(r['new']) and not same(r['old'],r['new']),'Invalid rollback paths')
    require(r['build_sha']==BUILD_SHA and all(re.fullmatch('[0-9A-F]{64}',r[k]) for k in ('old_dll_sha','old_ini_sha','new_dll_sha','new_ini_sha')),'Invalid rollback fingerprints')

def check_files(r,side):
    p=local_file(Path(r[side])); ini=local_file(p.parent/'virtualcar.ini')
    require(hashfile(p)==r[side+'_dll_sha'] and hashfile(ini)==r[side+'_ini_sha'],side+' files changed')

def switch(reg,record,undo=False):
    validate_record(record)
    before,after=('new','old') if undo else ('old','new')
    verify_binding(reg.read(),record[before],record[after])
    reg.write(record[after]); require(same(reg.read(),record[after]),'Registry readback failed; inspect journal before retry')

class Registry:
    def __init__(self,writable):
        import winreg as w
        self.w=w; self.root=w.OpenKey(w.HKEY_LOCAL_MACHINE,PARENT,0,w.KEY_READ|w.KEY_WOW64_32KEY)
        self.key=w.OpenKey(self.root,NAME,0,w.KEY_READ|(w.KEY_SET_VALUE if writable else 0)|w.KEY_WOW64_32KEY)
    def read(self):
        w=self.w; children,n,_=w.QueryInfoKey(self.key); values={}
        for i in range(n):
            k,v,t=w.EnumValue(self.key,i); values[k]=(v,t)
        try:
            with w.OpenKey(self.root,LEGACY): legacy=True
        except FileNotFoundError: legacy=False
        return verify_registry(values,children,legacy)
    def write(self,path):
        self.w.SetValueEx(self.key,'FunctionLibrary',0,self.w.REG_SZ,path); self.w.FlushKey(self.key)
    def close(self): self.key.Close(); self.root.Close()

def main():
    p=argparse.ArgumentParser(); p.add_argument('action',choices=['plan','apply','rollback']); p.add_argument('--source',type=Path); p.add_argument('--candidate',type=Path); p.add_argument('--build',type=Path); p.add_argument('--journal',required=True,type=Path); p.add_argument('--clients-closed',action='store_true'); a=p.parse_args()
    require(os.name=='nt','Windows required'); writable=a.action!='plan'
    require(not writable or a.clients_closed,'Close all diagnostic readers and confirm --clients-closed')
    journal=Path(os.path.abspath(a.journal)); no_reparse(journal.parent); fixed_ntfs(journal.parent)
    reg=Registry(writable)
    try:
        if a.action=='rollback':
            r=json.loads(local_file(journal).read_text(encoding='utf-8')); validate_record(r)
            check_files(r,'old'); switch(reg,r,True); print('VC109_ROLLBACK=PASS'); return
        require(all((a.source,a.candidate,a.build)),'Source, candidate and build required')
        source=Path(os.path.abspath(a.source)); candidate=Path(os.path.abspath(a.candidate))
        require(source!=candidate and source not in candidate.parents and candidate not in source.parents,'Provider directories must be isolated')
        require(not journal.exists() and journal.parent not in (source,candidate) and source not in journal.parents and candidate not in journal.parents,'Use a new journal outside both providers')
        r=evidence(source,candidate,Path(os.path.abspath(a.build))); validate_record(r)
        verify_binding(reg.read(),r['old'],r['new'])
        if a.action=='plan': print('VC109_SWITCH_PLAN=PASS (no writes)'); print('FROM='+r['old']); print('TO='+r['new']); return
        # Durable journal before the single registry value write. Never overwrite it.
        with journal.open('x',encoding='utf-8') as f:
            json.dump(r,f,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
        check_files(r,'old'); check_files(r,'new'); switch(reg,r)
        print('VC109_SWITCH=PASS (registry readback only, runtime NOT_TESTED)'); print('ROLLBACK_JOURNAL='+str(journal))
    finally: reg.close()

if __name__=='__main__':
    try: main()
    except (ValueError,OSError,KeyError,TypeError) as e:
        print('VC109_SWITCH=FAIL: '+str(e),file=sys.stderr); sys.exit(1)
