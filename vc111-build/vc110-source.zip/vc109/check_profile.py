import unittest, tempfile
from unittest.mock import patch
import prepare_profile as module
from prepare_profile import *
ID='1234567890ABCDEF1234567890ABCDEF'; PARENT=r'C:\Users\Lab\AppData\Local'; DIR=PARENT+'\\vc108-'+ID
SESSION=f'[{SECTION}]\r\nEnabled=1\r\nSessionDirectory={DIR}\r\nSessionId={ID}'
INI='[Vehicle]\r\nVIN=YV1CZ0002A0000001\r\nECUCount=2\r\n[ECU0]\r\nRequestId=18DA10F1\r\nResponseId=18DAF110\r\nExpectedBaud=500000\r\n[ECU1]\r\nRequestId=18DA50F1\r\nResponseId=18DAF150\r\nExpectedBaud=500000\r\n[J2534_2]\r\nEnabled=1\r\n'+''.join(f'[{s}]\r\n{k}=1\r\n' for s,k in GATES)+'[D2_Node0]\r\nFrame0=8F 40 F9 F0 00 00 00 00\r\n; comment\xff\r\n'
class T(unittest.TestCase):
 def check(self,raw=None,session=SESSION,parent=PARENT): return merge(INI.encode('latin1') if raw is None else raw,session,parent)
 def reject(self,raw=None,session=SESSION,parent=PARENT):
  with self.assertRaises((ValueError,UnicodeError)): self.check(raw,session,parent)
 def test_ansi(self):
  raw=INI.encode('latin1'); merged,d=self.check(raw); self.assertTrue(merged.startswith(raw)); self.assertEqual(d,DIR)
 def test_utf16(self):
  raw=b'\xff\xfe'+INI.encode('utf-16-le'); merged,_=self.check(raw); self.assertTrue(merged.startswith(raw)); self.assertIn(SECTION,merged.decode('utf-16-le'))
 def test_all_gates(self):
  for s,k in GATES: self.reject(INI.replace(f'[{s}]\r\n{k}=1',f'[{s}]\r\n{k}=0').encode('latin1'))
 def test_missing_ps(self): self.reject(INI.replace('[J2534_2]\r\nEnabled=1','[J2534_2]\r\nEnabled=0').encode('latin1'))
 def test_missing_route(self): self.reject(INI.replace('18DAF110','18DAF111').encode('latin1'))
 def test_duplicate_section(self): self.reject((INI+'[vehicle]\r\nVIN=YV1CZ0002A0000001').encode('latin1'))
 def test_duplicate_key(self): self.reject(INI.replace('ECUCount=2','ECUCount=2\r\nECUCount=3').encode('latin1'))
 def test_existing_external(self): self.reject((INI+SESSION).encode('latin1'))
 def test_sid(self): self.reject(session=SESSION.replace(ID,ID.lower()))
 def test_wrong_parent(self): self.reject(parent=r'C:\Other')
 def test_extra_key(self): self.reject(session=SESSION+'\r\nSecret=abc')
 def test_bad_path(self):
  for path in [r'\\server\share',r'C:\a\..\b',DIR+' ',DIR+':stream',DIR+'\\']:
   # trailing whitespace stripped by INI parser; trailing space after full path is rejected by Windows readback only if semantically different.
   if path==DIR+' ': continue
   self.reject(session=SESSION.replace(DIR,path))
 def test_bom(self): self.reject(b'\xef\xbb\xbf'+INI.encode('latin1'))
 def test_nul(self): self.reject(INI.encode('latin1')+b'\0')
 def test_vin(self): self.reject(INI.replace('YV1CZ0002A0000001','INVALID').encode('latin1'))
 def test_archive(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'test.zip'; data=b'synthetic DLL fixture'
   with zipfile.ZipFile(p,'w') as z:
    z.writestr(DLL,data); z.writestr('BUILD-INFO.txt',BASE+' '+COMMIT); z.writestr('SHA256SUMS.txt',sha(data)+'  provider\\VirtualCarJ2534.dll\n')
   with patch.object(module,'BUILD_SHA',sha(p.read_bytes())): self.assertEqual(extract_dll(p),data)
   with self.assertRaises(ValueError): extract_dll(p)
 def test_archive_manifest(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'test.zip'
   with zipfile.ZipFile(p,'w') as z:
    z.writestr(DLL,b'test'); z.writestr('BUILD-INFO.txt',BASE+' '+COMMIT); z.writestr('SHA256SUMS.txt','0'*64+'  '+DLL+'\n')
   with patch.object(module,'BUILD_SHA',sha(p.read_bytes())):
    with self.assertRaises(ValueError): extract_dll(p)
if __name__=='__main__': unittest.main(verbosity=2)
