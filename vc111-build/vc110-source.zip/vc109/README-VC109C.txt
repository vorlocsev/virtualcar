VC109C — WinUI profile orchestration, experimental source candidate.

Uses the already compiled VC108R x86 provider (inner ZIP hash is pinned by
prepare_profile.py). New WinUI x64 build required; no new native DLL needed.
No automatic activation on startup or at session creation. Normal app startup
is unchanged; this is only the --live-control mode.

Build from a fresh output directory with .NET 10 SDK on Windows / VMware:
  powershell.exe -NoProfile -File .\build-winui.ps1 -Prototype C:\VC108R-prototype -Checkout C:\VirtualCar-PR511 -Output C:\VC109C-review
On VMware runner use -Python with the exact interpreter path read from
E:\VirtualCar\Tools\python312.path. The prototype must be the extracted VC108R
source archive, not the compiled package. The checkout must be exact PR511 head.
The script creates a source checkout and an app folder; it does not register.

Run C:\VC109C-review\app\VirtualCar.WinUI.exe --live-control as the normal
Windows user who will use VIDA. Specify a trusted absolute python.exe path;
VC109-tools is copied next to app by the build. Specify the exact original
compiled inner VC108R ZIP and the existing VC107 provider directory. Defaults
are the previously observed VMware package and working provider paths.
1. Create session, wait for local state publication.
2. Prepare profile: invokes VC109A with the session section via stdin, then
   VC109B plan. Original INI copied byte-for-byte; no registry mutation.
3. Close all diagnostic readers and confirm checkbox. Click Activate; the
   selected Python executable runs the pinned utility via explicit UAC.
   Do not use a different admin account for activation; DPAPI is current-user.
4. Open VIDA manually only after successful registry readback. Readback is
   not evidence of DLL loading or state receipt. No ECU write operations.
5. Close VIDA and other readers, tick checkbox again, click Restore. Verify
   original provider path restored before End session. Reapply is disabled
   for a used journal; create a new session instead.

Candidate and journal are unique to session under LOCALAPPDATA, separate
from the private DPAPI directory. They are retained for review/recovery.
If the UI is interrupted, use the exact rollback journal and the original
VC109B command from an elevated shell. If registry readback is unknown,
End session refuses to run; inspect the registry and restore before closing.
This does not prevent OS shutdown, crash, or changes made by outside tools.
Do not run concurrent external installers; client closure is still attested
by the operator. The user-chosen Python interpreter and same-user environment
must be trusted; helper script hashes are pinned but this is not a security
boundary against malicious local administrators or same-user processes.
No secrets are passed via command line; the session section is sent via stdin.

Tests run on Linux: 17 profile checks, 13 mocked registry checks, 8 exact-source
patch/static contract checks. The C# coordinator and WinUI patch have not been
compiled or executed on Windows. The 8 static tests are not UI, UAC, or runtime
acceptance. Actual profile and registry unchanged. VC108R build previously
passed in VMware; this archive is source only. The original source is included
as a patch test fixture (LiveControlWindow.base.cs); do not add it to project.
