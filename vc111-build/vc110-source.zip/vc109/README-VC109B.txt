VC109B — reversible switch of canonical J2534 Lab Adapter (32-bit HKLM view).
This utility does NOT execute any registry change merely by being extracted.
It does not replace the original DLL or INI, create an additional provider, or launch VIDA.

1. Extract the INNER compiled VC108R ZIP and run app\VirtualCar.WinUI.exe --live-control.
Create a session with all diagnostic clients closed. Copy the complete candidate INI section.
Use prepare_profile.py as described in README.txt to create C:\VC109-provider (if not already staged for this session).
Keep the Live Control session running. Run the following in a PowerShell opened as administrator, from this utility directory.

2. Read-only preflight (no writes):
py -3 .\switch_provider.py plan --source C:\VC099-VIDA-511\provider --candidate C:\VC109-provider --build E:\VirtualCar\Builds\VC108R-45858063194-1\VirtualCar-VC108R-development.zip --journal C:\VC109-switch.json

3. Explicit activation only if you intend to change the machine-wide 32-bit J2534 registration. Close VIDA, SectorV, VDASH and any other DLL users; do not run concurrent driver installers. Keep the publisher alive.
py -3 .\switch_provider.py apply --source C:\VC099-VIDA-511\provider --candidate C:\VC109-provider --build E:\VirtualCar\Builds\VC108R-45858063194-1\VirtualCar-VC108R-development.zip --journal C:\VC109-switch.json --clients-closed

4. Restore the previous provider before ending the live session, with all readers closed:
py -3 .\switch_provider.py rollback --journal C:\VC109-switch.json --clients-closed

Do not reuse the journal or candidate directory for a new session. Keep the journal private and intact. If apply fails after the journal is created, inspect the current FunctionLibrary first; rollback refuses if current path differs from the recorded candidate. If the original files were changed, rollback refuses rather than restoring an unverified profile. There is no automatic process scan, concurrent external-installer lock or transaction spanning registry and filesystem. The --clients-closed option is the operator's attestation, not automatic detection. A journal is local trusted evidence, not cryptographic authorization; administrators and same-user processes are outside the threat model. The registry must have the exact canonical metadata matching DriverRegistration.cs at PR #511; unrelated registry keys are not touched. Duplicate external providers with other names are not removed. Only FunctionLibrary is changed; rollback does not alter any other metadata.

Tests: python check_switch.py (13 simulated registry checks), python check_profile.py (17 profile checks). Actual Windows registry, elevation, session authentication and runtime were NOT tested in this environment. No modification of a real Windows system was carried out. No new application build needed for this utility; it uses the previously compiled VC108R candidate. Source archive hash is checked against the exact compiled inner ZIP from run 45858063194, not the GitHub outer artifact wrapper.
