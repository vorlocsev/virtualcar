VC108G — standalone local synthetic state transport prototype (not integrated)

Includes VC108F Core/Checks and unchanged VCST v1 decoder. New VCTP v1
outer envelope is exactly 128 bytes, all integer fields little endian:
  0..3 magic VCTP; 4 version=1; 5 reserved=0; 6..7 length=128
  8..23 opaque 16-byte nonzero publisher session ID
  24..31 uint64 tick milliseconds (same Windows GetTickCount64 clock)
  32..95 VCST v1 payload (64 bytes)
  96..127 HMAC-SHA256 of bytes 0..95 (32-byte secret key)

Single publisher uses an absolute path, same-directory temporary file, flush,
rename/replace. Reader rejects wrong length, version, session, authentication,
future/regressing timestamp, age >1000 ms, repeated/decreasing sequence or
invalid VCST. A rejected frame never extends cache lifetime. Reader may reuse
last valid snapshot until its original timestamp expires. Cache initialization
is permitted only at trusted session setup, not on file contents. Sequence is
monotonic across Reset; restart requires fresh session and key. Proposed
publisher cadence 100 ms. Use GetTickCount64 in both Windows processes.

Linux checks (performed):
  python3 native/test_transport.py
  C11 GCC warnings-as-errors and UBSan, OpenSSL test adapter.
  VC108G_NATIVE=PASS 9/9; VC108G_PROCESS=PASS 500/500 + expiry.
  Python published authenticated frames through os.replace, separate C process
  read and validated each; sequential test, not a simultaneous race stress test.

Windows .NET 10 checks (NOT performed, no SDK here): from extracted root:
  dotnet run --project Checks/Checks.csproj --configuration Release -- managed.bin
  Expected VC108F_MANAGED=PASS 8/8 and VC108G_MANAGED=PASS 3/3.
  C# output is compared with independently generated authenticated golden frame.

NOT integrated into J2534 or WinUI. No production key provisioning, process
binding, Windows ACL/reparse checks, or native BCrypt HMAC adapter yet. Test
key/session in native harness and managed checks are public fixtures only.
File.Move atomicity and concurrent sharing on Windows NTFS remain untested;
native reader must use FILE_SHARE_DELETE and bounded reads, never block under
state lock. No network paths. A trusted launcher must provision per-session
random ID/key separately, restrict owner directory and disallow reparse points.
Same-user malicious processes with access to key are outside prototype model.
No automatic fallback to advancing B3A329 when opted-in external state expires;
actual stale-state behavior must be implemented and regression tested in DLL.
No ECU commands, registry edits, production configuration or repository changes.
