VC108Q — isolated Windows runtime gate (not a release)
Requires a successful VC108P build (Windows SDK, .NET 10 SDK, Python, Windows x64).
From the unpacked VC108Q prototype directory:
 powershell.exe -NoProfile -File .\acceptance\build-candidate.ps1 -Checkout C:\VirtualCar-PR511 -Output C:\VC108P-review
If the candidate already exists, do not rebuild. Then:
 powershell.exe -NoProfile -File .\acceptance\run-runtime.ps1 -Candidate C:\VC108P-review -Output C:\VC108Q-runtime
Use a new output directory each attempt. The test copies only the candidate DLL,
checks its hash, writes a minimal synthetic INI, isolates TEMP/TMP, creates a new
current-user DPAPI session, and launches a separate x86 PowerShell process. The
x86 consumer uses the 04.04 ABI, not a physical adapter or installed provider.
The model checkpoints use virtual time (180 s warm state immediately, 2 s pedal
slew); publisher ticks and expiry use actual Windows monotonic time. The x86
consumer requests each next phase only after its current gate succeeds.
Expected gate: VC108Q_X86_RUNTIME=PASS 8/8 followed by
VC108Q_MANAGED_RUNTIME=PASS (x86 consumer completed all phases).
The 8 groups test stationary, ignition II, warm ECM/CEM/VBATT, REM D2 voltage,
full pedal, stale refusal + identity retention, recovery in the same session,
and engine stop + disconnect + close. No automatic B3A329 fallback allowed.
No VIDA, registry registration, external CAN, ECU writes, jobs or publish.
On failure, retain the isolated output (INI references an expired test session,
not usable after cleanup). Do not copy it to a real provider. Capture error and
last lines of its private SectorVVirtualCar.log. The test owner terminates its
own isolated child if it exceeds 90 s, then disposes credentials. No key logged.
Linux executed: reference pipeline 8/8 (Python fixture + portable C), PE/SDK
8/8, WinUI generator 6/6, native anchors 24/24, mocked hooks 9/9, VCTP 9/9,
500/500 process transfers, diagnostics 12/12, accelerator 6/6, worker 12/12,
late publication race 100/100. Windows C#, DPAPI, actual DLL load, actual native
ABI replies, user-facing WinUI and VIDA still NOT TESTED. No EXE/DLL bundled.
