"""Stage exact-head WinUI candidate outside source checkout. No registry/profile/build."""
import argparse
import pathlib
import shutil
import subprocess

BASE = 'b5671a5f0662d9be75e66314fb7968b2cca61a81'
UI = 'emulator/managed/VirtualCar.WinUI'
APP = UI + '/App.xaml.cs'
PROJECT = UI + '/VirtualCar.WinUI.csproj'
BLOBS = {APP: '1bb6e3c47a552f0e59cc1161a5b5b4d9b6b12dff', PROJECT: '383e4a20a6a2830bd900e0e91fbc975ca592d665'}
ANCHOR = '        if (arguments.SequenceEqual(new[] { "--home-preview" }))'
INSERT = '''        if (arguments.SequenceEqual(new[] { "--live-control" }))
        {
            _window = new LiveControlWindow();
            _window.Activate();
            return;
        }
'''

def transform(source):
    if source.count(ANCHOR) != 1 or '--live-control' in source:
        raise ValueError('Missing/ambiguous startup anchor or already patched')
    return source.replace(ANCHOR, INSERT + ANCHOR, 1)

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkout', type=pathlib.Path)
    parser.add_argument('output', type=pathlib.Path)
    args = parser.parse_args(); repo = args.checkout.resolve(); out = args.output.resolve()
    if out.exists() or out == repo or repo in out.parents:
        raise SystemExit('Fresh destination outside checkout required')
    if git(repo, 'rev-parse', 'HEAD').decode().strip() != BASE:
        raise SystemExit('Exact HEAD required')
    for path, digest in BLOBS.items():
        if git(repo, 'rev-parse', f'{BASE}:{path}').decode().strip() != digest:
            raise SystemExit('Source blob mismatch: ' + path)
    source = git(repo, 'show', f'{BASE}:{APP}').decode('utf-8')
    candidate = transform(source)
    subprocess.run(['git', 'clone', '--local', '--no-hardlinks', '--no-checkout', str(repo), str(out)], check=True)
    subprocess.run(['git', '-C', str(out), 'checkout', '--detach', BASE], check=True)
    if git(out, 'rev-parse', 'HEAD').decode().strip() != BASE:
        raise SystemExit('Staged HEAD mismatch')
    root = pathlib.Path(__file__).resolve().parent.parent
    dest = out / UI / 'LiveControl'; dest.mkdir(exist_ok=False)
    for name in ('LivePublisher.cs', 'LiveControlWindow.cs'):
        shutil.copyfile(root/'winui'/name, dest/name)
    for name in ('VehicleState.cs','StateTransport.cs','PrivateSession.cs'):
        shutil.copyfile(root/'Core'/name, dest/name)
    (out/APP).write_bytes(candidate.encode('utf-8'))
    print('VC108O_WINUI_STAGE=PASS (source only, not compiled)')
    print('VC108O_PROJECT=' + str(out/PROJECT))

if __name__ == '__main__': main()
