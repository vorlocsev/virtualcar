using VirtualCar.LivePrototype;

namespace VirtualCar.WinUI;

// Owns the model and publisher; no J2534 or profile edits. All model calls
// acquire the same gate BEFORE sampling the clock, so UI and worker cannot
// pass decreasing times to VehicleController. Disk writes stay outside gate.
internal sealed class LivePublisher
{
    private readonly object gate = new();
    private readonly VehicleController model = new();
    private readonly PrivateSession session;
    private readonly CancellationTokenSource stop = new();
    private readonly Task worker;
    private VehicleSnapshot? published;
    private bool failed, ending;
    private long publishedAt;
    public string DirectoryPath => session.DirectoryPath;
    public string SessionId => session.SessionHex;
    private static long Now() => checked((long)WindowsStateClock.Now());

    private LivePublisher(PrivateSession session)
    {
        this.session = session;
        worker = Task.Run(RunAsync);
    }
    public static LivePublisher Create()
    {
        string parent = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        // VC108N loads the directory via the ANSI INI API and MAX_PATH buffers.
        // Refuse ambiguous paths rather than letting an ACP conversion corrupt them.
        if (parent.Any(c => c < 32 || c > 126) || parent.Length > 160)
            throw new InvalidOperationException("ASCII local application data path required by native prototype.");
        var session = PrivateSession.Create(parent);
        try { return new LivePublisher(session); }
        catch { session.Dispose(); throw; }
    }
    public (VehicleSnapshot? Snapshot, bool Failed) Read()
    { lock (gate) return (Fresh() ? published : null, failed); }
    private bool Fresh() => published.HasValue && Now() - publishedAt <= 1000;
    private void Command(Action<VehicleController,long> action)
    {
        lock (gate)
        {
            if (ending || failed || !Fresh()) throw new InvalidOperationException("Publisher unavailable.");
            action(model, Now());
        }
    }
    public void SetIgnition(Ignition value) => Command((m,t) => m.SetIgnition(value,t));
    public void Start() => Command((m,t) => m.StartEngine(t));
    public void Stop() => Command((m,t) => m.StopEngine(t));
    public void Reset() => Command((m,t) => m.Reset(t));
    public void Pedal(int value) => Command((m,t) => m.SetAccelerator(value,t));
    private async Task RunAsync()
    {
        try
        {
            while (!stop.IsCancellationRequested)
            {
                VehicleSnapshot next; long sampledAt;
                lock (gate) { if (ending) break; sampledAt = Now(); next = model.Snapshot(sampledAt); }
                session.Publish(next);
                lock (gate) { if (!ending) { published = next; publishedAt = sampledAt; } }
                await Task.Delay(100, stop.Token).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException) when (stop.IsCancellationRequested) { }
        catch (Exception) { lock (gate) { failed = true; published = null; } }
    }
    // Owner explicitly confirms all diagnostic readers are closed. Do not
    // dispose session resources while the publisher still owns them.
    public async Task EndAsync()
    {
        lock (gate) { if (ending) throw new InvalidOperationException("Already ending."); ending = true; published = null; }
        stop.Cancel();
        try { await worker.ConfigureAwait(false); await Task.Run(session.Dispose).ConfigureAwait(false); }
        finally { stop.Dispose(); }
    }
}
