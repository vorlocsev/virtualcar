import unittest
from prepare_winui import transform, ANCHOR, INSERT

class StageChecks(unittest.TestCase):
    def test_exact_insert(self):
        before = 'prefix\n' + ANCHOR + '\nsuffix\n'
        self.assertEqual(transform(before), 'prefix\n' + INSERT + ANCHOR + '\nsuffix\n')
    def test_missing(self):
        with self.assertRaises(ValueError): transform('nothing')
    def test_duplicate(self):
        with self.assertRaises(ValueError): transform(ANCHOR + '\n' + ANCHOR)
    def test_repeat(self):
        with self.assertRaises(ValueError): transform(transform(ANCHOR))
    def test_existing_mode(self):
        with self.assertRaises(ValueError): transform('--live-control\n' + ANCHOR)
    def test_legacy_preserved(self):
        source = ANCHOR + '\n--advanced\n--preview-only\n--diagnostics-only\n--registration-only\n'
        self.assertEqual(transform(source).replace(INSERT,''), source)

if __name__ == '__main__':
    unittest.main(verbosity=2)
