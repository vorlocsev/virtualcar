VC108O — opt-in WinUI live-control candidate (source only)
Baseline b5671a5f0662d9be75e66314fb7968b2cca61a81. App.xaml.cs blob 1bb6e3c47a552f0e59cc1161a5b5b4d9b6b12dff and WinUI project blob 383e4a20a6a2830bd900e0e91fbc975ca592d665 checked through GitHub.

From the unpacked prototype on Windows:
  py -3 .\winui\prepare_winui.py C:\VirtualCar-PR511 C:\VC108O-review
  dotnet publish C:\VC108O-review\emulator\managed\VirtualCar.WinUI\VirtualCar.WinUI.csproj -c Release -r win-x64 --self-contained true -o C:\VC108O-app
  & C:\VC108O-app\VirtualCar.WinUI.exe --live-control
Use a new empty publish destination. Keep the original application host filename.
The staging script clones local Git objects into an independent checkout; it does not change the original source or contact GitHub. It stages five new C# source files and adds one explicit startup branch. Existing startup modes stay unchanged. It does NOT stage the native patch; see README-VC108N.txt for separate native staging and build limitations.

Click Create session. The panel displays a candidate INI section (directory and ID, not the key). Do NOT paste this into the active provider. Once an isolated native candidate is compiled and audited, copy the section to that candidate's profile before opening J2534. No automatic registration, profile write, J2534 call or diagnostic write is implemented. No claim of DLL receipt; UI shows last successfully published local state. With ignition II use Start, wait until Running, use pedal, Stop, Reset. The existing model has a 180 s synthetic startup/warm-up, zero road speed and resets temperature on Stop. Position I in the UI is local-only, not a verified CEM response.

Publisher runs in the background, requests and snapshots share a clock sampled under the same short lock. File writes are outside it. UI renders the published state and disables controls on missing/stale/failed publication. Close VIDA and ALL diagnostic readers before checking the confirmation and clicking End session. AppWindow.Closing cancels normal window closure while session exists. End waits for publication to finish before deleting files; synchronous filesystem I/O may stall, so no hard shutdown deadline is claimed. Forced process termination leaves credentials and state files, which become stale; cleanup must be done after all readers exit. Session creation rejects non-ASCII and long local paths conservatively because current native bridge reads ANSI INI into MAX_PATH. No trusted remote-client acknowledgement is implemented. DPAPI/ACL protect against other ordinary users, not arbitrary same-user code.

Actually executed: WinUI source-transform tests 6/6, VC108N synthetic anchor checks 24/24, VC108N mocked OS hooks 9/9. Exact app/project source retrieved and verified by blob IDs. No Windows SDK or .NET SDK in environment; WinUI compile, staged exact-head checkout, ACL/DPAPI, Windows native build and runtime all NOT TESTED. No repo write, CI, registration or active profile changes.
