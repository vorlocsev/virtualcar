using System.Diagnostics;
using VirtualCar.LivePrototype;
if(!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
if(args.Length!=1) throw new ArgumentException("Native test exe required");
using var session=PrivateSession.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
var info=new ProcessStartInfo(Path.GetFullPath(args[0])) { UseShellExecute=false };
info.ArgumentList.Add(session.CredentialPath);info.ArgumentList.Add(session.StatePath);info.ArgumentList.Add(session.SessionHex);
using var p=Process.Start(info) ?? throw new Exception("Native test launch failed");
var watch=Stopwatch.StartNew();ulong seq=0;
try {
    while(!p.HasExited && watch.Elapsed<TimeSpan.FromSeconds(30)) {
        session.Publish(new VehicleSnapshot(++seq,Ignition.On,Engine.Running,VehicleController.Sample(180000)));
        await Task.Delay(100);
    }
    if(!p.HasExited) throw new TimeoutException("Worker check timed out");
    if(p.ExitCode!=0) throw new Exception($"Worker check exit {p.ExitCode}");
} finally { if(!p.HasExited){p.Kill();p.WaitForExit();} }
Console.WriteLine("VC108M_MANAGED_PUBLISHER=PASS");
