using VirtualCar.LivePrototype;
static void Require(bool ok) { if (!ok) throw new Exception("Check failed"); }
static void Reject<T>(Action f) where T:Exception { try { f(); } catch (T) { return; } throw new Exception("Expected rejection"); }
static void Pass(string name) => Console.WriteLine("PASS " + name);
var c = new VehicleController();
Require(c.Snapshot(0).Engine == Engine.Off); Reject<InvalidOperationException>(()=>c.StartEngine(0)); Pass("ignition gate");
c.SetIgnition(Ignition.On,100); c.StartEngine(100); Require(c.Snapshot(2100).Ecm.Rpm==200); Require(c.Snapshot(4100).Ecm.Rpm==1100); Pass("start timeline");
c.StartEngine(4100); Require(c.Snapshot(60100).Ecm.CoolantC==60); Pass("idempotent start");
var s=c.Snapshot(180100); Require(s.Ecm.Rpm==700 && s.Ecm.BatteryMv==14000 && s.Ecm.CoolantC==90 && s.Ecm.MafCentiGps==550); Require(c.Snapshot(long.MaxValue-100).Ecm==s.Ecm); Pass("warm idle clamp");
long t=long.MaxValue-100; c.StopEngine(t); Require(c.Snapshot(t).Ecm.Rpm==0); c.StartEngine(t); Require(c.Snapshot(t+1).Engine==Engine.Cranking); c.SetIgnition(Ignition.Accessory,t+1); Require(c.Snapshot(t+1).Engine==Engine.Off); Pass("stop restart ignition");
var before=c.Snapshot(t+1); c.Reset(t+2); var after=c.Snapshot(t+2); Require(after.Sequence==before.Sequence+1 && after.Ignition==Ignition.Off); Reject<ArgumentOutOfRangeException>(()=>c.Snapshot(t+1)); Pass("reset monotonicity");
var golden = new VehicleSnapshot(1,Ignition.On,Engine.Running,VehicleController.Sample(180000)); byte[] wire=VehicleStateWire.Encode(golden);
Require(Convert.ToHexString(wire)=="5643535401004000010000000000000002020000B0360000BC0200000000000000000000B40000002602000064000000230000005A0000001E0000002D000000"); Pass("wire golden vector");
Reject<ArgumentOutOfRangeException>(()=>VehicleStateWire.Encode(golden with { Ecm=golden.Ecm with { CoolantC=-41 }})); Reject<ArgumentOutOfRangeException>(()=>VehicleStateWire.Encode(golden with { Ignition=Ignition.Off })); Pass("wire invalid values");
if(args.Length==1) File.WriteAllBytes(args[0],wire);
Console.WriteLine("VC108F_MANAGED=PASS 8/8");
byte[] key = new byte[32]; key[0]=1; key[1]=2; key[2]=3;
byte[] session = new byte[16]; session[0]=4; session[1]=5; session[2]=6;
byte[] frame = StateEnvelope.Encode(golden,session,key,1000);
Require(frame.AsSpan().SequenceEqual(File.ReadAllBytes(Path.Combine("native","transport-golden.bin")))); Pass("transport golden vector");
Reject<ArgumentException>(()=>StateEnvelope.Encode(golden,new byte[16],key,1000));
Reject<ArgumentException>(()=>StateEnvelope.Encode(golden,session,new byte[31],1000)); Pass("credentials bounds");
string dir=Path.Combine(Path.GetTempPath(),"vc108g-"+Guid.NewGuid().ToString("N")); Directory.CreateDirectory(dir);
try {
    string path=Path.Combine(dir,"state.bin"); AtomicStateFile.Publish(path,frame);
    Require(File.ReadAllBytes(path).AsSpan().SequenceEqual(frame));
    byte[] second=StateEnvelope.Encode(golden with { Sequence=2 },session,key,1001);
    AtomicStateFile.Publish(path,second);
    Require(File.ReadAllBytes(path).AsSpan().SequenceEqual(second)&&Directory.GetFiles(dir).Length==1);
    Reject<ArgumentException>(()=>AtomicStateFile.Publish(path,new byte[127]));
    Require(File.ReadAllBytes(path).AsSpan().SequenceEqual(second)); Pass("atomic file publication");
} finally { Directory.Delete(dir,true); }
Console.WriteLine("VC108G_MANAGED=PASS 3/3");

// VC108K: use a separate controller to preserve the earlier contract tests.
var a = new VehicleController();
Reject<InvalidOperationException>(() => a.SetAccelerator(100,0));
a.SetIgnition(Ignition.On,0); a.StartEngine(0);
Reject<InvalidOperationException>(() => a.SetAccelerator(100,3999));
Require(a.Snapshot(3999).Ecm.PedalPermille==0); Pass("accelerator engine gate");
var idle=a.Snapshot(180000); Require(idle.Ecm==VehicleController.Sample(180000));
Reject<ArgumentOutOfRangeException>(()=>a.SetAccelerator(-1,180000));
Reject<ArgumentOutOfRangeException>(()=>a.SetAccelerator(1001,180000));
Require(a.Snapshot(180000).Ecm==idle.Ecm); Pass("pedal bounds and unchanged idle");
a.SetAccelerator(500,180000);
var immediate=a.Snapshot(180000); Require(immediate.Ecm.PedalPermille==500 && immediate.Ecm.Rpm==700);
var half=a.Snapshot(180500); Require(half.Ecm.Rpm==1650 && half.Ecm.LoadPermille==347 && half.Ecm.MafCentiGps==2037 && half.Ecm.ManifoldKpa==50); Pass("pedal immediate and engine slew");
a.SetAccelerator(500,180500); var steady=a.Snapshot(181000); Require(steady.Ecm.Rpm==2600 && steady.Ecm.PedalPermille==500); Pass("idempotent pedal command");
a.SetAccelerator(1000,181000); var full=a.Snapshot(182000); Require(full.Ecm.Rpm==4500 && full.Ecm.LoadPermille==850 && full.Ecm.MafCentiGps==6500 && full.Ecm.ManifoldKpa==95 && full.Ecm.SpeedKph==0); Pass("full pedal stationary vehicle");
a.SetAccelerator(0,182000); Require(a.Snapshot(182500).Ecm.Rpm==2600); Require(a.Snapshot(183000).Ecm==idle.Ecm); Pass("release returns to idle");
var b2=new VehicleController(); b2.SetIgnition(Ignition.On,0); b2.StartEngine(0); b2.SetAccelerator(1000,180000); b2.Snapshot(180100); b2.Snapshot(180200); var frequent=b2.Snapshot(181000);
var c2=new VehicleController(); c2.SetIgnition(Ignition.On,0); c2.StartEngine(0); c2.SetAccelerator(1000,180000); Require(c2.Snapshot(181000).Ecm==frequent.Ecm); Pass("poll-frequency independence");
a.SetAccelerator(1000,183000); a.StopEngine(183100); Require(a.Snapshot(183100).Ecm.PedalPermille==0 && a.Snapshot(183100).Ecm.Rpm==0);
a.StartEngine(183100); Require(a.Snapshot(187100).Ecm.PedalPermille==0); a.SetAccelerator(300,187100); a.SetIgnition(Ignition.Accessory,187200); Require(a.Snapshot(187200).Engine==Engine.Off && a.Snapshot(187200).Ecm.PedalPermille==0);
a.Reset(187300); Reject<ArgumentOutOfRangeException>(()=>a.SetAccelerator(0,187299)); Pass("stop ignition reset and stale command");
// Compare managed-produced frame with an independent Python/C vector.
Require(VehicleStateWire.Encode(full with {Sequence=1}).AsSpan().SequenceEqual(File.ReadAllBytes(Path.Combine("native","accelerator-golden.bin")))); Pass("full pedal wire vector");
Console.WriteLine("VC108K_MANAGED=PASS 9/9");
