VC108I — portable integration boundary (NOT a patched J2534 DLL)
Base: VC108H; target repo exact HEAD b5671a5f0662d9be75e66314fb7968b2cca61a81.
New native/live_state_slot.{h,c} keeps externally authenticated snapshots
under the existing DLL state lock, with generation and independent freshness.
All calls require caller serialization; there is no internal thread or mutex.
The portable tests exercise lifecycle and handoff; no Windows SDK installed.

Integration specification (requires exact native source review):
- Preserve legacy mode by default. Explicit external opt-in; no automatic
  fallback to B3A329 if external data is unavailable, including startup.
- At trusted PassThruOpen lifecycle, initialize slot via vc_live_begin;
  allocate worker credentials and a new session before starting worker.
  Never reset generation on a rejected/expired frame. Do not reset slot
  memory between opens; keep generation monotonic for DLL lifetime.
- A worker owns vc_win_reader and calls vc_win_poll outside DLL state lock.
  On NEW only, publish reader.cache.snapshot with reader.cache.accepted_tick
  and captured generation under state lock; use current GetTickCount64()
  inside lock. CACHED cannot renew timestamp. No key or IPC I/O under lock.
- At ecm_lab_refresh() (existing callers in request dispatch and IOCTL),
  select fresh snapshot using current GetTickCount64 under lock. Map all
  eleven fields explicitly into ECM_LAB_STATE. Use one snapshot per request.
  In external mode, ensure ecm_lab_dynamic_tick is not called; route every
  relevant ECM, CEM, REM and battery IOCTL consumer through freshness gate.
  Distinguish unavailable from engine OFF; stale must not be encoded as zero.
  Decide allowed negative response/silence per existing route policy after
  reviewing handlers. Do not suppress identity or DTC requests.
- CEM A45F ignition mapping: existing 04/07 observed for 0/II only, not an
  OEM calibration. Position I must remain unsupported until evidenced;
  do not infer arbitrary raw switch bits. Keep CEM voltage from same snapshot.
- On close, invalidate generation under lock, signal worker, release lock,
  join worker before closing context/unloading DLL. Prevent new open from
  racing teardown. Synchronous I/O may block: design cancellation/ownership
  explicitly before production integration. Never wait in DllMain.
- No secrets in INI, logs, CLI arguments or test artifacts. A trusted launch
  mechanism must provision session/key and private path. This is unresolved.
- No raw CAN/ECU write commands; local simulation state only. Preserve VCRD.
- Custom no-CRT link/import compatibility and x86/x64 ABI must be verified;
  portable struct layout is NOT the wire layout and not shared across processes.

Tests run in Linux:
 cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined native/live_state_slot.c native/check_live_slot.c -o /tmp/vc108i-check
 /tmp/vc108i-check  # PASS 10/10
 python3 native/test_transport.py  # PASS 9/9 and 500/500
 python3 native/test_live_pipeline.py  # same 9/9 + slot pipeline 500/500 and expiry
Pipeline is Python publisher -> atomic file -> C/OpenSSL authenticated transport
-> slot -> diagnostic-side test consumer; not actual DLL/VIDA.
Windows tests, NOT run here: use VS Developer PowerShell (x86, then x64):
 powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows\check-windows.ps1
 powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows\check-live-slot.ps1
Expected H_WINDOWS=PASS 9/9 and I_LIVE_SLOT=PASS 10/10 (full VC108 prefixes).
These do not validate actual J2534 integration. No .NET SDK installed here.
Source fetch failed, so no claim of source patch, compile/link, or live VIDA.
