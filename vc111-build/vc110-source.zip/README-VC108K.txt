VC108K — stationary synthetic accelerator model, cumulative E–K prototype.
Target PR511 b5671a5f0662d9be75e66314fb7968b2cca61a81. No repository changes.

New VehicleController.SetAccelerator(int permille, long now) accepts 0..1000
only with ignition II and engine Running (>=4 s from StartEngine). Pedal is
reported immediately; an internal response ramps at 500 permille/s up and
1000 permille/s down. Repeated identical commands do not restart ramps.
Snapshots use elapsed monotonic time, not polling frequency. Stop, ignition
0/I, and Reset clear pedal and response. StartEngine begins at zero pedal.

Response interpolates from the current B3A329 baseline toward 4500 rpm,
850 permille load, 6500 centi-g/s MAF and 95 kPa MAP. Zero response retains
baseline exactly. Vehicle speed stays zero. Battery and thermal model remain
unchanged. Stop still resets temperatures in this prototype. These are
chosen synthetic targets/rates, NOT OEM calibration or engine physics.
No VCST or VCTP wire changes. No CAN commands or ECU writes added.

Linux checks actually run (GCC C11 -Wall -Wextra -Werror -pedantic + UBSan):
 cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined native/vehicle_state_wire.c native/live_state_slot.c native/diagnostic_state.c native/check_accelerator.c -o /tmp/vc108k-check
 /tmp/vc108k-check native/accelerator-golden.bin  # 6/6 PASS
 python3 native/test_live_pipeline.py  # 9/9, 500/500 + expiry PASS
 cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined native/live_state_slot.c native/diagnostic_state.c native/check_diagnostic_state.c -o /tmp/vc108k-diag
 /tmp/vc108k-diag  # 12/12 PASS
 cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined native/live_state_slot.c native/check_live_slot.c -o /tmp/vc108k-slot
 /tmp/vc108k-slot  # 10/10 PASS

Native accelerator check uses an independent Python-generated binary vector,
not an output of the managed controller. Nine new C# checks are supplied,
NOT compiled or run (no .NET SDK). They cover gating, bounds, slew, idempotency,
full pedal, release, polling independence, reset and wire equality.
From archive root: dotnet run --project Checks/Checks.csproj --configuration Release
Expected VC108K_MANAGED=PASS 9/9 following prior F/G checks.
Windows Developer PowerShell: powershell.exe -NoProfile -File .\windows\check-accelerator.ps1
Windows, C# -> native live transport, WinUI and VIDA still NOT TESTED.
