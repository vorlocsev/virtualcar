using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using VirtualCar.LivePrototype;

// Standalone test owner. Never install a provider or use the operational INI.
if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
if (args.Length != 3) throw new ArgumentException("DLL, fresh run directory, x86 runner script required");
string dll = Path.GetFullPath(args[0]), run = Path.GetFullPath(args[1]), script = Path.GetFullPath(args[2]);
if (Path.GetFileName(dll) != "VirtualCarJ2534.dll" || !File.Exists(dll) || !File.Exists(script)) throw new ArgumentException("Candidate DLL and runner required");
if (Directory.Exists(run) || File.Exists(run)) throw new IOException("Fresh run directory required");
Directory.CreateDirectory(run);
File.Copy(dll, Path.Combine(run,"VirtualCarJ2534.dll"), false);
string digest = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(dll)));
if (digest != Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(run,"VirtualCarJ2534.dll"))))) throw new IOException("Candidate copy hash mismatch");
Console.WriteLine("VC108Q_DLL_SHA256=" + digest);
using var session = PrivateSession.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
if (session.DirectoryPath.Length > 220 || session.DirectoryPath.Any(c => c < 32 || c > 126)) throw new InvalidOperationException("ASCII bounded session path required");
string ini = "[Vehicle]\r\nECUCount=2\r\nBatteryMv=12500\r\nEmitIsoRxStart=0\r\n[ECU0]\r\nRequestId=18DA10F1\r\nResponseId=18DAF110\r\nExpectedBaud=500000\r\nPartNumber=LAB-ECM\r\n[ECU1]\r\nRequestId=18DA50F1\r\nResponseId=18DAF150\r\nExpectedBaud=500000\r\n[Diagnostics]\r\nEnableGGDCemLab=1\r\nStrictJ2534Filters=0\r\n";
foreach (string section in new[] {"B3A309_EcmLiveDataLab", "B3A314_EcmExtendedLiveLab", "B3A267_CurrentDataLab", "B3A319_BatterySyncLab", "B3A320_RemVoltageSyncLab", "B3A324_SupplyVoltageSyncLab", "B3A329_DynamicEcmLab"}) ini += $"[{section}]\r\nEnabled=1\r\n";
ini += $"[VC108N_ExternalStateLab]\r\nEnabled=1\r\nSessionDirectory={session.DirectoryPath}\r\nSessionId={session.SessionHex}\r\n";
File.WriteAllText(Path.Combine(run,"virtualcar.ini"),ini,Encoding.ASCII);
var model = new VehicleController();
int phase = 0; long t = 0;
// Deliberate virtual clock: exact checkpoints, real Windows tick for transport freshness.
session.Publish(model.Snapshot(t));
var info = new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "SysWOW64", "WindowsPowerShell", "v1.0", "powershell.exe")) {UseShellExecute=false};
foreach (string arg in new[] {"-NoProfile","-ExecutionPolicy","Bypass","-File",script,"-Directory",run}) info.ArgumentList.Add(arg);
info.Environment["TEMP"] = run; info.Environment["TMP"] = run;
using var child = Process.Start(info) ?? throw new InvalidOperationException("x86 runner failed to start");
var watch = Stopwatch.StartNew();
try {
    while (!child.HasExited && watch.Elapsed < TimeSpan.FromSeconds(90)) {
        if (phase < 6 && File.Exists(Path.Combine(run,$"phase-{phase+1}"))) {
            phase++;
            switch (phase) {
                case 1: t=1; model.SetIgnition(Ignition.On,t); break;
                case 2: t=1000; model.StartEngine(t); t=181000; break;
                case 3: model.SetAccelerator(1000,t); t+=2000; break;
                case 4: break; // intentionally stop publication; cache must expire
                case 5: break; // resume same state with new sequence/tick
                case 6: t++; model.StopEngine(t); break;
            }
        }
        if (phase != 4) session.Publish(model.Snapshot(t));
        await Task.Delay(100);
    }
    if (!child.HasExited) throw new TimeoutException("Runtime check timeout");
    if (child.ExitCode != 0 || phase != 6) throw new InvalidOperationException($"Runtime check failed: exit={child.ExitCode}, phase={phase}");
    Console.WriteLine("VC108Q_MANAGED_RUNTIME=PASS (x86 consumer completed all phases)");
} finally { if (!child.HasExited) { child.Kill(); child.WaitForExit(); } }
