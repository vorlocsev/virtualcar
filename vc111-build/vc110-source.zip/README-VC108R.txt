VC108R — Windows acceptance orchestration, not a release.
Run from the extracted VC108R directory in x86-target Visual Studio Developer
PowerShell, with 64-bit Python 3, Git, clang-cl, link, Windows SDK, .NET 10 SDK.
Fresh candidate:
 py -3 .\acceptance\run-windows-gates.py --checkout C:\VirtualCar-PR511 --candidate C:\VC108R-review --evidence C:\VC108R-evidence
Already built candidate (explicit reuse, no historical build attestation):
 py -3 .\acceptance\run-windows-gates.py --checkout C:\VirtualCar-PR511 --candidate C:\VC108P-review --evidence C:\VC108R-evidence --reuse
Use a new evidence directory each run. Fresh build requires a new candidate path.
Do not reuse a candidate after a failed partial build unless it is independently
known to be complete. Reuse verifies PE/exports/imports and binary identity,
not the provenance of the existing build. The runtime child copies the DLL and
uses only a synthetic temporary profile. No VIDA or registry modifications.
The report includes the exact checkout SHA, DLL/apphost SHA256, PE architecture,
build/runtime markers and process exit codes. A PASS requires all relevant
markers exactly once, exit zero and matching hashes. Missing markers mean
NOT_TESTED/unconfirmed, not successful. On failure retain result.json, build.log
(if built), runtime.log (if started) and the isolated runtime directory.
Expected: VC108R=PASS_BUILD_AND_RUNTIME (or PASS_RUNTIME_EXISTING_BUILD_NOT_ATTESTED).
WinUI interactive launch and original VIDA remain NOT_TESTED in either case.
Linux executed: report parser/PE/path policy 9/9; reference pipeline 8/8;
PE/SDK auditor 8/8; WinUI generator 6/6; native anchors 24/24; mocked hooks 9/9.
Windows orchestration itself not run: no Windows/PowerShell/.NET SDK here.
