VC108N — exact-head J2534 integration candidate (review, not a released DLL)

Baseline commit b5671a5f0662d9be75e66314fb7968b2cca61a81; virtualcar.c blob 80cee49fc7712d86e3b3d9d1840f8d1598f0f125.
All eleven exact edit anchors were checked against this blob through GitHub.

From the unpacked prototype directory (Windows, PowerShell 5.1):
  py -3 .\integration\prepare.py C:\VirtualCar-PR511 C:\VC108N-review
This requires a fresh destination outside the checkout. It checks HEAD and blob, refuses changes to virtualcar.c, writes a unified patch, runs git apply --check (no write), and stages the committed emulator/src tree plus selected VC108 sources. It never writes to the original checkout, DLL, INI or registry.
The real exact-head preparation still needs to be run on the Windows checkout.

Build integration (NOT tested, NOT yet automated):
- Ordinary builds without VC108N_EXTERNAL_STATE keep existing code paths and do not link the new sources.
- Experimental build: define VC108N_EXTERNAL_STATE on virtualcar.c; compile bridge and transport/worker in separate translation units (Windows SDK headers not included in virtualcar.c). Define VC108N_DLL_WORKER consistently on all new Windows units. Link SDK imports for kernel32, bcrypt, crypt32, preserve the original 14 J2534 exports and no-CRT ABI. Existing p2core freestanding_memory supplies memcpy/memset. New sources avoid memcmp/wcslen and the 4 KiB stack blob. Actual x86 link, import/export audit, no-CRT audit, and Windows runtime remain required. Do not mix with production build.
- No new J2534 exports. No diagnostic write commands. DllMain unchanged. Worker retains its module reference until FreeLibraryAndExitThread. If a client omits PassThruClose, the module may remain resident until process exit; it is not force-unloaded.
- Stop times out after 5 s; close can be retried. Open is rejected while join is pending. File I/O is outside the state lock; short worker select lock only. Start launches thread, does not claim that authentication has completed.
- Explicit lab INI opt-in ONLY on future isolated candidate, not the current provider:
  [VC108N_ExternalStateLab]
  Enabled=1
  SessionDirectory=... absolute trusted directory created by PrivateSession ...
  SessionId=... exact 32 uppercase hex chars ...
No secret in INI. All prior B3A329 prerequisites except B3A329 itself required. A trusted launcher must validate the local NTFS directory/ancestors and publish the exact session ID; provisioning UI not done. Disabled/missing key retains legacy; malformed or missing prerequisites fails Open. Invalid credential data causes external state unavailable, not legacy fallback.
- Fresh data is checked at response generation, not at delivery of already queued frames. CEM A45F supports only existing lab positions 0 and II. Position I returns no response. CEM DD02 and three exact D2 voltage requests reuse original conversion helpers. Other static D2 values remain as before; no new calibration or unsupported route is invented. READ_VBATT returns ERR_DEVICE_NOT_CONNECTED without writing output when external state is unavailable. F1xx identity and DTC remain on existing paths.

Tests actually executed on Linux: 11/11 source anchors checked remotely; anchor-transform fixture 24/24; policy 7/7; selected generated Open/Close/refresh hooks with mocked OS 9/9; diagnostic vectors 12/12; accelerator 6/6; credential wire 8/8; transport 9/9; two process pipelines 500/500 each; lifecycle 12/12; concurrent late publication 100/100. Windows build, real exact-head git apply --check, WinUI and VIDA runtime NOT TESTED. Neither repository nor active provider changed.
