VC108H — Windows VCTP receiver prototype, not integrated with J2534

Retains VC108F/G managed model, 64-byte VCST and 128-byte VCTP wire.
New Windows source: windows/state_windows.{h,c}. Uses BCrypt HMAC-SHA256,
GetTickCount64, bounded synchronous CreateFileW/ReadFile, and FILE_SHARE_DELETE
for same-directory atomic replacement. Denies in-place writes while reading.
Checks regular disk file, final reparse flag, exact size and EOF. Rejects
relative/UNC/device/ADS paths, dot/trailing-space components and nonfixed drives.
These checks are defense in depth, not a full security boundary: the trusted
launcher MUST provision a private local NTFS directory and exclude all ancestor
reparse points, hard-link attacks and untrusted writers, and supply a fresh
random 16-byte session and 32-byte secret via a separate protected channel.
Never put the key in the state file, logs or a published profile. Public test
credentials in the test harness are NOT deployable.

Reader lifecycle: zero-initialize vc_win_reader; initialize with trusted session
and key; one worker owns it; poll the trusted path; close/zero at teardown.
Results: NEW=authenticated newer snapshot; CACHED=last valid snapshot remains
fresh; STALE=no valid snapshot or age >1000 ms, output unchanged. An invalid
file cannot renew the timestamp. Receiver does NOT autonomously reset session
identity, sequence or epoch on expiry. No fallback to automatic B3A329 is
implemented here. When integrated, external mode must suppress the affected
simulated live-data replies after expiry, preserve unrelated identification
and DTC paths, and expose clear status; do not fabricate an engine stop or
silently return to an advancing legacy scenario. The final policy remains to
be implemented/tested. Do not use synchronous file/crypto calls under the DLL
state lock. Future worker must publish a coherent snapshot with original
accepted_tick; every diagnostic read must check age independently even if the
worker hangs. For a worker running inside the DLL, shutdown must be bounded
and safe against module unload. No worker/lifetime integration exists yet.

Windows test (NOT executed here): Windows 10/11, MSVC C11 + SDK; start an x86
Developer PowerShell (repeat separately for x64), then from extracted root:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows\check-windows.ps1
Expected VC108H_WINDOWS=PASS 9/9. Builds in unique TEMP dir, tests real BCrypt
against Python-generated golden HMAC, file publication, replay, tamper, size,
expiry, recovery and reader close. Deletes test files; no registry or VIDA
changes. Timing test expects local machine not stalled for >1s during fresh
checks. Not a Windows concurrency/ACL stress test. Test uses a normal local
TEMP path; if TEMP is UNC/reparse or nonfixed, use suitable local environment.
The MSVC build includes normal CRT and bcrypt.lib; this is NOT the actual
custom import/no-CRT J2534 DLL build and its ABI/import compatibility is untested.

Executed Linux regression on unchanged portable wire/transport:
  python3 native/test_transport.py
  VC108G_NATIVE=PASS 9/9; VC108G_PROCESS=PASS 500/500 + expiry.
Uses GCC, OpenSSL and UBSan, Python publisher. These are NOT tests of BCrypt or
Windows file sharing. .NET SDK, MSVC, Windows SDK and Wine are unavailable in
this environment; managed and native Windows builds are untested. No repo,
DLL, WinUI, VIDA, registry, configuration, CI or releases modified.

Next VC108I: validate Windows receiver x86 and x64, then design worker and
lock-safe snapshot integration with existing J2534 refresh points; keep default
legacy mode intact and external state explicitly opt-in. Validate stale and
reconnect behavior, CEM ignition mapping (0/I/II not all OEM-verified), ECM and
CEM voltage synchronization, and preserve baseline VC107 VIDA functionality.
