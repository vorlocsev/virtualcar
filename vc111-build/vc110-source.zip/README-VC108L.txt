VC108L — private session bootstrap prototype (cumulative E–L).
Target PR511 b5671a5f0662d9be75e66314fb7968b2cca61a81; no repo/DLL changes.

PrivateSession.Create requires a trusted existing private local NTFS parent,
checks all existing ancestors for reparse points, creates a random directory
with protected owner-only DACL, verifies ACL, generates fresh 16-byte ID and
32-byte key using the OS RNG. VCK1 plaintext (56 bytes, versioned header,
ID, key) is encrypted with current-user DPAPI; only credentials.dpapi is
written to disk. Publish uses the existing atomic VCTP and monotonic sequence.
Dispose zeroes managed key, removes known files and directory (nonrecursive).
Caller must stop/join readers before Dispose. On abnormal process exit old
files may remain; VCTP expires within 1 second. A new session never reuses
an old directory/key. A trusted launcher must select and pass exact path and
expected ID to the receiver, not discover arbitrary credentials by scanning.
The ID/path are not secrets. Do not pass keys in arguments, INI or logs.

Native vc_win_init_protected validates file shape, size <=4096, disk and final
reparse point, decrypts DPAPI, checks exact VCK1/session/key, initializes
BCrypt reader and zeroes temporary plaintext/key. Caller owns all ancestor
and ACL checks and must pass a zero-initialized inactive reader. Neither
DPAPI nor owner DACL protects against arbitrary code running as the same
Windows user, admin, or SYSTEM. No isolation between hostile same-user
processes is claimed. Parent trust and check/use races are not solved by
attribute checks; a trusted launcher must guarantee parent ownership and
non-replacement. Cross-user/service identity not supported in this design.
No automatic reader bootstrap or restart handoff is installed yet. No raw
CAN, ECU writes, diagnostic programming, or changes to VCRD. VCST/VCTP unchanged.

Actually run in Linux (GCC C11 -Werror + UBSan):
 cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined native/session_credentials.c native/check_credentials.c -o /tmp/vc108l-check
 /tmp/vc108l-check  # PASS 8/8
 python3 native/test_live_pipeline.py  # PASS 9/9 and 500/500 + expiry
 Accelerator 6/6, diagnostic adapter 12/12, state slot 10/10 also rerun.

Windows/.NET NOT RUN: from archive root, x86 and x64 Visual Studio Developer
PowerShell with .NET 10 SDK:
 powershell.exe -NoProfile -File .\windows\check-session.ps1
Expected VC108L_WINDOWS_RECEIVER=PASS 4/4 and VC108L_MANAGED=PASS 5/5.
This tests current-user encryption/decryption, session binding, active reader
protection, corrupted blob rejection, publisher monotonicity and cleanup.
It does not prove cross-user denial, crash recovery, races or real DLL runtime.
The launcher and worker lifecycle must still be implemented; custom no-CRT
link/import requirements and real Windows x86/x64 builds remain unverified.
