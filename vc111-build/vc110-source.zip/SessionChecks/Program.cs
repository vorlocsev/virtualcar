using System.Diagnostics;
using VirtualCar.LivePrototype;

if(!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
if(args.Length!=1) throw new ArgumentException("Native test exe required");
static void Require(bool v) { if(!v)throw new Exception("Check failed"); }
static void Reject<T>(Action f) where T:Exception { try{f();}catch(T){return;}throw new Exception("Expected rejection"); }
// LocalAppData is assumed to be the trusted current-user parent for this test.
string parent=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
using var first=PrivateSession.Create(parent);
using var second=PrivateSession.Create(parent);
Require(first.SessionHex!=second.SessionHex && first.DirectoryPath!=second.DirectoryPath);
Console.WriteLine("PASS independent sessions");
byte[] encrypted=File.ReadAllBytes(first.CredentialPath);
Require(encrypted.Length is >56 and <=4096 && !encrypted.AsSpan().StartsWith("VCK1"u8));
Console.WriteLine("PASS encrypted credential storage");
var state=new VehicleSnapshot(1,Ignition.On,Engine.Running,VehicleController.Sample(180000));
first.Publish(state);byte[] before=File.ReadAllBytes(first.StatePath);
Reject<InvalidOperationException>(()=>first.Publish(state));
Require(before.AsSpan().SequenceEqual(File.ReadAllBytes(first.StatePath)));
first.Publish(state with {Sequence=2});Require(!before.AsSpan().SequenceEqual(File.ReadAllBytes(first.StatePath)));
Console.WriteLine("PASS monotonic publisher");
string bad=Path.Combine(first.DirectoryPath,"corrupt.dpapi");
// Deliberate corruption in this private test directory, not actual credentials.
File.WriteAllBytes(bad,[0,1,2,3]);
try {
    var info=new ProcessStartInfo(Path.GetFullPath(args[0])) { UseShellExecute=false };
    info.ArgumentList.Add(first.CredentialPath);info.ArgumentList.Add(first.SessionHex);info.ArgumentList.Add(bad);
    using var p=Process.Start(info) ?? throw new Exception("Native test launch failed");
    if(!p.WaitForExit(30000)){p.Kill();p.WaitForExit();throw new TimeoutException();}
    Require(p.ExitCode==0);
}finally {File.Delete(bad);}
Console.WriteLine("PASS native DPAPI interoperability");
string dir=first.DirectoryPath;first.Dispose();Require(!Directory.Exists(dir));
Reject<ObjectDisposedException>(()=>first.Publish(state with {Sequence=3}));
Console.WriteLine("PASS cleanup and disposed publisher");
Console.WriteLine("VC108L_MANAGED=PASS 5/5");
