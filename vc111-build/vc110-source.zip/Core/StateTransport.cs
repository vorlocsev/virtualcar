using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Runtime.InteropServices;

namespace VirtualCar.LivePrototype;

// Local simulation-only envelope. A trusted launcher must provide fresh session and key.
public static class StateEnvelope
{
    public const int Size = 128;
    public const ulong MaxAgeMs = 1000;
    public static byte[] Encode(VehicleSnapshot state, ReadOnlySpan<byte> session,
        ReadOnlySpan<byte> key, ulong tick)
    {
        if (session.Length != 16 || key.Length != 32 || session.IndexOfAnyExcept((byte)0) < 0)
            throw new ArgumentException("Invalid publisher credentials");
        byte[] frame = new byte[Size];
        "VCTP"u8.CopyTo(frame); frame[4] = 1; frame[6] = Size;
        session.CopyTo(frame.AsSpan(8,16));
        BinaryPrimitives.WriteUInt64LittleEndian(frame.AsSpan(24,8), tick);
        VehicleStateWire.Encode(state).CopyTo(frame,32);
        HMACSHA256.HashData(key, frame.AsSpan(0,96), frame.AsSpan(96,32));
        return frame;
    }
}

public static class AtomicStateFile
{
    // One writer, owner-controlled directory on local NTFS. No network paths in deployment.
    // The launcher is responsible for ACLs, reparse-point exclusion and key provisioning.
    public static void Publish(string path, ReadOnlySpan<byte> frame)
    {
        if (!Path.IsPathFullyQualified(path) || frame.Length != StateEnvelope.Size)
            throw new ArgumentException("Absolute path and exact frame required");
        string full = Path.GetFullPath(path);
        string temp = Path.Combine(Path.GetDirectoryName(full)!, ".vcst-" + Guid.NewGuid().ToString("N") + ".tmp");
        bool created = false;
        try
        {
            using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                created = true;
                stream.Write(frame); stream.Flush(flushToDisk: true);
            }
            File.Move(temp, full, overwrite: true);
        }
        finally { if (created && File.Exists(temp)) File.Delete(temp); }
    }
}

public static class WindowsStateClock
{
    [DllImport("kernel32.dll", ExactSpelling = true)]
    private static extern ulong GetTickCount64();
    public static ulong Now()
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
        return GetTickCount64();
    }
}
