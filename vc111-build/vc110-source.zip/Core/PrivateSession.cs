using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Runtime.Versioning;

namespace VirtualCar.LivePrototype;

// One trusted publisher per session. Current-user DPAPI + a protected DACL;
// not a security boundary against arbitrary code running as the same user.
[SupportedOSPlatform("windows")]
public sealed class PrivateSession : IDisposable
{
    private readonly object gate = new();
    private readonly byte[] key, session;
    private bool disposed;
    private ulong lastSequence, lastTick;
    public string DirectoryPath { get; }
    public string CredentialPath => Path.Combine(DirectoryPath, "credentials.dpapi");
    public string StatePath => Path.Combine(DirectoryPath, "state.bin");
    public string SessionHex => Convert.ToHexString(session);
    private PrivateSession(string path, byte[] id, byte[] secret)
    { DirectoryPath = path; session = id; key = secret; }

    // parent is a trusted existing private directory, not supplied by an IPC peer.
    public static PrivateSession Create(string parent)
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
        if (!Path.IsPathFullyQualified(parent)) throw new ArgumentException("Absolute parent required");
        string full = Path.GetFullPath(parent);
        string root = Path.GetPathRoot(full)!;
        if (root.Length != 3 || root[1] != ':' || new DriveInfo(root).DriveType != DriveType.Fixed ||
            !new DriveInfo(root).DriveFormat.Equals("NTFS", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Local NTFS required");
        for (DirectoryInfo? d = new(full); d is not null; d = d.Parent)
            if (!d.Exists || (d.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new InvalidOperationException("Existing non-reparse ancestors required");
        using WindowsIdentity identity = WindowsIdentity.GetCurrent();
        SecurityIdentifier sid = identity.User ?? throw new InvalidOperationException("Missing user SID");
        byte[] id = RandomNumberGenerator.GetBytes(16), secret = RandomNumberGenerator.GetBytes(32);
        byte[] clear = new byte[56];
        string path = Path.Combine(full,"vc108-"+Convert.ToHexString(id));
        bool created = false;
        try
        {
            if (id.AsSpan().IndexOfAnyExcept((byte)0) < 0 || secret.AsSpan().IndexOfAnyExcept((byte)0) < 0)
                throw new CryptographicException("Invalid random credentials");
            if (Directory.Exists(path) || File.Exists(path)) throw new IOException("Session collision");
            var acl = new DirectorySecurity();
            acl.SetOwner(sid); acl.SetAccessRuleProtection(true,false);
            acl.AddAccessRule(new FileSystemAccessRule(sid,FileSystemRights.FullControl,
                InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
            var dir = new DirectoryInfo(path); dir.Create(acl); created = true;
            if ((dir.Attributes & FileAttributes.ReparsePoint) != 0) throw new IOException("Unexpected reparse point");
            var actual = dir.GetAccessControl();
            if (!actual.AreAccessRulesProtected || !sid.Equals(actual.GetOwner(typeof(SecurityIdentifier))))
                throw new IOException("Session ACL verification failed");
            var rules = actual.GetAccessRules(true,true,typeof(SecurityIdentifier));
            if (rules.Count != 1 || rules[0] is not FileSystemAccessRule rule || !sid.Equals(rule.IdentityReference) ||
                rule.AccessControlType != AccessControlType.Allow || (rule.FileSystemRights & FileSystemRights.FullControl) != FileSystemRights.FullControl)
                throw new IOException("Unexpected session access rules");
            "VCK1"u8.CopyTo(clear); clear[4]=1; clear[6]=56;
            id.CopyTo(clear,8); secret.CopyTo(clear,24);
            byte[] encrypted = Protect(clear);
            using (var stream = new FileStream(Path.Combine(path,"credentials.dpapi"),FileMode.CreateNew,FileAccess.Write,FileShare.None))
            { stream.Write(encrypted); stream.Flush(true); }
            return new PrivateSession(path,id,secret);
        }
        catch
        {
            CryptographicOperations.ZeroMemory(secret);
            // No recursive deletion, even on failure. Only our known credential file.
            if (created) { try { File.Delete(Path.Combine(path,"credentials.dpapi")); Directory.Delete(path); } catch (IOException) { } catch (UnauthorizedAccessException) { } }
            throw;
        }
        finally { CryptographicOperations.ZeroMemory(clear); }
    }
    public void Publish(VehicleSnapshot state)
    {
        lock(gate)
        {
            ObjectDisposedException.ThrowIf(disposed,this);
            ulong tick=WindowsStateClock.Now();
            if(state.Sequence<=lastSequence || tick<lastTick) throw new InvalidOperationException("Nonmonotonic publication");
            AtomicStateFile.Publish(StatePath,StateEnvelope.Encode(state,session,key,tick));
            lastSequence=state.Sequence;lastTick=tick;
        }
    }
    // Owner must stop/join readers before disposal. No automatic reconnect to old credentials.
    public void Dispose()
    {
        lock(gate)
        {
            if(disposed)return;
            disposed=true;CryptographicOperations.ZeroMemory(key);
            File.Delete(StatePath);File.Delete(CredentialPath);Directory.Delete(DirectoryPath);
        }
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct Blob { public int Length; public IntPtr Data; }
    [DllImport("crypt32.dll",CharSet=CharSet.Unicode,SetLastError=true,ExactSpelling=true)]
    [return:MarshalAs(UnmanagedType.Bool)]
    private static extern bool CryptProtectData(ref Blob input,string? description,IntPtr entropy,IntPtr reserved,IntPtr prompt,uint flags,out Blob output);
    [DllImport("kernel32.dll",ExactSpelling=true)] private static extern IntPtr LocalFree(IntPtr p);
    private static byte[] Protect(byte[] clear)
    {
        Blob input = new() {Length=clear.Length,Data=Marshal.AllocHGlobal(clear.Length)}; Blob output=default;
        try
        {
            Marshal.Copy(clear,0,input.Data,clear.Length);
            if(!CryptProtectData(ref input,null,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,1,out output))
                throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            if(output.Length is <1 or >4096 || output.Data==IntPtr.Zero) throw new CryptographicException("Unexpected DPAPI blob");
            byte[] encrypted=new byte[output.Length];Marshal.Copy(output.Data,encrypted,0,encrypted.Length);return encrypted;
        }
        finally
        {
            for(int i=0;i<clear.Length;i++)Marshal.WriteByte(input.Data,i,0);
            Marshal.FreeHGlobal(input.Data);
            if(output.Data!=IntPtr.Zero) _=LocalFree(output.Data);
        }
    }
}
