using System.Buffers.Binary;

namespace VirtualCar.LivePrototype;

public enum Ignition : byte { Off, Accessory, On }
public enum Engine : byte { Off, Cranking, Running }
public readonly record struct EcmValues(int BatteryMv, int Rpm, int SpeedKph, int PedalPermille,
    int LoadPermille, int MafCentiGps, int AmbientKpa, int ManifoldKpa, int CoolantC, int IntakeC, int EcmC);
public readonly record struct VehicleSnapshot(ulong Sequence, Ignition Ignition, Engine Engine, EcmValues Ecm);

public static class VehicleStateWire
{
    public const int Size = 64;
    public static byte[] Encode(VehicleSnapshot s)
    {
        EcmValues e = s.Ecm;
        if (s.Sequence == 0 || !Enum.IsDefined(s.Ignition) || !Enum.IsDefined(s.Engine) ||
            (s.Ignition != Ignition.On && s.Engine != Engine.Off) || (s.Engine == Engine.Off && e.Rpm != 0) ||
            e.BatteryMv is < 0 or > 20000 || e.Rpm is < 0 or > 16383 || e.SpeedKph is < 0 or > 255 ||
            e.PedalPermille is < 0 or > 1000 || e.LoadPermille is < 0 or > 1000 ||
            e.MafCentiGps is < 0 or > 65535 || e.AmbientKpa is < 0 or > 127 || e.ManifoldKpa is < 0 or > 255 ||
            e.CoolantC is < -40 or > 119 || e.IntakeC is < -40 or > 119 || e.EcmC is < -40 or > 119)
            throw new ArgumentOutOfRangeException(nameof(s));
        byte[] wire = new byte[Size];
        "VCST"u8.CopyTo(wire); wire[4] = 1; wire[6] = Size;
        BinaryPrimitives.WriteUInt64LittleEndian(wire.AsSpan(8), s.Sequence);
        wire[16] = (byte)s.Ignition; wire[17] = (byte)s.Engine;
        int[] fields = [e.BatteryMv, e.Rpm, e.SpeedKph, e.PedalPermille, e.LoadPermille,
            e.MafCentiGps, e.AmbientKpa, e.ManifoldKpa, e.CoolantC, e.IntakeC, e.EcmC];
        for (int i = 0; i < fields.Length; i++) BinaryPrimitives.WriteInt32LittleEndian(wire.AsSpan(20 + 4*i), fields[i]);
        return wire;
    }
}

// Single owner, in-process prototype. Time is monotonic milliseconds from the same clock.
// Transport identity, freshness and native delivery are deliberately outside this class.
public sealed class VehicleController
{
    private static readonly int[] Times = [0, 2000, 4000, 60000, 180000];
    private static readonly EcmValues[] States = [
        new(12500,0,0,0,0,0,100,100,20,20,20),
        new(10500,200,0,0,150,200,100,90,20,20,20),
        new(14200,1100,0,0,250,900,100,45,20,20,25),
        new(14000,900,0,0,200,700,100,38,60,25,35),
        new(14000,700,0,0,180,550,100,35,90,30,45)];
    private readonly object gate = new();
    private Ignition ignition;
    private bool started;
    private long epoch, lastTime;
    private ulong sequence;
    // Requested pedal is immediate; engine response is a deterministic slew.
    // No drivetrain or OEM engine calibration is implied.
    private int pedal, responseAtCommand;
    private long pedalEpoch;
    private void ClearPedal(long now) { pedal = responseAtCommand = 0; pedalEpoch = now; }
    private int PedalResponse(long now)
    {
        long elapsed = Math.Min(now - pedalEpoch, 2000L);
        int delta = pedal - responseAtCommand;
        int step = (int)(elapsed * (delta >= 0 ? 500 : 1000) / 1000);
        return responseAtCommand + Math.Sign(delta) * Math.Min(Math.Abs(delta), step);
    }
    public void SetAccelerator(int permille, long now)
    {
        lock (gate)
        {
            CheckTime(now);
            if (permille is < 0 or > 1000) throw new ArgumentOutOfRangeException(nameof(permille));
            if (ignition != Ignition.On || !started || now - epoch < 4000)
                throw new InvalidOperationException("Running engine required");
            if (pedal != permille)
            {
                responseAtCommand = PedalResponse(now);
                pedal = permille; pedalEpoch = now;
            }
            lastTime = now;
        }
    }
    private EcmValues ApplyAccelerator(EcmValues baseline, long now)
    {
        int response = PedalResponse(now);
        int Blend(int a, int b) => a + (b - a) * response / 1000;
        return baseline with {
            PedalPermille = pedal,
            Rpm = Blend(baseline.Rpm, 4500),
            LoadPermille = Blend(baseline.LoadPermille, 850),
            MafCentiGps = Blend(baseline.MafCentiGps, 6500),
            ManifoldKpa = Blend(baseline.ManifoldKpa, 95)
        };
    }
    private void CheckTime(long now) { if (now < lastTime) throw new ArgumentOutOfRangeException(nameof(now)); }
    public void SetIgnition(Ignition value, long now)
    {
        lock (gate) { CheckTime(now); if (!Enum.IsDefined(value)) throw new ArgumentOutOfRangeException(nameof(value));
            ignition = value; if (value != Ignition.On) { started = false; ClearPedal(now); } lastTime = now; }
    }
    public void StartEngine(long now)
    {
        lock (gate) { CheckTime(now); if (ignition != Ignition.On) throw new InvalidOperationException("Ignition II required");
            if (!started) { epoch = now; started = true; ClearPedal(now); } lastTime = now; }
    }
    public void StopEngine(long now) { lock (gate) { CheckTime(now); started = false; ClearPedal(now); lastTime = now; } }
    public void Reset(long now) { lock (gate) { CheckTime(now); started = false; ClearPedal(now); ignition = Ignition.Off; lastTime = now; } }
    public VehicleSnapshot Snapshot(long now)
    {
        lock (gate)
        {
            CheckTime(now); if (sequence == ulong.MaxValue) throw new InvalidOperationException("Sequence exhausted");
            long elapsed = started ? now - epoch : 0;
            var e = started ? Sample(elapsed) : States[0];
            var mode = !started ? Engine.Off : elapsed < 4000 ? Engine.Cranking : Engine.Running;
            if (mode == Engine.Running) e = ApplyAccelerator(e, now);
            lastTime = now; return new(++sequence, ignition, mode, e);
        }
    }
    public static EcmValues Sample(long elapsed)
    {
        if (elapsed < 0) throw new ArgumentOutOfRangeException(nameof(elapsed));
        if (elapsed >= Times[^1]) return States[^1];
        int i = 0; while (elapsed >= Times[i+1]) i++;
        int pos = (int)elapsed - Times[i], span = Times[i+1] - Times[i];
        EcmValues a = States[i], b = States[i+1];
        int L(int x, int y) => x + (int)((long)(y-x)*pos/span);
        return new(L(a.BatteryMv,b.BatteryMv), L(a.Rpm,b.Rpm), L(a.SpeedKph,b.SpeedKph),
            L(a.PedalPermille,b.PedalPermille), L(a.LoadPermille,b.LoadPermille), L(a.MafCentiGps,b.MafCentiGps),
            L(a.AmbientKpa,b.AmbientKpa), L(a.ManifoldKpa,b.ManifoldKpa), L(a.CoolantC,b.CoolantC),
            L(a.IntakeC,b.IntakeC), L(a.EcmC,b.EcmC));
    }
}
