import tempfile,unittest
from pathlib import Path
from stage_rotation import transform,stage,EDITS
S='\n'.join(old for old,_ in EDITS)+'\nSectorVVirtualCar.log\nSectorVVirtualCar.log\n'
class T(unittest.TestCase):
 def test_exact(self):
  out=transform(S);self.assertEqual(out.count('VirtualCar-VC110.log'),2);self.assertIn('vc110_write(g_log_path,line,p);',out);self.assertNotIn('SectorVVirtualCar.log',out)
 def test_missing(self):
  for old,_ in EDITS:
   with self.assertRaises(ValueError):transform(S.replace(old,''))
 def test_duplicate(self):
  for old,_ in EDITS:
   with self.assertRaises(ValueError):transform(S+'\n'+old)
 def test_path_count(self):
  with self.assertRaises(ValueError):transform(S+'SectorVVirtualCar.log')
 def test_stage(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);f=p/'virtualcar.c';f.write_text(S);stage(p)
   self.assertEqual(f.read_text(),transform(S));self.assertTrue((p/'vc110/rotation_windows.c').is_file());self.assertTrue((p/'vc110/rotation.h').is_file())
   with self.assertRaises(ValueError):stage(p)
if __name__=='__main__':unittest.main(verbosity=2)
