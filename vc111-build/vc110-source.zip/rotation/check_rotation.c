#include "rotation.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct { uint64_t size[4]; int present[4], fail_size, fail_move, fail_append; unsigned moves,writes; char content[4][32]; } fake;
static int size(void *v,unsigned s,uint64_t *n){fake *f=v;if(f->fail_size)return -1;*n=f->size[s];return f->present[s];}
static int move(void *v,unsigned a,unsigned b){fake *f=v;f->moves++;if(f->fail_move==(int)a+1)return 0;if(f->present[a]){f->present[b]=1;f->present[a]=0;f->size[b]=f->size[a];f->size[a]=0;memcpy(f->content[b],f->content[a],32);memset(f->content[a],0,32);}return 1;}
static int append(void *v,const char *p,unsigned n){fake *f=v;if(f->fail_append)return 0;f->writes++;assert(f->size[0]+n<=32);memcpy(f->content[0]+f->size[0],p,n);f->present[0]=1;f->size[0]+=n;return 1;}
static const vc110_ops ops={size,move,append};
#define PUT(s) vc110_record(&ops,&f,8,s,sizeof(s)-1)
int main(void){fake f={0};unsigned i;
assert(PUT("1234")&&f.size[0]==4&&f.moves==0); /* 1 */
assert(PUT("5678")&&f.size[0]==8&&f.moves==0); /* 2 */
assert(PUT("A")&&f.size[0]==1&&f.size[1]==8&&memcmp(f.content[1],"12345678",8)==0); /* 3 */
assert(PUT("BCDEFGH")&&f.size[0]==8&&f.moves==3); /* 4 */
assert(PUT("IJKLMNOP")&&f.size[2]==8&&memcmp(f.content[1],"ABCDEFGH",8)==0); /* 5 */
assert(PUT("QRSTUVWX")&&memcmp(f.content[3],"12345678",8)==0); /* 6 */
assert(PUT("abcdefgh")&&memcmp(f.content[3],"ABCDEFGH",8)==0); /* 7 */
assert(!PUT("123456789")&&f.size[0]==8); /* 8 */
assert(!vc110_record(&ops,&f,8,"",0)); /* 9 */
f.fail_size=1;assert(!PUT("x")&&f.size[0]==8);f.fail_size=0; /* 10 */
for(i=1;i<=3;i++){fake copy=f;f.fail_move=i;unsigned writes=f.writes;assert(!PUT("x")&&f.writes==writes&&f.size[0]==8);f=copy;} /* 11 */
f.fail_append=1;assert(!PUT("x")&&f.size[0]==0&&f.size[1]==8); /* 12 */
f.fail_append=0;assert(PUT("recover")&&f.size[0]==7); /* 13 */
for(i=0;i<10000;i++){assert(PUT("abc"));for(unsigned j=0;j<4;j++)assert(f.size[j]<=8);} /* 14 */
puts("VC110_POLICY=PASS 14/14; 10000 repeated appends");return 0;}
