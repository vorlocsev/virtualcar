"""Patch only the staged VC108P source tree, never the active DLL or repository."""
from pathlib import Path
import shutil,sys
OLD='''    f=CreateFileA(g_log_path,0x00100004u,3,0,4,0x80,0); /* SYNCHRONIZE|FILE_APPEND_DATA, OPEN_ALWAYS */
    if(f==INVALID_HANDLE)return;
    WriteFile(f,line,p,&written,0);CloseHandle(f);'''
EDITS=[('#include "vc0663_identity.h"','#include "vc0663_identity.h"\n#include "vc110/rotation.h"'),('    HANDLE f;U32 written;char line[320];U32 p=0;','    char line[320];U32 p=0;'),(OLD,'    vc110_write(g_log_path,line,p);')]
def transform(source):
    for old,new in EDITS:
        if source.count(old)!=1: raise ValueError('Missing or ambiguous source anchor: '+old[:60])
        source=source.replace(old,new,1)
    if source.count('SectorVVirtualCar.log')!=2: raise ValueError('Unexpected legacy log path count')
    return source.replace('SectorVVirtualCar.log','VirtualCar-VC110.log')
def stage(src):
    src=Path(src);f=src/'virtualcar.c';dest=src/'vc110'
    if dest.exists():raise ValueError('Fresh stage required')
    result=transform(f.read_text(encoding='utf-8'))
    dest.mkdir()
    for name in ('rotation.h','rotation_windows.c'):shutil.copyfile(Path(__file__).parent/name,dest/name)
    f.write_bytes(result.encode('utf-8'))
    print('VC110_ROTATION_STAGE=PASS (source only)')
if __name__=='__main__':stage(sys.argv[1])
